import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { Request, Response, NextFunction } from 'express';

// Ensure upload directories exist
const createDirectoryIfNotExists = (dirPath: string) => {
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
  }
};

const uploadDirs = [
  'public/uploads/images/categories',
  'public/uploads/images/saints',
  'public/uploads/images/header'
];

uploadDirs.forEach(dir => createDirectoryIfNotExists(dir));

// Configure storage
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    // Determine destination based on uploaded file type or request path
    let uploadPath = 'public/uploads/images';
    
    if (req.path.includes('/categories')) {
      uploadPath += '/categories';
    } else if (req.path.includes('/saints')) {
      uploadPath += '/saints';
    } else if (req.path.includes('/header')) {
      uploadPath += '/header';
    }
    
    cb(null, uploadPath);
  },
  filename: (req, file, cb) => {
    // Generate a unique filename with timestamp and original extension
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const ext = path.extname(file.originalname);
    cb(null, file.fieldname + '-' + uniqueSuffix + ext);
  }
});

// Filter for image types
const fileFilter = (req: Request, file: Express.Multer.File, cb: multer.FileFilterCallback) => {
  // Accept only images including newer formats
  const allowedTypes = [
    'image/jpeg',
    'image/jpg', 
    'image/png',
    'image/gif',
    'image/webp',
    'image/avif',
    'image/svg+xml'
  ];
  
  // Check for AVIF files specifically by extension if MIME detection fails
  const isAvifFile = file.originalname.toLowerCase().endsWith('.avif');
  
  if (file.mimetype.startsWith('image/') || allowedTypes.includes(file.mimetype) || isAvifFile) {
    cb(null, true);
  } else {
    cb(new Error('Not an image! Please upload only images.'));
  }
};

// Create multer upload middleware
export const upload = multer({
  storage: storage,
  fileFilter: fileFilter,
  limits: {
    fileSize: 5 * 1024 * 1024 // Limit file size to 5MB
  }
});

// Error handling middleware for multer errors
export const handleMulterError = (err: any, req: Request, res: Response, next: NextFunction) => {
  if (err instanceof multer.MulterError) {
    if (err.code === 'LIMIT_FILE_SIZE') {
      return res.status(400).json({
        error: 'File too large. Maximum size is 5MB.'
      });
    }
    return res.status(400).json({
      error: err.message
    });
  } else if (err) {
    return res.status(400).json({
      error: err.message
    });
  }
  next();
};

// Convert uploaded file path to URL path
export const getUploadedFileUrl = (filePath: string): string => {
  // Remove 'public/' from the beginning of the path to get the URL path
  return filePath.replace(/^public\//, '/');
};
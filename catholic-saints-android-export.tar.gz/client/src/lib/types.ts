export type CategoryWithCount = {
  id: number;
  name: string;
  description: string | null;
  icon: string;
  iconBgColor: string;
  iconColor: string;
  imageUrl: string | null;
  saintCount: number;
};

export type SaintPreview = {
  id: number;
  name: string;
  description: string;
  imageUrl: string | null;
  categoryName?: string;
  categoryId?: number;
};

export type SaintDetail = {
  id: number;
  name: string;
  title: string | null;
  description: string;
  imageUrl: string | null;
  feastDay: string | null;
  patronOf: string | null;
  born: string | null;
  died: string | null;
  prayer: string;
  novenaLength: number;
  categories: {
    id: number;
    name: string;
  }[];
};

export type ActiveNovena = {
  id: number;
  saintId: number;
  saintName: string;
  saintImageUrl: string | null;
  categoryName: string;
  startDate: string;
  currentDay: number;
  completedDays: number[];
  intention: string | null;
  isComplete: boolean;
  novenaLength?: number;
};

export type NovenaDetail = {
  id: number;
  saintId: number;
  saint: {
    id: number;
    name: string;
    imageUrl: string | null;
    prayer: string;
    novenaLength?: number;
  };
  startDate: string;
  currentDay: number;
  completedDays: number[];
  intention: string | null;
  isComplete: boolean;
};

export type CategoryResponse = {
  id: number;
  name: string;
  description: string | null;
  icon: string;
  iconBgColor: string;
  iconColor: string;
  imageUrl: string | null;
  saintCount: number;
};

export type SaintResponse = {
  id: number;
  name: string;
  title: string | null;
  description: string;
  imageUrl: string | null;
  feastDay: string | null;
  patronOf: string | null;
  born: string | null;
  died: string | null;
  prayer: string;
  isPopular: boolean;
  novenaLength?: number;
  categories?: { id: number; name: string }[];
};

export type NovenaPrayerResponse = {
  id: number;
  saintId: number;
  day: number;
  title: string | null;
  content: string;
  createdAt: string;
};

export type NovenaResponse = {
  id: number;
  userId: string;
  saintId: number;
  startDate: string;
  currentDay: number;
  completedDays: number[];
  intention: string | null;
  isComplete: boolean;
  saint?: SaintResponse;
  dailyPrayer?: NovenaPrayerResponse;
};

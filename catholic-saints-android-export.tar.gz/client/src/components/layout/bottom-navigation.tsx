import * as React from "react";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";

export function BottomNavigation() {
  const [location, navigate] = useLocation();

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 shadow-soft-lg z-10 transition-transform duration-300">
      <div className="flex justify-around">
        <NavItem 
          icon="fas fa-home" 
          label="Home" 
          isActive={location === "/"} 
          onClick={() => navigate("/")} 
        />
        <NavItem 
          icon="fas fa-pray" 
          label="Saints" 
          isActive={location.startsWith("/saints") || location.startsWith("/category")} 
          onClick={() => navigate("/saints")} 
        />
        <NavItem 
          icon="fas fa-heart" 
          label="Total Consecration" 
          isActive={location.startsWith("/consecration-home") || location.startsWith("/consecration/")} 
          onClick={() => navigate("/consecration-home")} 
        />
        <NavItem 
          icon="fas fa-calendar-alt" 
          label="54-Day Rosary" 
          isActive={location.startsWith("/rosary-novena")} 
          onClick={() => navigate("/rosary-novena-home")} 
        />
        <NavItem 
          icon="fas fa-rosary" 
          label="Holy Rosary" 
          isActive={location.startsWith("/holy-rosary")} 
          onClick={() => navigate("/holy-rosary-home")} 
        />
        <NavItem 
          icon="fas fa-book-open" 
          label="My Novenas" 
          isActive={location.startsWith("/novenas")} 
          onClick={() => navigate("/novenas")} 
        />
        <NavItem 
          icon="fas fa-info-circle" 
          label="About Us" 
          isActive={location === "/about"} 
          onClick={() => navigate("/about")} 
        />
      </div>
    </nav>
  );
}

interface NavItemProps {
  icon: string;
  label: string;
  isActive: boolean;
  onClick: () => void;
}

function NavItem({ icon, label, isActive, onClick }: NavItemProps) {
  return (
    <button 
      className={cn(
        "flex flex-col items-center py-3 px-4 relative transition-all duration-200", 
        isActive ? "text-primary" : "text-slate-500 hover:text-slate-700"
      )}
      onClick={onClick}
    >
      {/* Active indicator dot */}
      {isActive && (
        <span className="absolute top-0 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-primary"></span>
      )}
      
      {/* Icon with animation */}
      <div className={cn(
        "relative flex items-center justify-center transition-transform duration-200",
        isActive ? "scale-110" : "scale-100"
      )}>
        <i className={cn(icon, "text-xl")}></i>
        
        {/* Icon background effect when active */}
        {isActive && (
          <span className="absolute inset-0 bg-primary bg-opacity-10 rounded-full -m-1.5 pulse-gentle"></span>
        )}
      </div>
      
      <span className={cn(
        "text-xs mt-1 transition-all duration-200",
        isActive ? "font-medium" : "font-normal"
      )}>
        {label}
      </span>
    </button>
  );
}

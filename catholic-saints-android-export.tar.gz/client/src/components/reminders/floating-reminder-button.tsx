import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

interface NovenaResponse {
  id: number;
  saintId: number;
  saint?: {
    id: number;
    name: string;
    imageUrl?: string;
    novenaLength?: number;
  };
  startDate: string;
  currentDay: number;
  completedDays: number[];
  intention?: string;
  isComplete: boolean;
}

interface FloatingReminderButtonProps {
  hideOnPages?: string[];
}

export function FloatingReminderButton({ hideOnPages = ['/novenas', '/novena/'] }: FloatingReminderButtonProps) {
  const [location, navigate] = useLocation();
  
  // Don't show on specific pages
  const shouldHide = hideOnPages.some(page => location.startsWith(page));
  
  // Fetch active novenas
  const { data: novenas, isLoading } = useQuery<NovenaResponse[]>({
    queryKey: ["/api/novenas"],
  });

  // Count novenas that need prayer today
  const pendingCount = React.useMemo(() => {
    if (!novenas) return 0;
    
    return novenas.filter(novena => 
      !novena.isComplete && 
      !novena.completedDays.includes(novena.currentDay)
    ).length;
  }, [novenas]);

  const handleClick = () => {
    navigate('/novenas');
  };

  if (isLoading || pendingCount === 0 || shouldHide) {
    return null;
  }

  return (
    <div className="fixed bottom-20 right-4 z-40">
      <Button
        onClick={handleClick}
        className="bg-blue-600 hover:bg-blue-700 text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-300 px-4 py-2 flex items-center gap-2 animate-pulse"
        size="sm"
      >
        <i className="fas fa-bell text-sm"></i>
        <span className="text-sm font-medium">
          {pendingCount} prayer{pendingCount !== 1 ? 's' : ''} waiting
        </span>
        <Badge className="bg-white text-blue-600 font-bold text-xs px-1.5 py-0.5">
          {pendingCount}
        </Badge>
      </Button>
    </div>
  );
}
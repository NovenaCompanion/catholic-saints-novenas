import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

interface NovenaResponse {
  id: number;
  saintId: number;
  saint?: {
    id: number;
    name: string;
    imageUrl?: string;
    novenaLength?: number;
  };
  startDate: string;
  currentDay: number;
  completedDays: number[];
  intention?: string;
  isComplete: boolean;
}

interface DailyNovenaReminderProps {
  onDismiss?: () => void;
}

export function DailyNovenaReminder({ onDismiss }: DailyNovenaReminderProps) {
  const [, navigate] = useLocation();
  
  // Fetch active novenas
  const { data: novenas, isLoading } = useQuery<NovenaResponse[]>({
    queryKey: ["/api/novenas"],
  });

  // Filter novenas that need prayer today
  const activeNovenas = React.useMemo(() => {
    if (!novenas) return [];
    
    return novenas.filter(novena => 
      !novena.isComplete && 
      !novena.completedDays.includes(novena.currentDay)
    );
  }, [novenas]);

  const handlePrayNow = (novenaId: number, saintId: number, currentDay: number) => {
    // Special handling for Total Consecration (Saint ID 10) - go directly to current day
    if (saintId === 10) {
      navigate(`/consecration/${novenaId}/day/${currentDay}`);
    } 
    // Special handling for 54-Day Rosary Novena (Saint ID 9) - go to specific novena detail
    else if (saintId === 9) {
      navigate(`/rosary-novena/${novenaId}`);
    } 
    else {
      navigate(`/novena/${novenaId}`);
    }
    onDismiss?.();
  };

  const handleViewAllNovenas = () => {
    navigate('/novenas');
    onDismiss?.();
  };

  if (isLoading || activeNovenas.length === 0) {
    return null;
  }

  return (
    <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200 p-4 mb-4 shadow-sm">
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-2">
            <i className="fas fa-bell text-blue-600"></i>
            <h3 className="font-serif text-lg font-semibold text-blue-900">
              Prayer Reminder
            </h3>
            <Badge variant="secondary" className="bg-blue-100 text-blue-800">
              {activeNovenas.length} {activeNovenas.length === 1 ? 'novena' : 'novenas'}
            </Badge>
          </div>
          
          <p className="text-blue-700 text-sm mb-3">
            You have {activeNovenas.length === 1 ? 'a novena' : 'novenas'} waiting for today's prayer
          </p>
          
          {/* Show first 2 active novenas */}
          <div className="space-y-2 mb-3">
            {activeNovenas.slice(0, 2).map((novena) => (
              <div key={novena.id} className="flex items-center justify-between bg-white rounded-lg p-3 border border-blue-100">
                <div className="flex items-center gap-3">
                  {novena.saint?.imageUrl && (
                    <img 
                      src={novena.saint.imageUrl} 
                      alt={novena.saint.name}
                      className="w-8 h-8 rounded-full object-cover"
                    />
                  )}
                  <div>
                    <p className="font-medium text-slate-900 text-sm">
                      {novena.saint?.name}
                    </p>
                    <p className="text-xs text-slate-600">
                      Day {novena.currentDay} of {novena.saint?.novenaLength || 9}
                    </p>
                  </div>
                </div>
                <Button 
                  size="sm"
                  onClick={() => handlePrayNow(novena.id, novena.saintId, novena.currentDay)}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 text-xs"
                >
                  Pray Now
                </Button>
              </div>
            ))}
            
            {activeNovenas.length > 2 && (
              <p className="text-blue-600 text-xs text-center">
                +{activeNovenas.length - 2} more novenas
              </p>
            )}
          </div>
          
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              size="sm"
              onClick={handleViewAllNovenas}
              className="border-blue-300 text-blue-700 hover:bg-blue-50"
            >
              View All
            </Button>
            {onDismiss && (
              <Button 
                variant="ghost" 
                size="sm"
                onClick={onDismiss}
                className="text-blue-600 hover:text-blue-700 hover:bg-blue-50"
              >
                Dismiss
              </Button>
            )}
          </div>
        </div>
        
        {onDismiss && (
          <button 
            onClick={onDismiss}
            className="text-blue-400 hover:text-blue-600 ml-2"
          >
            <i className="fas fa-times text-sm"></i>
          </button>
        )}
      </div>
    </Card>
  );
}
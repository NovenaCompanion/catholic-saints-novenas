import * as React from "react";
import { cn } from "@/lib/utils";

export interface ProgressCircleProps {
  day: number;
  status: "completed" | "current" | "pending";
  date?: string;
  onClick?: () => void;
  className?: string;
}

export function ProgressCircle({
  day,
  status,
  date,
  onClick,
  className,
}: ProgressCircleProps) {
  const getStatusClasses = () => {
    switch (status) {
      case "completed":
        return "border-green-500 bg-green-100 text-green-700 shadow-sm";
      case "current":
        return "border-blue-500 bg-blue-100 text-blue-700 shadow pulse-gentle";
      case "pending":
        return "border-slate-300 bg-white text-slate-400";
      default:
        return "border-slate-300 bg-white text-slate-400";
    }
  };
  
  // Get appropriate icon based on status
  const getIcon = () => {
    switch (status) {
      case "completed":
        return <i className="fas fa-check text-[0.65rem]"></i>;
      case "current":
        return <span className="text-xs font-bold">{day}</span>;
      default:
        return <span className="text-xs font-bold">{day}</span>;
    }
  };
  
  // For days > 99, we need to use a smaller font size to fit
  const dayText = day > 99 ? 
    <span className="text-[0.6rem] font-bold">{day}</span> : 
    getIcon();

  return (
    <div className={cn("flex flex-col items-center group", className)}>
      <div
        className={cn(
          "w-7 h-7 rounded-full flex items-center justify-center border-2 text-xs font-bold transition-all duration-200", 
          getStatusClasses(), 
          onClick && "cursor-pointer hover:scale-110"
        )}
        onClick={onClick}
      >
        {dayText}
      </div>
      {date && (
        <span className="text-[0.65rem] text-slate-500 mt-1 opacity-80 group-hover:opacity-100">
          {date}
        </span>
      )}
    </div>
  );
}

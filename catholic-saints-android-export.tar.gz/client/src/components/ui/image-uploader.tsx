import * as React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";

interface ImageUploaderProps {
  onImageUploaded: (imageUrl: string) => void;
  uploadType: "categories" | "saints" | "header";
  currentImageUrl?: string;
  className?: string;
}

export function ImageUploader({
  onImageUploaded,
  uploadType,
  currentImageUrl,
  className = "",
}: ImageUploaderProps) {
  const { toast } = useToast();
  const [isUploading, setIsUploading] = React.useState(false);
  const [previewUrl, setPreviewUrl] = React.useState<string | null>(currentImageUrl || null);
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  // Update preview when currentImageUrl prop changes
  React.useEffect(() => {
    if (currentImageUrl) {
      setPreviewUrl(currentImageUrl);
    }
  }, [currentImageUrl]);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Basic validation
    if (!file.type.match('image.*')) {
      toast({
        title: "Invalid file type",
        description: "Please select an image file (JPEG, PNG, etc.)",
        variant: "destructive",
      });
      return;
    }

    // Size validation (5MB max)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Please select an image smaller than 5MB",
        variant: "destructive",
      });
      return;
    }

    // Show preview
    const reader = new FileReader();
    reader.onload = (event) => {
      setPreviewUrl(event.target?.result as string);
    };
    reader.readAsDataURL(file);

    // Upload the file
    await uploadImage(file);
  };

  const uploadImage = async (file: File) => {
    setIsUploading(true);

    try {
      const formData = new FormData();
      formData.append("image", file);

      const response = await fetch(`/api/upload/${uploadType}`, {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        throw new Error("Failed to upload image");
      }

      const data = await response.json();
      onImageUploaded(data.url);

      toast({
        title: "Image uploaded successfully",
        description: "Your image has been uploaded and will be used.",
      });
    } catch (error) {
      console.error("Error uploading image:", error);
      toast({
        title: "Upload failed",
        description: "There was an error uploading your image. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
    }
  };

  const handleButtonClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className={`space-y-4 ${className}`}>
      <div className="flex flex-col items-center">
        {/* Hidden file input */}
        <Input
          type="file"
          accept="image/*"
          ref={fileInputRef}
          onChange={handleFileChange}
          className="hidden"
        />

        {/* Upload button */}
        <Button
          type="button"
          onClick={handleButtonClick}
          disabled={isUploading}
          variant="outline"
          className="w-full"
        >
          {isUploading ? (
            <>
              <i className="fas fa-spinner fa-spin mr-2"></i>
              Uploading...
            </>
          ) : (
            <>
              <i className="fas fa-upload mr-2"></i>
              {previewUrl ? "Change Image" : "Upload Image"}
            </>
          )}
        </Button>

        {/* Image preview */}
        {previewUrl && (
          <div className="mt-4 relative border border-slate-200 rounded-md overflow-hidden">
            <img
              src={previewUrl.startsWith("data:") ? previewUrl : previewUrl}
              alt="Image preview"
              className="max-w-full h-auto max-h-48 object-contain"
            />
            <Button
              type="button"
              onClick={() => {
                setPreviewUrl(null);
                onImageUploaded("");
                if (fileInputRef.current) {
                  fileInputRef.current.value = "";
                }
              }}
              variant="destructive"
              size="sm"
              className="absolute top-2 right-2 h-8 w-8 p-0 rounded-full"
            >
              <i className="fas fa-times"></i>
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
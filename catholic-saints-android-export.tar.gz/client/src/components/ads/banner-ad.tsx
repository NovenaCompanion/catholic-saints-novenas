import * as React from "react";
import { Capacitor } from "@capacitor/core";
import { AdMob, BannerAdOptions, BannerAdSize, BannerAdPosition } from "@capacitor-community/admob";

// Web AdSense Banner Component for Desktop
function WebBannerAd() {
  const adRef = React.useRef<HTMLDivElement>(null);
  const [adError, setAdError] = React.useState<string | null>(null);

  React.useEffect(() => {
    const loadAdSense = () => {
      try {
        // Check if AdSense script is loaded
        if (typeof window !== 'undefined' && (window as any).adsbygoogle) {
          // Push the ad
          ((window as any).adsbygoogle = (window as any).adsbygoogle || []).push({});
        } else {
          // Load AdSense script if not already loaded
          const script = document.createElement('script');
          script.async = true;
          script.src = 'https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-XXXXXXXXXXXXXXXXX'; // Replace with your AdSense client ID
          script.crossOrigin = 'anonymous';
          document.head.appendChild(script);
          
          script.onload = () => {
            if ((window as any).adsbygoogle) {
              ((window as any).adsbygoogle = (window as any).adsbygoogle || []).push({});
            }
          };
        }
      } catch (error) {
        console.error('Failed to load AdSense ad:', error);
        setAdError('Failed to load advertisement');
      }
    };

    loadAdSense();
  }, []);

  if (adError) {
    return (
      <div className="bg-red-50 p-2 text-center text-xs text-red-600">
        {adError}
      </div>
    );
  }

  return (
    <div className="w-full flex justify-center my-4">
      {/* Google AdSense Banner Ad - Replace data-ad-client and data-ad-slot with your values */}
      <ins 
        className="adsbygoogle block"
        style={{ display: 'block' }}
        data-ad-client="ca-pub-XXXXXXXXXXXXXXXXX" // Replace with your AdSense client ID
        data-ad-slot="XXXXXXXXXX" // Replace with your ad slot ID
        data-ad-format="auto"
        data-full-width-responsive="true"
        ref={adRef}
      />
    </div>
  );
}

interface BannerAdProps {
  position?: BannerAdPosition;
  size?: BannerAdSize;
  className?: string;
}

export function BannerAd({ 
  position = BannerAdPosition.BOTTOM_CENTER, 
  size = BannerAdSize.ADAPTIVE_BANNER,
  className = "" 
}: BannerAdProps) {
  const [isAdLoaded, setIsAdLoaded] = React.useState(false);
  const [adError, setAdError] = React.useState<string | null>(null);

  React.useEffect(() => {
    // Only show ads on mobile platforms
    if (!Capacitor.isNativePlatform()) {
      return;
    }

    const showBannerAd = async () => {
      try {
        // Initialize AdMob if not already done
        await AdMob.initialize({
          testingDevices: ['2077ef9a63d2b398840261c8221a0c9b'], // Add your test device ID
        });

        const options: BannerAdOptions = {
          adId: 'ca-app-pub-3940256099942544/6300978111', // Test banner ad unit ID
          adSize: size,
          position: position,
          margin: 0,
          isTesting: true, // Remove this in production
        };

        await AdMob.showBanner(options);
        setIsAdLoaded(true);
        setAdError(null);
      } catch (error) {
        console.error('Failed to show banner ad:', error);
        setAdError('Failed to load advertisement');
        setIsAdLoaded(false);
      }
    };

    showBannerAd();

    // Cleanup function to hide banner when component unmounts
    return () => {
      if (Capacitor.isNativePlatform()) {
        AdMob.hideBanner().catch(console.error);
      }
    };
  }, [position, size]);

  // On web platforms, show Google AdSense ad
  if (!Capacitor.isNativePlatform()) {
    return (
      <div className={`w-full ${className}`}>
        <WebBannerAd />
      </div>
    );
  }

  // On mobile, the ad is handled natively, so we just return a spacer
  if (isAdLoaded) {
    return <div className={`h-16 ${className}`} />; // Spacer for banner ad
  }

  if (adError) {
    return (
      <div className={`bg-red-50 p-2 text-center text-xs text-red-600 ${className}`}>
        {adError}
      </div>
    );
  }

  return <div className={`h-16 ${className}`} />; // Loading spacer
}

// Hook for interstitial ads
export function useInterstitialAd() {
  const showInterstitial = React.useCallback(async () => {
    if (!Capacitor.isNativePlatform()) {
      console.log('Interstitial ad would show here on mobile');
      return;
    }

    try {
      await AdMob.prepareInterstitial({
        adId: 'ca-app-pub-3940256099942544/1033173712', // Test interstitial ad unit ID
        isTesting: true, // Remove this in production
      });

      await AdMob.showInterstitial();
    } catch (error) {
      console.error('Failed to show interstitial ad:', error);
    }
  }, []);

  return { showInterstitial };
}
import * as React from "react";
import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Heart, Play, ArrowRight, Sparkles } from "lucide-react";
import { SaintPreview } from "@/lib/types";

interface SaintCardProps {
  saint: SaintPreview;
  onClick?: () => void;
}

export function SaintCard({ saint, onClick }: SaintCardProps) {
  const [, navigate] = useLocation();

  // Get universal saint image from database
  const [universalSaintImage, setUniversalSaintImage] = React.useState<string | undefined>(undefined);

  // Load image from database
  React.useEffect(() => {
    const loadImage = async () => {
      try {
        const response = await fetch('/api/images/universal-saint');
        if (response.ok) {
          const data = await response.json();
          setUniversalSaintImage(data.url);
        }
      } catch (error) {
        console.error('Error loading universal saint image:', error);
      }
    };

    loadImage();

    // Listen for image update events
    const handleImageChange = () => {
      loadImage();
    };

    window.addEventListener('universalImageChanged', handleImageChange);

    return () => {
      window.removeEventListener('universalImageChanged', handleImageChange);
    };
  }, []);
  
  const handleClick = () => {
    if (onClick) {
      onClick();
    } else {
      // Special redirects for specialized saints
      if (saint.id === 9) {
        // 54 Day Rosary Novena
        navigate('/rosary-novena');
      } else if (saint.id === 10) {
        // Total Consecration
        navigate('/consecration-home');
      } else {
        navigate(`/saint/${saint.id}`);
      }
    }
  };

  return (
    <Card 
      className="group bg-white/80 backdrop-blur-sm border-0 shadow-xl rounded-2xl overflow-hidden cursor-pointer transform transition-all duration-500 hover:scale-105 hover:shadow-2xl"
      onClick={handleClick}
    >
      {/* Modern Saint Image Section */}
      <div className="relative h-48 overflow-hidden">
        <div 
          className="h-full w-full bg-gradient-to-br from-blue-100 to-purple-100 flex items-center justify-center transform transition-transform duration-700 group-hover:scale-110"
          style={(universalSaintImage || saint.imageUrl) ? { 
            backgroundImage: `url(${universalSaintImage || saint.imageUrl})`, 
            backgroundSize: 'cover', 
            backgroundPosition: 'center',
          } : {}}
        >
          {!universalSaintImage && !saint.imageUrl && (
            <div className="flex flex-col items-center justify-center h-full w-full">
              <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center mb-3">
                <Sparkles className="w-8 h-8 text-white" />
              </div>
              <span className="text-sm text-slate-600 font-medium">Sacred Image</span>
            </div>
          )}
          
          {/* Enhanced overlay with gradient */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent"></div>
          
          {/* Category Badge */}
          {saint.categoryName && (
            <div className="absolute top-4 left-4">
              <Badge className="bg-white/90 text-slate-700 border-0 backdrop-blur-sm font-medium px-3 py-1 rounded-full">
                {saint.categoryName}
              </Badge>
            </div>
          )}
          
          {/* Heart Icon */}
          <div className="absolute top-4 right-4">
            <Button
              variant="ghost"
              size="sm"
              className="h-10 w-10 p-0 bg-white/20 backdrop-blur-sm hover:bg-white/30 rounded-full border-0"
              onClick={(e) => {
                e.stopPropagation();
                // Handle favorite functionality
              }}
            >
              <Heart className="w-5 h-5 text-white" />
            </Button>
          </div>
          
          {/* Saint name overlay on image */}
          <div className="absolute bottom-4 left-4 right-4">
            <h3 className="text-white font-bold text-xl leading-tight drop-shadow-lg">
              {saint.name}
            </h3>
          </div>
        </div>
      </div>
      
      {/* Modern Content Section */}
      <div className="p-6">
        <p className="text-slate-600 text-sm leading-relaxed mb-6 line-clamp-3">
          {saint.description}
        </p>
        
        {/* Enhanced Start Novena Button */}
        <Button
          className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-semibold py-3 rounded-xl shadow-lg transform transition-all duration-200 group-hover:scale-105"
          onClick={(e) => {
            e.stopPropagation();
            handleClick();
          }}
        >
          <div className="flex items-center justify-center gap-2">
            <Play className="w-5 h-5" />
            <span>Begin Novena</span>
            <ArrowRight className="w-4 h-4 opacity-0 group-hover:opacity-100 group-hover:translate-x-1 transition-all duration-200" />
          </div>
        </Button>
      </div>
    </Card>
  );
}

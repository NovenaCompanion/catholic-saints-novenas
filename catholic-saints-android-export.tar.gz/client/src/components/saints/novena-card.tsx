import * as React from "react";
import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { ActiveNovena } from "@/lib/types";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { ProgressCircle } from "@/components/ui/progress-circle";
import { format, addDays } from "date-fns";

interface NovenaCardProps {
  novena: ActiveNovena;
}

export function NovenaCard({ novena }: NovenaCardProps) {
  const [, navigate] = useLocation();
  const [isUpdating, setIsUpdating] = React.useState(false);

  // Get universal saint image from localStorage with state management
  const [universalSaintImage, setUniversalSaintImage] = React.useState<string | undefined>(() => {
    const stored = localStorage.getItem("universalSaintImage");
    return stored && stored.trim() !== "" ? stored : undefined;
  });

  // Listen for storage changes
  React.useEffect(() => {
    const handleStorageChange = () => {
      const stored = localStorage.getItem("universalSaintImage");
      setUniversalSaintImage(stored && stored.trim() !== "" ? stored : undefined);
    };

    window.addEventListener('storage', handleStorageChange);
    window.addEventListener('universalImageChanged', handleStorageChange);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('universalImageChanged', handleStorageChange);
    };
  }, []);

  const getDayStatus = (day: number) => {
    if (novena.completedDays.includes(day)) {
      return "completed";
    }
    if (day === novena.currentDay) {
      return "current";
    }
    return "pending";
  };

  const viewNovenaDetails = () => {
    // Special handling for Total Consecration (Saint ID 10) - go directly to current day
    if (novena.saintId === 10) {
      navigate(`/consecration/${novena.id}/day/${novena.currentDay}`);
    } 
    // Special handling for 54-Day Rosary Novena (Saint ID 9) - go to specific novena detail
    else if (novena.saintId === 9) {
      navigate(`/rosary-novena/${novena.id}`);
    } 
    else {
      navigate(`/novena/${novena.id}`);
    }
  };

  const markTodayComplete = async () => {
    try {
      setIsUpdating(true);
      
      // Use different API endpoint for 54-Day Rosary Novena
      if (novena.saintName.includes("54-Day Rosary Novena")) {
        await apiRequest('POST', `/api/rosary-novenas/${novena.id}/day/${novena.currentDay}/complete`, {});
        
        // Invalidate rosary novena cache
        queryClient.invalidateQueries({ queryKey: [`/api/rosary-novenas/${novena.id}`] });
        queryClient.invalidateQueries({ queryKey: ["/api/rosary-novenas/current"] });
      } else {
        await apiRequest(
          "PATCH", 
          `/api/novenas/${novena.id}/progress`, 
          { day: novena.currentDay }
        );
        
        // Invalidate regular novena cache
        queryClient.invalidateQueries({ queryKey: [`/api/novenas/${novena.id}`] });
        queryClient.invalidateQueries({ queryKey: ["/api/novenas"] });
      }
      
    } catch (error) {
      console.error("Failed to update novena progress:", error);
    } finally {
      setIsUpdating(false);
    }
  };

  const getStartDate = () => {
    try {
      return new Date(novena.startDate);
    } catch (e) {
      return new Date();
    }
  };

  return (
    <Card className="bg-white rounded-lg shadow-soft overflow-hidden border border-slate-100 hover-rise">
      <div className="flex items-stretch">
        {/* Saint Image Section */}
        <div className="w-1/3 relative overflow-hidden">
          <div 
            className="h-36 w-full bg-gradient-to-br from-blue-50 to-blue-100 flex items-center justify-center"
            style={(universalSaintImage || novena.saintImageUrl) ? { 
              backgroundImage: `url(${universalSaintImage || novena.saintImageUrl})`, 
              backgroundSize: 'cover', 
              backgroundPosition: 'center' 
            } : {}}
          >
            {!universalSaintImage && !novena.saintImageUrl && (
              <div className="flex flex-col items-center justify-center">
                <i className="fas fa-pray text-3xl text-primary opacity-30 mb-2"></i>
                <span className="text-xs text-blue-400">No Image</span>
              </div>
            )}
            
            {/* Image overlay gradient */}
            <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-transparent"></div>
          </div>
          
          {/* Overlay showing current day - positioned at the bottom of the image */}
          <div className="absolute bottom-0 left-0 right-0 bg-black/50 py-1.5 px-3 text-center">
            <span className="text-white text-xs font-medium">
              Started {format(getStartDate(), "MMM d")}
            </span>
          </div>
        </div>
        
        {/* Content Section */}
        <div className="w-2/3 p-4">
          <div className="flex justify-between items-start">
            <div>
              <span className="bg-primary/10 text-primary text-xs px-2 py-1 rounded-full font-medium">
                {novena.categoryName}
              </span>
              
              <h3 className="font-serif text-lg font-semibold mt-1 pr-4 line-clamp-1">
                {novena.saintName}
              </h3>
            </div>
            
            <span className={`
              px-3 py-1 rounded-full text-xs font-bold flex items-center
              ${novena.isComplete 
                ? "bg-green-100 text-green-700" 
                : "bg-secondary/10 text-secondary"}
            `}>
              {novena.isComplete 
                ? <><i className="fas fa-check-circle mr-1"></i> Complete</>
                : <>Day {novena.currentDay}</>
              }
            </span>
          </div>
          
          {/* Intention with styled quote marks */}
          <div className="relative mt-2 pl-3 border-l-2 border-slate-200">
            <p className="text-sm text-slate-600 italic">
              {novena.intention 
                ? `"${novena.intention}"`
                : <span className="text-slate-400">No intention set</span>
              }
            </p>
          </div>
          
          {/* Novena Progress with improved styling */}
          <div className="flex space-x-1 mt-3 overflow-x-auto pt-1 pb-2">
            {Array.from({ length: Math.min(9, novena.novenaLength || 9) }, (_, i) => i + 1).map((day) => (
              <ProgressCircle
                key={day}
                day={day}
                status={getDayStatus(day)}
              />
            ))}
          </div>
        </div>
      </div>
      
      {/* Action Bar with improved buttons */}
      <div className="bg-slate-50 p-4 flex justify-between items-center border-t border-slate-100">
        <button 
          className="text-primary hover:text-primary-dark font-medium text-sm flex items-center transition-colors duration-200 group" 
          onClick={viewNovenaDetails}
        >
          <i className="fas fa-book-open mr-2 bg-primary/10 h-7 w-7 flex items-center justify-center rounded-full group-hover:bg-primary group-hover:text-white transition-colors duration-200"></i> 
          View Prayer
        </button>
        
        {!novena.isComplete && (
          <button 
            className="bg-primary hover:bg-primary-dark text-white px-4 py-1.5 rounded-lg text-sm font-semibold disabled:opacity-50 transition-colors duration-200 flex items-center shadow-sm"
            onClick={markTodayComplete}
            disabled={isUpdating}
          >
            {isUpdating 
              ? <><i className="fas fa-circle-notch fa-spin mr-1"></i> Updating...</>
              : <><i className="fas fa-check mr-1"></i> Mark Complete</>
            }
          </button>
        )}
        
        {novena.isComplete && (
          <span className="text-green-600 font-semibold text-sm flex items-center">
            <i className="fas fa-check-circle mr-1"></i> Novena Completed
          </span>
        )}
      </div>
    </Card>
  );
}

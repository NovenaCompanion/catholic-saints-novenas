import * as React from "react";
import { Header } from "@/components/layout/header";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { Card } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

export default function Settings() {
  // Basic app preferences
  const [darkMode, setDarkMode] = React.useState(false);
  const [notifications, setNotifications] = React.useState(true);
  const [reminders, setReminders] = React.useState(true);
  const [floatingReminder, setFloatingReminder] = React.useState(true);
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow mt-14 mb-16">
        <div className="container mx-auto px-4 py-6">
          <h1 className="font-serif text-3xl font-bold mb-6">Settings</h1>
          
          <Card className="bg-white rounded-lg shadow-md p-5 mb-6">
            <h2 className="font-serif text-xl font-semibold mb-4">Application Preferences</h2>
            
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="dark-mode" className="font-medium">Dark Mode</Label>
                  <p className="text-sm text-slate-500">Enable dark theme for the application</p>
                </div>
                <Switch 
                  id="dark-mode" 
                  checked={darkMode} 
                  onCheckedChange={setDarkMode}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="notifications" className="font-medium">Notifications</Label>
                  <p className="text-sm text-slate-500">Receive notifications for novena reminders</p>
                </div>
                <Switch 
                  id="notifications" 
                  checked={notifications} 
                  onCheckedChange={setNotifications}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="reminders" className="font-medium">Daily Reminders</Label>
                  <p className="text-sm text-slate-500">Get daily reminders for active novenas</p>
                </div>
                <Switch 
                  id="reminders" 
                  checked={reminders} 
                  onCheckedChange={setReminders}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="floating-reminder" className="font-medium">Floating Prayer Button</Label>
                  <p className="text-sm text-slate-500">Show floating button when prayers are pending</p>
                </div>
                <Switch 
                  id="floating-reminder" 
                  checked={floatingReminder} 
                  onCheckedChange={setFloatingReminder}
                />
              </div>
            </div>
          </Card>

          {/* Privacy and Data */}
          <Card className="bg-white rounded-lg shadow-md p-5 mb-6">
            <h2 className="font-serif text-xl font-semibold mb-4">Privacy & Data</h2>
            
            <div className="space-y-4 text-slate-600">
              <p>
                Your prayer intentions and novena progress are stored locally on your device. 
                We respect your privacy and do not share your personal spiritual data.
              </p>
              
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h4 className="font-medium text-blue-900 mb-2">Data Usage</h4>
                <ul className="text-sm text-blue-800 space-y-1">
                  <li>• Novena progress is saved locally</li>
                  <li>• Prayer intentions remain private</li>
                  <li>• No tracking of personal spiritual practices</li>
                  <li>• Testimonials are only shared with your consent</li>
                </ul>
              </div>
            </div>
          </Card>

          {/* App Information */}
          <Card className="bg-white rounded-lg shadow-md p-5">
            <h2 className="font-serif text-xl font-semibold mb-4">App Information</h2>
            
            <div className="space-y-3 text-slate-600">
              <div className="flex justify-between">
                <span className="font-medium">Version</span>
                <span>1.0.0</span>
              </div>
              
              <div className="flex justify-between">
                <span className="font-medium">Last Updated</span>
                <span>June 2025</span>
              </div>
              
              <div className="flex justify-between">
                <span className="font-medium">Total Saints</span>
                <span>250+</span>
              </div>
              
              <div className="pt-4 border-t">
                <p className="text-sm text-center text-slate-500">
                  © 2025 Rosary City Foundation
                </p>
              </div>
            </div>
          </Card>
        </div>
      </main>
      
      <BottomNavigation />
    </div>
  );
}
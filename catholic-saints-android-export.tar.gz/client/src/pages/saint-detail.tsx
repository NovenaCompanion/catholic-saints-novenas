import * as React from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Header } from "@/components/layout/header";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { SaintResponse } from "@/lib/types";
import { Card } from "@/components/ui/card";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { TestimonialList } from "@/components/testimonials/testimonial-list";
import { TestimonialForm } from "@/components/testimonials/testimonial-form";

export default function SaintDetail() {
  const params = useParams();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const saintId = params.id;
  const [isTestimonialFormOpen, setIsTestimonialFormOpen] = React.useState(false);

  // Redirect to proper interfaces for special saints
  React.useEffect(() => {
    if (saintId === "9") {
      // 54-Day Rosary Novena
      navigate("/rosary-novena");
      return;
    } else if (saintId === "10") {
      // Total Consecration
      navigate("/consecration-home");
      return;
    }
  }, [saintId, navigate]);

  // Get universal saint image from localStorage with state management - MOVED TO TOP
  const [universalSaintImage, setUniversalSaintImage] = React.useState<string | undefined>(() => {
    return localStorage.getItem("universalSaintImage") || undefined;
  });

  // Listen for storage changes - MOVED TO TOP
  React.useEffect(() => {
    const handleStorageChange = () => {
      setUniversalSaintImage(localStorage.getItem("universalSaintImage") || undefined);
    };

    window.addEventListener('storage', handleStorageChange);
    window.addEventListener('universalImageChanged', handleStorageChange);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('universalImageChanged', handleStorageChange);
    };
  }, []);

  // Fetch saint details
  const { data: saint, isLoading } = useQuery<SaintResponse>({
    queryKey: [`/api/saints/${saintId}`],
  });

  const startNovena = useMutation({
    mutationFn: async () => {
      if (!saintId) throw new Error("Saint ID is required");
      const response = await apiRequest("POST", "/api/novenas", {
        saintId: parseInt(saintId, 10),
        intention: "My intention for this novena"
      });
      return await response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/novenas"] });
      toast({
        title: "Novena Started",
        description: `You've started a novena to ${saint?.name || 'this saint'}. May your prayers be heard.`,
      });
      
      // Route to consecration page for 33-Day Consecration
      if (saint?.name?.includes("33-Day Consecration")) {
        navigate(`/consecration/${data.id}`);
      } else {
        navigate(`/novena/${data.id}`);
      }
    },
    onError: (error) => {
      toast({
        title: "Failed to Start Novena",
        description: "There was an error starting your novena. Please try again.",
        variant: "destructive",
      });
      console.error("Error starting novena:", error);
    },
  });

  const navigateBack = () => {
    navigate("/");
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow mt-14 mb-16">
          <div className="container mx-auto px-4 py-6 text-center">
            <div className="mt-20">
              <i className="fas fa-pray text-4xl text-slate-300 mb-4"></i>
              <p>Loading saint information...</p>
            </div>
          </div>
        </main>
        <BottomNavigation />
      </div>
    );
  }

  const typedSaint = saint as SaintResponse;

  return (
    <div className="min-h-screen flex flex-col">
      <div className="relative">
        {(universalSaintImage || typedSaint.imageUrl) ? (
          <img 
            src={universalSaintImage || typedSaint.imageUrl || ''} 
            alt={typedSaint.name} 
            className="w-full h-56 object-cover"
          />
        ) : (
          <div className="w-full h-56 bg-blue-50 flex items-center justify-center">
            <i className="fas fa-pray text-4xl text-primary-dark opacity-30"></i>
          </div>
        )}
        <div className="absolute top-0 left-0 w-full h-56 bg-gradient-to-b from-black/50 to-transparent"></div>
        <button 
          className="absolute top-4 left-4 text-white bg-black/30 p-2 rounded-full"
          onClick={navigateBack}
        >
          <i className="fas fa-arrow-left"></i>
        </button>
        <button 
          className="absolute top-4 right-4 text-white bg-black/30 p-2 rounded-full" 
          aria-label="Add to favorites"
        >
          <i className="far fa-heart"></i>
        </button>
      </div>

      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center mb-4 flex-wrap gap-2">
          {typedSaint.categories?.map(category => (
            <span 
              key={category.id} 
              className="category-badge"
            >
              {category.name}
            </span>
          ))}
        </div>

        <h1 className="font-serif text-3xl font-bold mb-2">{typedSaint.name}</h1>
        <p className="text-slate-600 mb-6">{typedSaint.title}</p>

        {/* Saint Information */}
        <Card className="bg-white rounded-lg shadow-md p-5 mb-6">
          <h2 className="font-serif text-xl font-semibold mb-3">About</h2>
          <p className="text-slate-700 mb-3">{typedSaint.description}</p>
          
          <div className="grid grid-cols-2 gap-4 mt-4 text-sm">
            {typedSaint.feastDay && (
              <div>
                <p className="text-slate-500">Feast Day</p>
                <p className="font-semibold">{typedSaint.feastDay}</p>
              </div>
            )}
            {typedSaint.patronOf && (
              <div>
                <p className="text-slate-500">Patron Of</p>
                <p className="font-semibold">{typedSaint.patronOf}</p>
              </div>
            )}
            {typedSaint.born && (
              <div>
                <p className="text-slate-500">Born</p>
                <p className="font-semibold">{typedSaint.born}</p>
              </div>
            )}
            {typedSaint.died && (
              <div>
                <p className="text-slate-500">Died</p>
                <p className="font-semibold">{typedSaint.died}</p>
              </div>
            )}
          </div>
        </Card>

        {/* Novena Prayer */}
        <Card className="bg-white rounded-lg shadow-md p-5 mb-6">
          <div className="flex justify-between items-center mb-3">
            <h2 className="font-serif text-xl font-semibold">Novena Prayer</h2>
            <button 
              className="text-sm text-primary font-medium flex items-center"
              onClick={() => navigate(`/prayers/edit/${saintId}`)}
            >
              <i className="fas fa-edit mr-1"></i> Edit Daily Prayers
            </button>
          </div>
          <div className="prose prose-slate">
            {typedSaint.prayer.split('\n\n').map((paragraph, index) => (
              <p key={index}>{paragraph}</p>
            ))}
          </div>
        </Card>

        {/* Start Novena Button */}
        <button 
          className="w-full bg-primary text-white font-semibold py-4 rounded-lg mb-6 flex items-center justify-center disabled:opacity-70"
          onClick={() => startNovena.mutate()}
          disabled={startNovena.isPending}
        >
          {startNovena.isPending ? (
            <>Loading...</>
          ) : (
            <>
              <i className="fas fa-pray mr-2"></i> Start Novena
            </>
          )}
        </button>
        
        {/* Testimonials Section */}
        <Card className="bg-white rounded-lg shadow-md p-5 mb-6">
          <TestimonialList 
            saintId={saintId || ""} 
            onAddTestimonial={() => setIsTestimonialFormOpen(true)} 
          />
        </Card>
      </div>

      {/* Testimonial Form Modal */}
      {typedSaint && (
        <TestimonialForm 
          saintId={saintId || ""} 
          saintName={typedSaint.name} 
          isOpen={isTestimonialFormOpen} 
          onClose={() => setIsTestimonialFormOpen(false)} 
        />
      )}

      <BottomNavigation />
    </div>
  );
}

import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation, useRoute } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Upload, Image as ImageIcon, Edit, Users, BookOpen, FolderOpen } from "lucide-react";

interface Testimonial {
  id: number;
  name: string;
  testimonial: string;
  saintName: string;
  saintId: number;
  createdAt: string;
  isApproved: boolean;
}

interface Saint {
  id: number;
  name: string;
  title: string | null;
  description: string;
  feastDay: string | null;
  biography: string | null;
  patronages: string | null;
  createdAt: string;
}

interface Category {
  id: number;
  name: string;
  description: string | null;
  createdAt: string;
}

interface Prayer {
  id: number;
  saintId: number;
  day: number;
  content: string;
  createdAt: string;
}

export default function Admin() {
  const [, navigate] = useLocation();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const [selectedTestimonial, setSelectedTestimonial] = useState<Testimonial | null>(null);
  const [showDialog, setShowDialog] = useState(false);

  // Content editing states
  const [activeTab, setActiveTab] = useState<'images' | 'saints' | 'prayers' | 'categories' | 'testimonials'>('images');
  const [selectedSaint, setSelectedSaint] = useState<Saint | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<Category | null>(null);
  const [selectedPrayer, setSelectedPrayer] = useState<Prayer | null>(null);
  const [editingPrayerDay, setEditingPrayerDay] = useState<number | null>(null);
  // Dialog states (keeping prayer dialog for future use)
  const [showPrayerDialog, setShowPrayerDialog] = useState(false);

  // Image upload states
  const [universalSaintImage, setUniversalSaintImage] = useState<string>("");
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [categoryImage, setCategoryImage] = useState<string>("");
  const [categoryUploading, setCategoryUploading] = useState(false);
  const categoryFileInputRef = useRef<HTMLInputElement>(null);
  
  const [headerImage, setHeaderImage] = useState<string>("");
  const [headerUploading, setHeaderUploading] = useState(false);
  const headerFileInputRef = useRef<HTMLInputElement>(null);

  // Check if user is authenticated admin
  const isAdmin = sessionStorage.getItem('adminAuthenticated') === 'true';
  
  useEffect(() => {
    if (!isAdmin) {
      navigate('/');
    }
  }, [isAdmin, navigate]);

  // Load images from database on component mount
  useEffect(() => {
    if (!isAdmin) return;
    
    const loadImages = async () => {
      try {
        // Load universal saint image
        const universalResponse = await fetch('/api/images/universal-saint');
        if (universalResponse.ok) {
          const universalData = await universalResponse.json();
          setUniversalSaintImage(universalData.url);
        }
        
        // Load category image
        const categoryResponse = await fetch('/api/images/category');
        if (categoryResponse.ok) {
          const categoryData = await categoryResponse.json();
          setCategoryImage(categoryData.url);
        }
        
        // Load header image
        const headerResponse = await fetch('/api/images/header');
        if (headerResponse.ok) {
          const headerData = await headerResponse.json();
          setHeaderImage(headerData.url);
        }
      } catch (error) {
        console.error('Error loading images:', error);
      }
    };

    loadImages();
  }, [isAdmin]);

  // Fetch all testimonials
  const { data: testimonials = [], isLoading } = useQuery<Testimonial[]>({
    queryKey: ['/api/admin/testimonials'],
    enabled: isAdmin
  });

  // Fetch saints for content editing
  const { data: saints = [] } = useQuery<Saint[]>({
    queryKey: ['/api/saints'],
    enabled: activeTab === 'saints' || activeTab === 'prayers',
  });

  // Fetch categories for content editing
  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
    enabled: activeTab === 'categories',
  });

  // Fetch prayers for selected saint
  const { data: prayers = [] } = useQuery<Prayer[]>({
    queryKey: ['/api/prayers', selectedSaint?.id],
    enabled: activeTab === 'prayers' && !!selectedSaint?.id,
  });

  // Event handlers
  const handleLogout = () => {
    sessionStorage.removeItem('adminAuthenticated');
    navigate('/');
  };

  const handleViewTestimonial = (testimonial: Testimonial) => {
    setSelectedTestimonial(testimonial);
    setShowDialog(true);
  };

  if (!isAdmin) {
    return null;
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 p-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center py-8">
            <i className="fas fa-spinner fa-spin text-2xl text-blue-600"></i>
            <p className="mt-2 text-gray-600">Loading admin dashboard...</p>
          </div>
        </div>
      </div>
    );
  }

  const pendingTestimonials = testimonials.filter((t) => !t.isApproved);
  const approvedTestimonials = testimonials.filter((t) => t.isApproved);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 flex items-center">
              <i className="fas fa-shield-alt mr-3 text-blue-600"></i>
              Admin Dashboard
            </h1>
            <p className="text-gray-600 mt-1">Manage content, images, and testimonials</p>
          </div>
          
          <div className="flex space-x-3">
            <Button variant="outline" onClick={() => navigate('/settings')}>
              <i className="fas fa-arrow-left mr-2"></i>
              Back to Settings
            </Button>
            <Button variant="destructive" onClick={handleLogout}>
              <i className="fas fa-sign-out-alt mr-2"></i>
              Logout
            </Button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex space-x-1 mb-6 bg-white rounded-lg p-1 shadow-sm">
          <Button
            variant={activeTab === 'images' ? 'default' : 'ghost'}
            onClick={() => setActiveTab('images')}
            className="flex items-center space-x-2"
          >
            <ImageIcon className="w-4 h-4" />
            <span>Images</span>
          </Button>
          <Button
            variant={activeTab === 'saints' ? 'default' : 'ghost'}
            onClick={() => setActiveTab('saints')}
            className="flex items-center space-x-2"
          >
            <Users className="w-4 h-4" />
            <span>Saints</span>
          </Button>
          <Button
            variant={activeTab === 'prayers' ? 'default' : 'ghost'}
            onClick={() => setActiveTab('prayers')}
            className="flex items-center space-x-2"
          >
            <BookOpen className="w-4 h-4" />
            <span>Prayers</span>
          </Button>
          <Button
            variant={activeTab === 'categories' ? 'default' : 'ghost'}
            onClick={() => setActiveTab('categories')}
            className="flex items-center space-x-2"
          >
            <FolderOpen className="w-4 h-4" />
            <span>Categories</span>
          </Button>
          <Button
            variant={activeTab === 'testimonials' ? 'default' : 'ghost'}
            onClick={() => setActiveTab('testimonials')}
            className="flex items-center space-x-2"
          >
            <Edit className="w-4 h-4" />
            <span>Testimonials</span>
          </Button>
        </div>

        {/* Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="p-6 bg-white">
            <div className="flex items-center">
              <div className="p-3 bg-yellow-100 rounded-full">
                <i className="fas fa-clock text-yellow-600 text-xl"></i>
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Pending Review</p>
                <p className="text-2xl font-bold text-gray-900">{pendingTestimonials.length}</p>
              </div>
            </div>
          </Card>
          
          <Card className="p-6 bg-white">
            <div className="flex items-center">
              <div className="p-3 bg-green-100 rounded-full">
                <i className="fas fa-check-circle text-green-600 text-xl"></i>
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Approved</p>
                <p className="text-2xl font-bold text-gray-900">{approvedTestimonials.length}</p>
              </div>
            </div>
          </Card>
          
          <Card className="p-6 bg-white">
            <div className="flex items-center">
              <div className="p-3 bg-blue-100 rounded-full">
                <i className="fas fa-comments text-blue-600 text-xl"></i>
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total</p>
                <p className="text-2xl font-bold text-gray-900">{testimonials.length}</p>
              </div>
            </div>
          </Card>
        </div>

        {/* Content based on active tab */}
        {activeTab === 'images' && (
          <div className="space-y-6">
            <Card className="p-6 bg-white">
              <h2 className="text-lg font-semibold mb-4 flex items-center text-blue-600">
                <ImageIcon className="w-5 h-5 mr-2" />
                Image Management
              </h2>
              <p className="text-sm text-gray-600 mb-4">
                Upload and manage images for universal saints, categories, and headers.
              </p>
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="text-center p-4 border rounded-lg">
                  <h3 className="font-semibold mb-2">Universal Saint Image</h3>
                  <p className="text-sm text-gray-600">Displayed on all saints</p>
                </div>
                <div className="text-center p-4 border rounded-lg">
                  <h3 className="font-semibold mb-2">Category Image</h3>
                  <p className="text-sm text-gray-600">Background for categories</p>
                </div>
                <div className="text-center p-4 border rounded-lg">
                  <h3 className="font-semibold mb-2">Header Image</h3>
                  <p className="text-sm text-gray-600">Header background</p>
                </div>
              </div>
            </Card>
          </div>
        )}

        {/* Saints Management Tab */}
        {activeTab === 'saints' && (
          <div className="space-y-6">
            <Card className="p-6 bg-white">
              <h2 className="text-lg font-semibold mb-4 flex items-center text-green-600">
                <Users className="w-5 h-5 mr-2" />
                Saints Management
              </h2>
              <p className="text-sm text-gray-600 mb-4">
                Edit saint biographies, descriptions, feast days, and patronages. Select a saint below for quick editing or access the full management interface.
              </p>
              
              <div className="mb-6">
                <Button 
                  onClick={() => navigate('/admin/saints')} 
                  variant="outline"
                  className="w-full md:w-auto"
                >
                  <Users className="w-4 h-4 mr-2" />
                  Access Full Saints Management
                </Button>
              </div>
              
              <div className="space-y-4">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="saint-select">Select Saint to Edit</Label>
                    <Select
                      value={selectedSaint?.id.toString() || ''}
                      onValueChange={(value) => {
                        const saint = saints.find(s => s.id === parseInt(value));
                        setSelectedSaint(saint || null);
                      }}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Choose a saint..." />
                      </SelectTrigger>
                      <SelectContent>
                        {saints.slice(0, 50).map((saint) => (
                          <SelectItem key={saint.id} value={saint.id.toString()}>
                            {saint.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  {selectedSaint && (
                    <div className="flex items-end">
                      <Button onClick={() => navigate(`/admin/saints/edit/${selectedSaint.id}`)} className="w-full">
                        <Edit className="w-4 h-4 mr-2" />
                        Edit {selectedSaint.name}
                      </Button>
                    </div>
                  )}
                </div>
                
                {selectedSaint && (
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h3 className="font-semibold mb-2">{selectedSaint.name}</h3>
                    <p className="text-sm text-gray-600 mb-2">
                      <strong>Description:</strong> {selectedSaint.description.substring(0, 150)}...
                    </p>
                    <p className="text-sm text-gray-600 mb-2">
                      <strong>Feast Day:</strong> {selectedSaint.feastDay || 'Not set'}
                    </p>
                    <p className="text-sm text-gray-600">
                      <strong>Biography:</strong> {selectedSaint.biography?.substring(0, 100) || 'Not set'}...
                    </p>
                  </div>
                )}
              </div>
            </Card>
          </div>
        )}

        {/* Categories Management Tab */}
        {activeTab === 'categories' && (
          <div className="space-y-6">
            <Card className="p-6 bg-white">
              <h2 className="text-lg font-semibold mb-4 flex items-center text-purple-600">
                <FolderOpen className="w-5 h-5 mr-2" />
                Categories Management
              </h2>
              <p className="text-sm text-gray-600 mb-4">
                Edit category names and descriptions to improve organization. Select a category below for quick editing or access the full management interface.
              </p>
              
              <div className="mb-6">
                <Button 
                  onClick={() => navigate('/admin/categories')} 
                  variant="outline"
                  className="w-full md:w-auto"
                >
                  <FolderOpen className="w-4 h-4 mr-2" />
                  Access Full Categories Management
                </Button>
              </div>
              
              <div className="space-y-4">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="category-select">Select Category to Edit</Label>
                    <Select
                      value={selectedCategory?.id.toString() || ''}
                      onValueChange={(value) => {
                        const category = categories.find(c => c.id === parseInt(value));
                        setSelectedCategory(category || null);
                      }}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Choose a category..." />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((category) => (
                          <SelectItem key={category.id} value={category.id.toString()}>
                            {category.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  {selectedCategory && (
                    <div className="flex items-end">
                      <Button onClick={() => navigate(`/admin/categories/edit/${selectedCategory.id}`)} className="w-full">
                        <Edit className="w-4 h-4 mr-2" />
                        Edit {selectedCategory.name}
                      </Button>
                    </div>
                  )}
                </div>
                
                {selectedCategory && (
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h3 className="font-semibold mb-2">{selectedCategory.name}</h3>
                    <p className="text-sm text-gray-600">
                      <strong>Description:</strong> {selectedCategory.description || 'No description set'}
                    </p>
                  </div>
                )}
              </div>
            </Card>
          </div>
        )}

        {/* Prayers Management Tab */}
        {activeTab === 'prayers' && (
          <div className="space-y-6">
            <Card className="p-6 bg-white">
              <h2 className="text-lg font-semibold mb-4 flex items-center text-green-600">
                <BookOpen className="w-5 h-5 mr-2" />
                Prayer Management
              </h2>
              <p className="text-sm text-gray-600 mb-6">
                Access comprehensive prayer management tools for all saints and devotions.
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="p-4 border border-green-200 hover:border-green-300 transition-colors">
                  <div className="text-center">
                    <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <BookOpen className="w-8 h-8 text-green-600" />
                    </div>
                    <h3 className="font-semibold text-lg mb-2">Manage Saint Novenas</h3>
                    <p className="text-sm text-gray-600 mb-4">
                      Edit day-by-day novena prayers for all {saints.length} saints. Customize content for each of the 9 days.
                    </p>
                    <Button 
                      onClick={() => navigate('/admin/prayers')} 
                      className="w-full bg-green-600 hover:bg-green-700"
                    >
                      <Edit className="w-4 h-4 mr-2" />
                      Access Prayer Editor
                    </Button>
                  </div>
                </Card>
                
                <Card className="p-4 border border-blue-200 hover:border-blue-300 transition-colors">
                  <div className="text-center">
                    <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Upload className="w-8 h-8 text-blue-600" />
                    </div>
                    <h3 className="font-semibold text-lg mb-2">Import Novenas</h3>
                    <p className="text-sm text-gray-600 mb-4">
                      Import novena prayers from external sources or documents. Extract and organize prayer content automatically.
                    </p>
                    <Button 
                      onClick={() => navigate('/admin/novena-import')} 
                      variant="outline"
                      className="w-full border-blue-300 text-blue-600 hover:bg-blue-50"
                    >
                      <Upload className="w-4 h-4 mr-2" />
                      Import Novenas
                    </Button>
                  </div>
                </Card>
              </div>
              
              <div className="mt-6 bg-gray-50 p-4 rounded-lg">
                <h3 className="font-semibold mb-2 flex items-center">
                  <i className="fas fa-info-circle mr-2 text-blue-600"></i>
                  Prayer Management Overview
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                  <div>
                    <p className="font-medium text-gray-700">Total Saints</p>
                    <p className="text-2xl font-bold text-blue-600">{saints.length}</p>
                  </div>
                  <div>
                    <p className="font-medium text-gray-700">Special Devotions</p>
                    <p className="text-2xl font-bold text-green-600">5</p>
                    <p className="text-xs text-gray-500">Rosary, Consecration, etc.</p>
                  </div>
                  <div>
                    <p className="font-medium text-gray-700">Quick Actions</p>
                    <div className="flex space-x-2 mt-1">
                      <Button size="sm" variant="outline" onClick={() => navigate('/admin/saints')}>
                        <Users className="w-3 h-3 mr-1" />
                        Saints
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => navigate('/admin/prayers')}>
                        <BookOpen className="w-3 h-3 mr-1" />
                        Prayers
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        )}

        {/* Testimonials Tab */}
        {activeTab === 'testimonials' && (
          <div className="space-y-6">
            <Card className="p-6 bg-white">
              <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
                <i className="fas fa-clock mr-2 text-yellow-600"></i>
                Pending Testimonials ({pendingTestimonials.length})
              </h2>
              
              {pendingTestimonials.length === 0 ? (
                <p className="text-gray-500 text-center py-8">No pending testimonials</p>
              ) : (
                <div className="space-y-4">
                  {pendingTestimonials.slice(0, 10).map((testimonial) => (
                    <div key={testimonial.id} className="border rounded-lg p-4 hover:bg-gray-50">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <h3 className="font-semibold text-gray-900">{testimonial.name}</h3>
                            <Badge variant="secondary">{testimonial.saintName}</Badge>
                            <Badge variant="outline" className="text-yellow-600 border-yellow-600">
                              Pending
                            </Badge>
                          </div>
                          <p className="text-gray-600 line-clamp-2">
                            {testimonial.testimonial.substring(0, 150)}...
                          </p>
                          <p className="text-sm text-gray-400 mt-2">
                            {new Date(testimonial.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleViewTestimonial(testimonial)}
                        >
                          Review
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </Card>
          </div>
        )}

        {/* Basic Dialog for testimonial review */}
        <Dialog open={showDialog} onOpenChange={setShowDialog}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Review Testimonial</DialogTitle>
            </DialogHeader>
            
            {selectedTestimonial && (
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold">{selectedTestimonial.name}</h3>
                  <p className="text-sm text-gray-600">{selectedTestimonial.saintName}</p>
                </div>
                
                <div>
                  <label className="text-sm font-medium text-gray-600">Testimonial</label>
                  <p className="text-gray-900 mt-1">{selectedTestimonial.testimonial}</p>
                </div>
                
                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setShowDialog(false)}>
                    Close
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
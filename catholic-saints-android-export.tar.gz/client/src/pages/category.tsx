import * as React from "react";
import { useLocation, useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Header } from "@/components/layout/header";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { SaintCard } from "@/components/saints/saint-card";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Search, Heart, Users, Sparkles } from "lucide-react";
import { SaintResponse, CategoryResponse } from "@/lib/types";

export default function Category() {
  const params = useParams();
  const [, navigate] = useLocation();
  const categoryId = params.id;
  const [filteredSaints, setFilteredSaints] = React.useState<SaintResponse[]>([]);

  // Fetch category
  const { data: category, isLoading: loadingCategory } = useQuery({
    queryKey: [`/api/categories/${categoryId}`],
  });

  // Fetch saints in this category
  const { data: saints, isLoading: loadingSaints } = useQuery<SaintResponse[]>({
    queryKey: [`/api/categories/${categoryId}/saints`],
  });

  // Handle search
  const handleSearch = (query: string) => {
    if (!saints) return;
    
    if (!query) {
      setFilteredSaints(saints);
      return;
    }
    
    const lowercaseQuery = query.toLowerCase();
    const filtered = saints.filter((saint: SaintResponse) => 
      saint.name.toLowerCase().includes(lowercaseQuery) || 
      saint.description.toLowerCase().includes(lowercaseQuery)
    );
    
    setFilteredSaints(filtered);
  };

  // Set filtered saints when data is loaded
  React.useEffect(() => {
    // Add debug logging
    console.log("Category saints data:", saints);
    if (saints) {
      console.log("Setting filtered saints, length:", Array.isArray(saints) ? saints.length : "not an array");
      setFilteredSaints(saints);
    }
  }, [saints]);

  // Navigate back
  const navigateBack = () => {
    navigate("/");
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <Header onSearch={handleSearch} />

      <main className="flex-grow mt-14 mb-16">
        <div className="container mx-auto px-4 py-6">
          {/* Modern Category Header */}
          <div className="mb-8">
            <div className="flex items-center gap-4 mb-6">
              <Button
                variant="ghost"
                size="sm"
                onClick={navigateBack}
                className="h-12 w-12 p-0 rounded-full bg-white/80 backdrop-blur-sm shadow-lg hover:bg-white/90 border-0"
              >
                <ArrowLeft className="w-5 h-5" />
              </Button>
              
              <div className="flex-1">
                <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-2">
                  {loadingCategory ? "Loading..." : (category as CategoryResponse)?.name}
                </h1>
                <div className="h-1 w-20 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full"></div>
              </div>
            </div>

            {/* Category Stats Card */}
            {!loadingSaints && filteredSaints && (
              <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl rounded-2xl p-6 mb-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                      <Users className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-slate-800">{filteredSaints.length}</p>
                      <p className="text-slate-600">Sacred Saints</p>
                    </div>
                  </div>
                  
                  <Badge className="bg-gradient-to-r from-blue-100 to-purple-100 text-blue-700 border-0 px-4 py-2 rounded-full">
                    <Heart className="w-4 h-4 mr-2" />
                    Ready for Prayer
                  </Badge>
                </div>
              </Card>
            )}
          </div>

          {/* Saints Grid */}
          {loadingSaints ? (
            <div className="flex flex-col items-center justify-center py-16">
              <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center mb-4 animate-pulse">
                <Sparkles className="w-8 h-8 text-white" />
              </div>
              <p className="text-slate-600 text-lg font-medium">Discovering sacred saints...</p>
              <p className="text-slate-400 text-sm mt-1">Please wait while we prepare your spiritual journey</p>
            </div>
          ) : filteredSaints && filteredSaints.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredSaints.map((saint) => (
                <SaintCard 
                  key={saint.id} 
                  saint={{
                    ...saint,
                    categoryName: (category as CategoryResponse)?.name
                  }}
                />
              ))}
            </div>
          ) : (
            <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl rounded-2xl p-12 text-center">
              <div className="flex flex-col items-center">
                <div className="w-20 h-20 bg-gradient-to-r from-slate-200 to-slate-300 rounded-full flex items-center justify-center mb-6">
                  <Search className="w-10 h-10 text-slate-500" />
                </div>
                <h3 className="text-2xl font-bold text-slate-800 mb-3">No Saints Found</h3>
                <p className="text-slate-600 text-lg leading-relaxed mb-4 max-w-md">
                  We couldn't find any saints in this category matching your search.
                </p>
                <p className="text-slate-500">
                  Try adjusting your search or explore another category to discover more saints.
                </p>
              </div>
            </Card>
          )}
        </div>
      </main>

      <BottomNavigation />
    </div>
  );
}

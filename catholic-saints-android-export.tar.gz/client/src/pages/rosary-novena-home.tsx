import * as React from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Header } from "@/components/layout/header";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { Calendar, Clock, Heart, Star, CheckCircle2, Circle, Crown, BookOpen, Scroll, Church, Shield, Sparkles, Gift, Flower, Users, Gem, MapPin, Baby, Quote, Target, Zap, Timer } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { RosaryNovena } from "@shared/schema";



export default function RosaryNovenaHome() {
  const [, navigate] = useLocation();
  const { toast } = useToast();

  // Fetch rosary novena information (origin, method, promises)
  const { data: novenaInfo = [] } = useQuery({
    queryKey: ["/api/rosary-novena-info"],
    queryFn: async () => {
      const response = await fetch("/api/rosary-novena-info");
      if (!response.ok) throw new Error("Failed to fetch novena info");
      return response.json();
    }
  });

  // Extract specific info pieces safely
  const originInfo = Array.isArray(novenaInfo) ? novenaInfo.find((info: any) => info.type === 'origin') : null;
  const methodInfo = Array.isArray(novenaInfo) ? novenaInfo.find((info: any) => info.type === 'method') : null;
  const promisesInfo = Array.isArray(novenaInfo) ? novenaInfo.find((info: any) => info.type === 'promises') : null;
  const noteInfo = Array.isArray(novenaInfo) ? novenaInfo.find((info: any) => info.type === 'note') : null;

  // Check for existing 54-day novena
  const { data: existingNovena, isLoading } = useQuery<RosaryNovena | null>({
    queryKey: ['/api/rosary-novenas/current'],
  });

  // Start new 54-day novena
  const startNovena = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/rosary-novenas', {});
      if (!response.ok) {
        let errorText = response.statusText;
        try {
          const errorData = await response.text();
          errorText = errorData || response.statusText;
        } catch (e) {
          // If we can't read the response text, use statusText
        }
        throw new Error(`${response.status}: ${errorText}`);
      }
      return await response.json();
    },
    onSuccess: (novena: any) => {
      queryClient.invalidateQueries({ queryKey: ['/api/rosary-novenas'] });
      toast({
        title: "54-Day Rosary Novena Started",
        description: "Your journey of petition and thanksgiving begins today.",
      });
      navigate(`/rosary-novena/${novena.id}`);
    },
    onError: (error: Error) => {
      console.error("Failed to start rosary novena:", error);
      toast({
        title: "Error",
        description: `Unable to start novena: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const handleStartNovena = () => {
    startNovena.mutate();
  };

  const handleContinueNovena = () => {
    if (existingNovena) {
      navigate(`/rosary-novena/${existingNovena.id}`);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
        <Header />
        <main className="container mx-auto px-4 py-6 pb-20">
          <div className="flex items-center justify-center min-h-[400px]">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
          </div>
        </main>
        <BottomNavigation />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <Header />
      
      <main className="container mx-auto px-4 py-6 pb-20">
        {/* Hero Section */}
        <div className="text-center mb-8">
          <div className="mb-6">
            <div className="w-24 h-24 mx-auto bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center shadow-lg mb-4">
              <Crown className="w-12 h-12 text-white" />
            </div>
          </div>
          
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            54-Day Rosary Novena
          </h1>
          <p className="text-xl text-gray-600 mb-2">
            To the Blessed Virgin Mary
          </p>
          <p className="text-lg text-gray-500 max-w-2xl mx-auto">
            A powerful spiritual journey of 27 days of petition followed by 27 days of thanksgiving, 
            blessed by the intercession of Our Lady.
          </p>
        </div>

        {/* Prominent Continue/Start Section */}
        {existingNovena ? (
          <Card className="p-8 mb-8 bg-gradient-to-r from-indigo-50 to-purple-50 border-indigo-200 shadow-lg">
            <div className="text-center">
              <div className="mb-6">
                <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Clock className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-2xl font-bold text-indigo-800 mb-2">Continue Your Journey</h2>
                <p className="text-indigo-600">Your 54-day novena is in progress</p>
              </div>
              
              <div className="mb-6">
                <div className="flex items-center justify-center gap-2 mb-3">
                  <Calendar className="w-5 h-5 text-indigo-600" />
                  <span className="text-lg font-semibold text-indigo-700">
                    Day {existingNovena?.currentDay || 1} of 54
                  </span>
                </div>
                
                <Progress 
                  value={((existingNovena?.currentDay || 1) / 54) * 100} 
                  className="w-full max-w-md mx-auto mb-4"
                />
                
                <div className="flex justify-center">
                  {(existingNovena?.currentDay || 1) <= 27 ? (
                    <Badge variant="secondary" className="bg-rose-100 text-rose-700 px-4 py-2">
                      <Heart className="w-4 h-4 mr-2" />
                      Phase 1: Petition
                    </Badge>
                  ) : (
                    <Badge variant="secondary" className="bg-emerald-100 text-emerald-700 px-4 py-2">
                      <Sparkles className="w-4 h-4 mr-2" />
                      Phase 2: Thanksgiving
                    </Badge>
                  )}
                </div>
              </div>

              <Button 
                onClick={handleContinueNovena}
                size="lg" 
                className="bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-4 text-lg font-semibold shadow-lg"
              >
                <Clock className="w-5 h-5 mr-2" />
                Continue Today's Prayer
              </Button>
            </div>
          </Card>
        ) : (
          <Card className="p-8 mb-8 bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200 shadow-lg">
            <div className="text-center">
              <div className="mb-6">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Heart className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-2xl font-bold text-blue-800 mb-2">Begin Your 54-Day Journey</h2>
                <p className="text-blue-600">Start this beautiful tradition of prayer and devotion</p>
              </div>
              
              <p className="text-gray-600 mb-6 max-w-md mx-auto">
                Start this beautiful tradition of prayer, combining petition and thanksgiving 
                in a complete cycle of devotion to Our Lady.
              </p>
              
              <Button 
                onClick={handleStartNovena}
                disabled={startNovena.isPending}
                size="lg" 
                className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 text-lg font-semibold shadow-lg"
              >
                {startNovena.isPending ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Starting...
                  </>
                ) : (
                  <>
                    <Heart className="w-5 h-5 mr-2" />
                    Start 54-Day Novena
                  </>
                )}
              </Button>
            </div>
          </Card>
        )}

        {/* Information Tabs */}
        <div className="mb-8">
          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="grid w-full grid-cols-4 mb-6">
              <TabsTrigger value="overview" className="flex items-center gap-2">
                <Heart className="w-4 h-4" />
                Overview
              </TabsTrigger>
              <TabsTrigger value="origin" className="flex items-center gap-2">
                <Scroll className="w-4 h-4" />
                Origin
              </TabsTrigger>
              <TabsTrigger value="method" className="flex items-center gap-2">
                <BookOpen className="w-4 h-4" />
                Method
              </TabsTrigger>
              <TabsTrigger value="promises" className="flex items-center gap-2">
                <Church className="w-4 h-4" />
                Promises
              </TabsTrigger>
            </TabsList>

            <TabsContent value="overview">
              <div className="space-y-6">
                {/* Header */}
                <Card className="p-6 bg-gradient-to-r from-indigo-50 to-blue-50 border-indigo-200">
                  <div className="text-center">
                    <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Heart className="w-8 h-8 text-white" />
                    </div>
                    <h3 className="text-2xl font-bold text-indigo-800 mb-2">
                      The 54-Day Rosary Novena
                    </h3>
                    <p className="text-indigo-600">
                      A complete spiritual journey of petition and thanksgiving
                    </p>
                  </div>
                </Card>

                {/* What Is It */}
                <Card className="p-6 bg-gradient-to-r from-teal-50 to-cyan-50 border-teal-200">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-teal-500 rounded-full flex items-center justify-center flex-shrink-0">
                      <Target className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h4 className="text-xl font-bold text-teal-800 mb-3">What Is the 54-Day Rosary Novena?</h4>
                      <p className="text-teal-700 leading-relaxed mb-4">
                        This beautiful devotion consists of saying the <strong>Rosary for 54 consecutive days</strong>: 
                        27 days of petition followed immediately by 27 days of thanksgiving, regardless 
                        of whether your prayers appear to be answered.
                      </p>
                      <div className="grid md:grid-cols-2 gap-4">
                        <div className="bg-teal-100 p-4 rounded-lg">
                          <div className="flex items-center gap-2 mb-2">
                            <Calendar className="w-4 h-4 text-teal-700" />
                            <span className="font-semibold text-teal-800">Duration:</span>
                          </div>
                          <p className="text-teal-700 text-sm">54 consecutive days of prayer</p>
                        </div>
                        <div className="bg-teal-100 p-4 rounded-lg">
                          <div className="flex items-center gap-2 mb-2">
                            <Timer className="w-4 h-4 text-teal-700" />
                            <span className="font-semibold text-teal-800">Structure:</span>
                          </div>
                          <p className="text-teal-700 text-sm">27 days petition + 27 days thanksgiving</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </Card>

                {/* Origin & Authority */}
                <Card className="p-6 bg-gradient-to-r from-purple-50 to-violet-50 border-purple-200">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-purple-500 rounded-full flex items-center justify-center flex-shrink-0">
                      <Crown className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h4 className="text-xl font-bold text-purple-800 mb-3">Divine Origin & Church Recognition</h4>
                      <p className="text-purple-700 leading-relaxed mb-4">
                        The 54-Day Rosary Novena originated from an <strong>apparition of Our Lady of Pompeii in 1884</strong>. 
                        This devotion demonstrates complete trust in God's providence and Mary's maternal intercession.
                      </p>
                      <div className="bg-purple-100 p-4 rounded-lg">
                        <div className="flex items-center gap-2 mb-2">
                          <Church className="w-4 h-4 text-purple-700" />
                          <span className="font-semibold text-purple-800">Papal Recognition:</span>
                        </div>
                        <p className="text-purple-700 text-sm">
                          Pope Leo XIII was deeply moved by this miracle and promoted Rosary devotion throughout the Church
                        </p>
                      </div>
                    </div>
                  </div>
                </Card>

                {/* Key Features */}
                <Card className="p-6 bg-gradient-to-r from-rose-50 to-pink-50 border-rose-200">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-rose-500 rounded-full flex items-center justify-center flex-shrink-0">
                      <Zap className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h4 className="text-xl font-bold text-rose-800 mb-3">Powerful Spiritual Features</h4>
                      <div className="grid md:grid-cols-2 gap-4">
                        <div className="space-y-3">
                          <div className="bg-rose-100 p-3 rounded-lg">
                            <div className="flex items-center gap-2 mb-1">
                              <Star className="w-4 h-4 text-rose-700" />
                              <span className="font-semibold text-rose-800 text-sm">Complete Trust</span>
                            </div>
                            <p className="text-rose-700 text-xs">
                              Thanksgiving regardless of perceived outcomes
                            </p>
                          </div>
                          <div className="bg-rose-100 p-3 rounded-lg">
                            <div className="flex items-center gap-2 mb-1">
                              <Heart className="w-4 h-4 text-rose-700" />
                              <span className="font-semibold text-rose-800 text-sm">Maternal Intercession</span>
                            </div>
                            <p className="text-rose-700 text-xs">
                              Mary's powerful advocacy for all intentions
                            </p>
                          </div>
                        </div>
                        <div className="space-y-3">
                          <div className="bg-rose-100 p-3 rounded-lg">
                            <div className="flex items-center gap-2 mb-1">
                              <Shield className="w-4 h-4 text-rose-700" />
                              <span className="font-semibold text-rose-800 text-sm">Proven Results</span>
                            </div>
                            <p className="text-rose-700 text-xs">
                              Centuries of answered prayers and miracles
                            </p>
                          </div>
                          <div className="bg-rose-100 p-3 rounded-lg">
                            <div className="flex items-center gap-2 mb-1">
                              <Sparkles className="w-4 h-4 text-rose-700" />
                              <span className="font-semibold text-rose-800 text-sm">Spiritual Growth</span>
                            </div>
                            <p className="text-rose-700 text-xs">
                              Deepens relationship with Jesus and Mary
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </Card>

                {/* Perfect For */}
                <Card className="p-6 bg-gradient-to-r from-emerald-50 to-green-50 border-emerald-200">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-emerald-500 rounded-full flex items-center justify-center flex-shrink-0">
                      <Users className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h4 className="text-xl font-bold text-emerald-800 mb-3">Perfect For Those Seeking</h4>
                      <div className="grid md:grid-cols-3 gap-4">
                        <div className="bg-emerald-100 p-4 rounded-lg text-center">
                          <div className="w-8 h-8 bg-emerald-500 rounded-full flex items-center justify-center mx-auto mb-2">
                            <Heart className="w-4 h-4 text-white" />
                          </div>
                          <h5 className="font-semibold text-emerald-800 mb-1">Healing</h5>
                          <p className="text-emerald-700 text-xs">Physical, emotional, or spiritual restoration</p>
                        </div>
                        <div className="bg-emerald-100 p-4 rounded-lg text-center">
                          <div className="w-8 h-8 bg-emerald-500 rounded-full flex items-center justify-center mx-auto mb-2">
                            <Target className="w-4 h-4 text-white" />
                          </div>
                          <h5 className="font-semibold text-emerald-800 mb-1">Guidance</h5>
                          <p className="text-emerald-700 text-xs">Life decisions and discernment</p>
                        </div>
                        <div className="bg-emerald-100 p-4 rounded-lg text-center">
                          <div className="w-8 h-8 bg-emerald-500 rounded-full flex items-center justify-center mx-auto mb-2">
                            <Shield className="w-4 h-4 text-white" />
                          </div>
                          <h5 className="font-semibold text-emerald-800 mb-1">Protection</h5>
                          <p className="text-emerald-700 text-xs">Family, spiritual, and material needs</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </Card>

                {/* Mary's Promise */}
                <Card className="p-6 bg-gradient-to-r from-amber-50 to-yellow-50 border-amber-200">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-amber-500 rounded-full flex items-center justify-center flex-shrink-0">
                      <Quote className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h4 className="text-xl font-bold text-amber-800 mb-3">Our Lady's Promise</h4>
                      <div className="bg-amber-100 p-4 rounded-lg">
                        <p className="text-amber-800 font-medium mb-2 text-center">The Queen of the Holy Rosary said:</p>
                        <blockquote className="text-amber-700 text-sm italic text-center border-l-4 border-amber-400 pl-4">
                          "Whoever desires to obtain favors from me should make three novenas of the prayers of the Rosary, 
                          and three novenas in thanksgiving."
                        </blockquote>
                      </div>
                      <div className="mt-4 text-center">
                        <p className="text-amber-700 text-sm">
                          <strong>3 Novenas = 27 Days</strong> • Combined total: <strong>54 Days</strong> of grace and blessing
                        </p>
                      </div>
                    </div>
                  </div>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="origin">
              {originInfo ? (
                <div className="space-y-6">
                  {/* Header */}
                  <Card className="p-6 bg-gradient-to-r from-violet-50 to-purple-50 border-violet-200">
                    <div className="text-center">
                      <div className="w-16 h-16 bg-gradient-to-br from-violet-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Scroll className="w-8 h-8 text-white" />
                      </div>
                      <h3 className="text-2xl font-bold text-violet-800 mb-2">
                        Origin of the 54-Day Rosary Novena
                      </h3>
                      <p className="text-violet-600">
                        The miraculous apparition of Our Lady of Pompeii in 1884
                      </p>
                    </div>
                  </Card>

                  {/* Timeline Story */}
                  <div className="grid gap-6">
                    {/* Background */}
                    <Card className="p-6 bg-gradient-to-r from-amber-50 to-orange-50 border-amber-200">
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 bg-amber-500 rounded-full flex items-center justify-center flex-shrink-0">
                          <Clock className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <h4 className="text-xl font-bold text-amber-800 mb-3">The Beginning</h4>
                          <p className="text-amber-700 leading-relaxed mb-4">
                            This devotion, which the author has called the <strong>'Rosary Novenas to Our Lady,'</strong> is of comparatively recent origin. 
                            In an apparition of Our Lady of Pompeii, which occurred in <strong>1884 at Naples</strong>, 
                            in the house of Commander Agrelli, the heavenly Mother deigned to make known the manner in which she desires to be invoked.
                          </p>
                          <div className="bg-amber-100 p-4 rounded-lg">
                            <div className="flex items-center gap-2 mb-2">
                              <MapPin className="w-4 h-4 text-amber-700" />
                              <span className="font-semibold text-amber-800">Location:</span>
                            </div>
                            <p className="text-amber-700 text-sm">Naples, Italy - House of Commander Agrelli</p>
                          </div>
                        </div>
                      </div>
                    </Card>

                    {/* The Suffering */}
                    <Card className="p-6 bg-gradient-to-r from-red-50 to-rose-50 border-red-200">
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 bg-red-500 rounded-full flex items-center justify-center flex-shrink-0">
                          <Heart className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <h4 className="text-xl font-bold text-red-800 mb-3">Fortuna's Suffering</h4>
                          <p className="text-red-700 leading-relaxed mb-4">
                            For <strong>thirteen months</strong> Fortuna Agrelli, the daughter of the Commander, had endured dreadful sufferings and torturous cramps; 
                            she had been given up by the most celebrated physicians. On <strong>February 16, 1884</strong>, 
                            the afflicted girl and her relatives commenced a novena of Rosaries.
                          </p>
                          <div className="bg-red-100 p-4 rounded-lg">
                            <p className="text-red-700 text-sm">
                              <strong>13 months</strong> of suffering • <strong>February 16, 1884</strong> - Novena begins
                            </p>
                          </div>
                        </div>
                      </div>
                    </Card>

                    {/* The Apparition */}
                    <Card className="p-6 bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0">
                          <Crown className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <h4 className="text-xl font-bold text-blue-800 mb-3">The Vision - March 3, 1884</h4>
                          <div className="space-y-4">
                            <p className="text-blue-700 leading-relaxed">
                              The Queen of the Holy Rosary favored her with an apparition on <strong>March 3rd</strong>. 
                              Mary, sitting upon a high throne, surrounded by luminous figures, held the divine Child on her lap, and in her hand a Rosary.
                            </p>
                            <div className="bg-blue-100 p-4 rounded-lg">
                              <h5 className="font-semibold text-blue-800 mb-2">The Heavenly Scene:</h5>
                              <ul className="text-blue-700 text-sm space-y-1">
                                <li>• Mary on a high throne with the Divine Child</li>
                                <li>• Gold-embroidered garments shining with light</li>
                                <li>• Rosary in her hand</li>
                                <li>• St. Dominic and St. Catherine of Siena present</li>
                                <li>• Throne decorated with flowers</li>
                                <li>• Marvelous beauty beyond description</li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                    </Card>

                    {/* The Conversation */}
                    <Card className="p-6 bg-gradient-to-r from-emerald-50 to-green-50 border-emerald-200">
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 bg-emerald-500 rounded-full flex items-center justify-center flex-shrink-0">
                          <Quote className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <h4 className="text-xl font-bold text-emerald-800 mb-3">The Sacred Dialogue</h4>
                          <div className="space-y-4">
                            <div className="bg-emerald-100 p-4 rounded-lg">
                              <p className="text-emerald-800 font-medium mb-2">Fortuna's Plea:</p>
                              <p className="text-emerald-700 text-sm italic">
                                "Queen of the Holy Rosary, be gracious to me; restore me to health! I have already prayed to thee in a novena, O Mary, 
                                but have not yet experienced thy aid. I am so anxious to be cured!"
                              </p>
                            </div>
                            <div className="bg-emerald-200 p-4 rounded-lg">
                              <p className="text-emerald-800 font-medium mb-2">Mary's Loving Response:</p>
                              <p className="text-emerald-700 text-sm italic">
                                "Child, thou hast invoked me by various titles and hast always obtained favors from me. Now, since thou hast called me by that title so pleasing to me, 
                                <strong>'Queen of the Holy Rosary,'</strong> I can no longer refuse the favor thou dost petition; for this name is most precious and dear to me. 
                                <strong>Make three novenas, and thou shalt obtain all.</strong>"
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </Card>

                    {/* The Instructions */}
                    <Card className="p-6 bg-gradient-to-r from-purple-50 to-violet-50 border-purple-200">
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 bg-purple-500 rounded-full flex items-center justify-center flex-shrink-0">
                          <Sparkles className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <h4 className="text-xl font-bold text-purple-800 mb-3">The Second Apparition</h4>
                          <p className="text-purple-700 leading-relaxed mb-4">
                            Once more the Queen of the Holy Rosary appeared to her and said:
                          </p>
                          <div className="bg-purple-100 p-4 rounded-lg">
                            <p className="text-purple-800 font-medium mb-2">Our Lady's Final Instructions:</p>
                            <p className="text-purple-700 text-sm italic">
                              <strong>"Whoever desires to obtain favors from me should make three novenas of the prayers of the Rosary, 
                              and three novenas in thanksgiving."</strong>
                            </p>
                          </div>
                          <div className="mt-4 bg-purple-50 p-4 rounded-lg">
                            <p className="text-purple-700 text-sm">
                              <strong>This became the foundation</strong> of the 54-Day Rosary Novena: 
                              27 days in petition + 27 days in thanksgiving = 54 days total
                            </p>
                          </div>
                        </div>
                      </div>
                    </Card>

                    {/* Papal Recognition */}
                    <Card className="p-6 bg-gradient-to-r from-yellow-50 to-amber-50 border-yellow-200">
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 bg-yellow-500 rounded-full flex items-center justify-center flex-shrink-0">
                          <Crown className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <h4 className="text-xl font-bold text-yellow-800 mb-3">Papal Recognition</h4>
                          <p className="text-yellow-700 leading-relaxed mb-4">
                            This miracle of the Rosary made a very deep impression on <strong>Pope Leo XIII</strong>, 
                            and greatly contributed to the fact that in so many circular letters he urged all Christians to love the Rosary and say it fervently.
                          </p>
                          <div className="bg-yellow-100 p-4 rounded-lg">
                            <div className="flex items-center gap-2 mb-2">
                              <Users className="w-4 h-4 text-yellow-700" />
                              <span className="font-semibold text-yellow-800">Church Authority:</span>
                            </div>
                            <p className="text-yellow-700 text-sm">
                              Pope Leo XIII was so moved by this miracle that he promoted Rosary devotion throughout the Catholic Church
                            </p>
                          </div>
                        </div>
                      </div>
                    </Card>

                    {/* Ecclesiastical Note */}
                    <Card className="p-6 bg-gradient-to-r from-gray-50 to-slate-50 border-gray-200">
                      <div className="flex items-start gap-4">
                        <div className="w-10 h-10 bg-gray-500 rounded-full flex items-center justify-center flex-shrink-0">
                          <Church className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <h4 className="font-bold text-gray-800 mb-2">Ecclesiastical Note</h4>
                          <p className="text-gray-700 text-sm leading-relaxed mb-2">
                            In obedience to the decree of Pope Urban VIII and of other Supreme Pontiffs, the author begs to state that, 
                            in regard to what is herein narrated, no higher authority is claimed than that which is due to all authentic human testimony.
                          </p>
                          <p className="text-gray-600 text-xs italic">
                            ¹ The Rosary, My Treasure, Benedictine Convent, Clyde, Mo.
                          </p>
                        </div>
                      </div>
                    </Card>
                  </div>
                </div>
              ) : (
                <Card className="p-6">
                  <p className="text-gray-500">Loading origin information...</p>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="method">
              {methodInfo ? (
                <div className="space-y-6">
                  {/* Header */}
                  <Card className="p-6 bg-gradient-to-r from-emerald-50 to-green-50 border-emerald-200">
                    <div className="text-center">
                      <div className="w-16 h-16 bg-gradient-to-br from-emerald-500 to-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                        <BookOpen className="w-8 h-8 text-white" />
                      </div>
                      <h3 className="text-2xl font-bold text-emerald-800 mb-2">
                        How to Pray the 54-Day Rosary Novena
                      </h3>
                      <p className="text-emerald-600">
                        A structured guide for your spiritual journey
                      </p>
                    </div>
                  </Card>

                  {/* Method Steps */}
                  <div className="grid gap-6">
                    {/* Step 1: Basic Structure */}
                    <Card className="p-6 bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0">
                          <Calendar className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <h4 className="text-xl font-bold text-blue-800 mb-3">Daily Structure</h4>
                          <p className="text-blue-700 leading-relaxed mb-4">
                            The Novena consists of <strong>five decades of the Rosary</strong> each day for twenty-seven days in petition; 
                            then immediately <strong>five decades each day</strong> for twenty-seven days in thanksgiving, 
                            whether or not the request has been granted.
                          </p>
                          <div className="grid md:grid-cols-2 gap-4">
                            <div className="bg-blue-100 p-4 rounded-lg">
                              <div className="font-semibold text-blue-800 mb-2">Days 1-27: Petition</div>
                              <p className="text-blue-700 text-sm">Present your requests with faith and humility</p>
                            </div>
                            <div className="bg-blue-100 p-4 rounded-lg">
                              <div className="font-semibold text-blue-800 mb-2">Days 28-54: Thanksgiving</div>
                              <p className="text-blue-700 text-sm">Express gratitude regardless of outcome</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </Card>

                    {/* Step 2: Mystery Rotation */}
                    <Card className="p-6 bg-gradient-to-r from-purple-50 to-violet-50 border-purple-200">
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 bg-purple-500 rounded-full flex items-center justify-center flex-shrink-0">
                          <Star className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <h4 className="text-xl font-bold text-purple-800 mb-3">Mystery Meditation Pattern</h4>
                          <p className="text-purple-700 leading-relaxed mb-4">
                            The meditations vary from day to day in a beautiful three-day cycle that repeats throughout the entire novena.
                          </p>
                          <div className="grid md:grid-cols-3 gap-4">
                            <div className="bg-purple-100 p-4 rounded-lg text-center">
                              <div className="font-semibold text-purple-800 mb-2">Day 1, 4, 7...</div>
                              <div className="text-2xl mb-2">😊</div>
                              <p className="text-purple-700 text-sm">Joyful Mysteries</p>
                            </div>
                            <div className="bg-purple-100 p-4 rounded-lg text-center">
                              <div className="font-semibold text-purple-800 mb-2">Day 2, 5, 8...</div>
                              <div className="text-2xl mb-2">✝️</div>
                              <p className="text-purple-700 text-sm">Sorrowful Mysteries</p>
                            </div>
                            <div className="bg-purple-100 p-4 rounded-lg text-center">
                              <div className="font-semibold text-purple-800 mb-2">Day 3, 6, 9...</div>
                              <div className="text-2xl mb-2">👑</div>
                              <p className="text-purple-700 text-sm">Glorious Mysteries</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </Card>

                    {/* Step 3: Trust and Perseverance */}
                    <Card className="p-6 bg-gradient-to-r from-rose-50 to-pink-50 border-rose-200">
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 bg-rose-500 rounded-full flex items-center justify-center flex-shrink-0">
                          <Heart className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <h4 className="text-xl font-bold text-rose-800 mb-3">A Novena of Love</h4>
                          <div className="space-y-3">
                            <p className="text-rose-700 leading-relaxed">
                              A laborious Novena, but a <strong>Novena of Love</strong>. You who are sincere will not find it too difficult, 
                              if you really wish to obtain your request.
                            </p>
                            <div className="bg-rose-100 p-4 rounded-lg">
                              <p className="text-rose-700 text-sm font-medium mb-2">Divine Assurance:</p>
                              <p className="text-rose-700 text-sm italic">
                                "Should you not obtain the favor you seek, be assured that the Rosary Queen, who knows what each one stands most in need of, 
                                has heard your prayer. You will not have prayed in vain. No prayer ever went unheard. And Our Blessed Lady has never been known to fail."
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </Card>

                    {/* Step 4: Spiritual Roses */}
                    <Card className="p-6 bg-gradient-to-r from-amber-50 to-yellow-50 border-amber-200">
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 bg-amber-500 rounded-full flex items-center justify-center flex-shrink-0">
                          <Flower className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <h4 className="text-xl font-bold text-amber-800 mb-3">Spiritual Roses</h4>
                          <p className="text-amber-700 leading-relaxed mb-4">
                            Look upon each <strong>Hail Mary</strong> as a rare and beautiful rose which you lay at Mary's feet. 
                            These spiritual roses, bound in a wreath with Spiritual Communions, will be a most pleasing and acceptable gift to her, 
                            and will bring down upon you special graces.
                          </p>
                          <div className="bg-amber-100 p-4 rounded-lg">
                            <div className="flex items-center gap-2 mb-2">
                              <Users className="w-4 h-4 text-amber-700" />
                              <span className="font-semibold text-amber-800">Enhance Your Offering:</span>
                            </div>
                            <p className="text-amber-700 text-sm">
                              Each Hail Mary = A Beautiful Rose 🌹<br/>
                              + Spiritual Communions = A Complete Wreath 💐
                            </p>
                          </div>
                        </div>
                      </div>
                    </Card>

                    {/* Step 5: Spiritual Diamonds */}
                    <Card className="p-6 bg-gradient-to-r from-cyan-50 to-blue-50 border-cyan-200">
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 bg-cyan-500 rounded-full flex items-center justify-center flex-shrink-0">
                          <Gem className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <h4 className="text-xl font-bold text-cyan-800 mb-3">Spiritual Diamonds</h4>
                          <p className="text-cyan-700 leading-relaxed mb-4">
                            If you would reach the innermost recesses of her heart, lavishly bedeck your wreath with <strong>spiritual diamonds</strong>—holy communions. 
                            Then her joy will be unbounded, and she will open wide the channel of her choicest graces to you.
                          </p>
                          <div className="bg-cyan-100 p-4 rounded-lg">
                            <div className="flex items-center gap-2 mb-2">
                              <Sparkles className="w-4 h-4 text-cyan-700" />
                              <span className="font-semibold text-cyan-800">The Ultimate Gift:</span>
                            </div>
                            <p className="text-cyan-700 text-sm">
                              Spiritual Roses (Hail Marys) + Spiritual Diamonds (Holy Communions) = 
                              <strong> Mary's Unbounded Joy</strong> and the channel of her choicest graces 💎
                            </p>
                          </div>
                        </div>
                      </div>
                    </Card>
                  </div>

                  {/* Ecclesiastical Note */}
                  {noteInfo && (
                    <Card className="p-6 bg-gradient-to-r from-amber-50 to-orange-50 border-amber-200">
                      <div className="flex items-start gap-4">
                        <div className="w-10 h-10 bg-amber-500 rounded-full flex items-center justify-center flex-shrink-0">
                          <Church className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <h4 className="font-bold text-amber-800 mb-2">
                            {noteInfo.title}
                          </h4>
                          <p className="text-amber-700 text-sm leading-relaxed">
                            {noteInfo.content}
                          </p>
                        </div>
                      </div>
                    </Card>
                  )}
                </div>
              ) : (
                <Card className="p-6">
                  <p className="text-gray-500">Loading method information...</p>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="promises">
              {promisesInfo ? (
                <div className="space-y-6">
                  {/* Header */}
                  <Card className="p-6 bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
                    <div className="text-center">
                      <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Crown className="w-8 h-8 text-white" />
                      </div>
                      <h3 className="text-2xl font-bold text-blue-800 mb-2">
                        The 15 Promises of Our Lady
                      </h3>
                      <p className="text-blue-600">
                        Made by the Blessed Virgin to St. Dominic and Blessed Alan
                      </p>
                    </div>
                  </Card>

                  {/* Promises Grid */}
                  <div className="grid gap-4">
                    {/* Promise 1 */}
                    <Card className="p-5 bg-gradient-to-r from-rose-50 to-pink-50 border-rose-200 hover:shadow-lg transition-shadow">
                      <div className="flex items-start gap-4">
                        <div className="w-10 h-10 bg-rose-500 rounded-full flex items-center justify-center flex-shrink-0">
                          <Shield className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <div className="font-bold text-rose-800 mb-1">Promise 1</div>
                          <p className="text-rose-700 text-sm leading-relaxed">
                            To all those who will recite my Rosary devoutly, I promise my special protection and very great graces.
                          </p>
                        </div>
                      </div>
                    </Card>

                    {/* Promise 2 */}
                    <Card className="p-5 bg-gradient-to-r from-amber-50 to-orange-50 border-amber-200 hover:shadow-lg transition-shadow">
                      <div className="flex items-start gap-4">
                        <div className="w-10 h-10 bg-amber-500 rounded-full flex items-center justify-center flex-shrink-0">
                          <Star className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <div className="font-bold text-amber-800 mb-1">Promise 2</div>
                          <p className="text-amber-700 text-sm leading-relaxed">
                            Those who will persevere in the recitation of my Rosary shall receive some signal grace.
                          </p>
                        </div>
                      </div>
                    </Card>

                    {/* Promise 3 */}
                    <Card className="p-5 bg-gradient-to-r from-purple-50 to-violet-50 border-purple-200 hover:shadow-lg transition-shadow">
                      <div className="flex items-start gap-4">
                        <div className="w-10 h-10 bg-purple-500 rounded-full flex items-center justify-center flex-shrink-0">
                          <Shield className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <div className="font-bold text-purple-800 mb-1">Promise 3</div>
                          <p className="text-purple-700 text-sm leading-relaxed">
                            The Rosary shall be a very powerful armor against hell; it shall destroy vice, deliver from sin, and shall dispel heresy.
                          </p>
                        </div>
                      </div>
                    </Card>

                    {/* Promise 4 */}
                    <Card className="p-5 bg-gradient-to-r from-emerald-50 to-green-50 border-emerald-200 hover:shadow-lg transition-shadow">
                      <div className="flex items-start gap-4">
                        <div className="w-10 h-10 bg-emerald-500 rounded-full flex items-center justify-center flex-shrink-0">
                          <Sparkles className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <div className="font-bold text-emerald-800 mb-1">Promise 4</div>
                          <p className="text-emerald-700 text-sm leading-relaxed">
                            The Rosary shall make virtue and good works flourish, and shall obtain for souls the most abundant divine mercies; it shall substitute in hearts love of God for love of the world, elevate them to desire heavenly and eternal goods. Oh, that souls would sanctify themselves by this means!
                          </p>
                        </div>
                      </div>
                    </Card>

                    {/* Promise 5 */}
                    <Card className="p-5 bg-gradient-to-r from-blue-50 to-cyan-50 border-blue-200 hover:shadow-lg transition-shadow">
                      <div className="flex items-start gap-4">
                        <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0">
                          <Heart className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <div className="font-bold text-blue-800 mb-1">Promise 5</div>
                          <p className="text-blue-700 text-sm leading-relaxed">
                            Those who trust themselves to me through the Rosary, shall not perish.
                          </p>
                        </div>
                      </div>
                    </Card>

                    {/* Promise 6 */}
                    <Card className="p-5 bg-gradient-to-r from-indigo-50 to-purple-50 border-indigo-200 hover:shadow-lg transition-shadow">
                      <div className="flex items-start gap-4">
                        <div className="w-10 h-10 bg-indigo-500 rounded-full flex items-center justify-center flex-shrink-0">
                          <CheckCircle2 className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <div className="font-bold text-indigo-800 mb-1">Promise 6</div>
                          <p className="text-indigo-700 text-sm leading-relaxed">
                            Those who will recite my Rosary piously, considering its Mysteries, shall not be overwhelmed by misfortune nor die a bad death. The sinner shall be converted; the just shall grow in grace and become worthy of eternal life.
                          </p>
                        </div>
                      </div>
                    </Card>

                    {/* Promise 7 */}
                    <Card className="p-5 bg-gradient-to-r from-teal-50 to-cyan-50 border-teal-200 hover:shadow-lg transition-shadow">
                      <div className="flex items-start gap-4">
                        <div className="w-10 h-10 bg-teal-500 rounded-full flex items-center justify-center flex-shrink-0">
                          <Church className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <div className="font-bold text-teal-800 mb-1">Promise 7</div>
                          <p className="text-teal-700 text-sm leading-relaxed">
                            Those truly devoted to my Rosary shall not die without the consolations of the Church, or without grace.
                          </p>
                        </div>
                      </div>
                    </Card>

                    {/* Promise 8 */}
                    <Card className="p-5 bg-gradient-to-r from-pink-50 to-rose-50 border-pink-200 hover:shadow-lg transition-shadow">
                      <div className="flex items-start gap-4">
                        <div className="w-10 h-10 bg-pink-500 rounded-full flex items-center justify-center flex-shrink-0">
                          <Sparkles className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <div className="font-bold text-pink-800 mb-1">Promise 8</div>
                          <p className="text-pink-700 text-sm leading-relaxed">
                            Those who will recite my Rosary shall find during their life and at their death the light of God, the fullness of His grace, and shall share in the merits of the blessed.
                          </p>
                        </div>
                      </div>
                    </Card>

                    {/* Promise 9 */}
                    <Card className="p-5 bg-gradient-to-r from-orange-50 to-red-50 border-orange-200 hover:shadow-lg transition-shadow">
                      <div className="flex items-start gap-4">
                        <div className="w-10 h-10 bg-orange-500 rounded-full flex items-center justify-center flex-shrink-0">
                          <Gift className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <div className="font-bold text-orange-800 mb-1">Promise 9</div>
                          <p className="text-orange-700 text-sm leading-relaxed">
                            I will deliver very promptly from purgatory the souls devoted to my Rosary.
                          </p>
                        </div>
                      </div>
                    </Card>

                    {/* Promise 10 */}
                    <Card className="p-5 bg-gradient-to-r from-violet-50 to-purple-50 border-violet-200 hover:shadow-lg transition-shadow">
                      <div className="flex items-start gap-4">
                        <div className="w-10 h-10 bg-violet-500 rounded-full flex items-center justify-center flex-shrink-0">
                          <Crown className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <div className="font-bold text-violet-800 mb-1">Promise 10</div>
                          <p className="text-violet-700 text-sm leading-relaxed">
                            The true children of my Rosary shall enjoy great glory in heaven.
                          </p>
                        </div>
                      </div>
                    </Card>

                    {/* Promise 11 */}
                    <Card className="p-5 bg-gradient-to-r from-sky-50 to-blue-50 border-sky-200 hover:shadow-lg transition-shadow">
                      <div className="flex items-start gap-4">
                        <div className="w-10 h-10 bg-sky-500 rounded-full flex items-center justify-center flex-shrink-0">
                          <Heart className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <div className="font-bold text-sky-800 mb-1">Promise 11</div>
                          <p className="text-sky-700 text-sm leading-relaxed">
                            What you ask through my Rosary, you shall obtain.
                          </p>
                        </div>
                      </div>
                    </Card>

                    {/* Promise 12 */}
                    <Card className="p-5 bg-gradient-to-r from-lime-50 to-green-50 border-lime-200 hover:shadow-lg transition-shadow">
                      <div className="flex items-start gap-4">
                        <div className="w-10 h-10 bg-lime-500 rounded-full flex items-center justify-center flex-shrink-0">
                          <Shield className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <div className="font-bold text-lime-800 mb-1">Promise 12</div>
                          <p className="text-lime-700 text-sm leading-relaxed">
                            Those who propagate my Rosary shall obtain through me aid in all their necessities.
                          </p>
                        </div>
                      </div>
                    </Card>

                    {/* Promise 13 */}
                    <Card className="p-5 bg-gradient-to-r from-fuchsia-50 to-pink-50 border-fuchsia-200 hover:shadow-lg transition-shadow">
                      <div className="flex items-start gap-4">
                        <div className="w-10 h-10 bg-fuchsia-500 rounded-full flex items-center justify-center flex-shrink-0">
                          <Star className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <div className="font-bold text-fuchsia-800 mb-1">Promise 13</div>
                          <p className="text-fuchsia-700 text-sm leading-relaxed">
                            I have obtained from my Son that all the confrères of the Rosary shall have for their brethren in life and death the saints of heaven.
                          </p>
                        </div>
                      </div>
                    </Card>

                    {/* Promise 14 */}
                    <Card className="p-5 bg-gradient-to-r from-cyan-50 to-teal-50 border-cyan-200 hover:shadow-lg transition-shadow">
                      <div className="flex items-start gap-4">
                        <div className="w-10 h-10 bg-cyan-500 rounded-full flex items-center justify-center flex-shrink-0">
                          <Heart className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <div className="font-bold text-cyan-800 mb-1">Promise 14</div>
                          <p className="text-cyan-700 text-sm leading-relaxed">
                            Those who recite my Rosary faithfully are all my beloved children, the brothers and sisters of Jesus Christ.
                          </p>
                        </div>
                      </div>
                    </Card>

                    {/* Promise 15 */}
                    <Card className="p-5 bg-gradient-to-r from-yellow-50 to-amber-50 border-yellow-200 hover:shadow-lg transition-shadow">
                      <div className="flex items-start gap-4">
                        <div className="w-10 h-10 bg-yellow-500 rounded-full flex items-center justify-center flex-shrink-0">
                          <Crown className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <div className="font-bold text-yellow-800 mb-1">Promise 15</div>
                          <p className="text-yellow-700 text-sm leading-relaxed">
                            Devotion to my Rosary is a special sign of predestination.
                          </p>
                        </div>
                      </div>
                    </Card>
                  </div>
                </div>
              ) : (
                <Card className="p-6">
                  <p className="text-gray-500">Loading promises information...</p>
                </Card>
              )}
            </TabsContent>
          </Tabs>
        </div>

        {/* Structure Overview */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <Card className="p-6 bg-gradient-to-br from-rose-50 to-pink-50 border-rose-200">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-rose-500 rounded-full flex items-center justify-center">
                <Heart className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="font-bold text-rose-800">Phase 1: Petition</h3>
                <p className="text-rose-600 text-sm">Days 1-27</p>
              </div>
            </div>
            <p className="text-rose-700 text-sm leading-relaxed">
              Present your intentions and requests to Our Lady with faith and humility. 
              Pray the rosary daily while asking for her powerful intercession.
            </p>
          </Card>

          <Card className="p-6 bg-gradient-to-br from-emerald-50 to-green-50 border-emerald-200">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-emerald-500 rounded-full flex items-center justify-center">
                <Star className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="font-bold text-emerald-800">Phase 2: Thanksgiving</h3>
                <p className="text-emerald-600 text-sm">Days 28-54</p>
              </div>
            </div>
            <p className="text-emerald-700 text-sm leading-relaxed">
              Offer gratitude and thanksgiving to Mary for her motherly care, 
              trusting in God's perfect will and timing for all things.
            </p>
          </Card>
        </div>

        {/* Information Cards */}
        <div className="grid md:grid-cols-3 gap-6">
          <Card className="p-6">
            <div className="text-center">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Calendar className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="font-bold text-gray-900 mb-2">Daily Structure</h3>
              <p className="text-gray-600 text-sm">
                Pray one complete rosary each day with specific intentions for petition or thanksgiving.
              </p>
            </div>
          </Card>

          <Card className="p-6">
            <div className="text-center">
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="w-6 h-6 text-purple-600" />
              </div>
              <h3 className="font-bold text-gray-900 mb-2">Powerful Intercession</h3>
              <p className="text-gray-600 text-sm">
                Experience the maternal love and powerful intercession of Our Lady through this devotion.
              </p>
            </div>
          </Card>

          <Card className="p-6">
            <div className="text-center">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle2 className="w-6 h-6 text-green-600" />
              </div>
              <h3 className="font-bold text-gray-900 mb-2">Complete Cycle</h3>
              <p className="text-gray-600 text-sm">
                A balanced spiritual journey that teaches both petition and gratitude in prayer.
              </p>
            </div>
          </Card>
        </div>
      </main>
      
      <BottomNavigation />
    </div>
  );
}
import * as React from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Header } from "@/components/layout/header";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { Card } from "@/components/ui/card";
import { NovenaPrayerResponse, SaintResponse } from "@/lib/types";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function PrayerEditor() {
  const params = useParams();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const saintId = params.id;
  const [selectedDay, setSelectedDay] = React.useState<number>(1);
  const [title, setTitle] = React.useState<string>("");
  const [content, setContent] = React.useState<string>("");

  // Fetch saint details
  const { data: saint, isLoading: isLoadingSaint } = useQuery<SaintResponse>({
    queryKey: [`/api/saints/${saintId}`]
  });
  
  React.useEffect(() => {
    if (saint) {
      console.log("Saint data loaded:", saint);
      console.log("Novena length is:", saint.novenaLength);
    }
  }, [saint]);

  // Fetch all prayers for this saint
  const { data: prayers, isLoading: isLoadingPrayers } = useQuery<NovenaPrayerResponse[]>({
    queryKey: [`/api/saints/${saintId}/prayers`],
  });

  // Effect to update form when prayers data loads or selected day changes
  React.useEffect(() => {
    if (prayers && saint) {
      console.log("Saint data:", saint);
      console.log("Novena length:", saint.novenaLength);
      
      const prayer = prayers.find(p => p.day === selectedDay);
      if (prayer) {
        setTitle(prayer.title || "");
        setContent(prayer.content);
      } else {
        // If no prayer exists for this day, use saint's default prayer
        setTitle(`Day ${selectedDay} Prayer`);
        setContent(saint.prayer || "");
      }
    }
  }, [prayers, saint, selectedDay]);

  // Save prayer mutation
  const savePrayer = useMutation({
    mutationFn: async () => {
      const response = await apiRequest(
        "POST", 
        `/api/saints/${saintId}/prayers/${selectedDay}`, 
        { title, content }
      );
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/saints/${saintId}/prayers`] });
      queryClient.invalidateQueries({ queryKey: [`/api/saints/${saintId}/prayers/${selectedDay}`] });
      toast({
        title: "Prayer Saved",
        description: `Day ${selectedDay} prayer has been saved successfully.`,
      });
    },
    onError: (error) => {
      toast({
        title: "Error Saving Prayer",
        description: "There was an error saving the prayer. Please try again.",
        variant: "destructive",
      });
      console.error("Error saving prayer:", error);
    },
  });

  const handleDayChange = (day: number) => {
    setSelectedDay(day);
    
    if (prayers && saint) {
      const prayer = prayers.find(p => p.day === day);
      if (prayer) {
        setTitle(prayer.title || "");
        setContent(prayer.content);
      } else {
        // If no prayer exists for this day, use saint's default prayer
        setTitle(`Day ${day} Prayer`);
        setContent(saint.prayer || "");
      }
    }
  };

  const handleSavePrayer = () => {
    if (content.trim().length < 10) {
      toast({
        title: "Invalid Content",
        description: "Prayer content must be at least 10 characters long.",
        variant: "destructive",
      });
      return;
    }

    savePrayer.mutate();
  };

  const navigateBack = () => {
    navigate(`/saint/${saintId}`);
  };

  if (isLoadingSaint || isLoadingPrayers) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow mt-14 mb-16">
          <div className="container mx-auto px-4 py-6 text-center">
            <div className="mt-20">
              <i className="fas fa-pray text-4xl text-slate-300 mb-4"></i>
              <p>Loading saint information...</p>
            </div>
          </div>
        </main>
        <BottomNavigation />
      </div>
    );
  }

  const typedSaint = saint as SaintResponse;

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow mt-14 mb-16">
        <div className="container mx-auto px-4 py-6">
          <div className="mb-6 flex items-center">
            <button className="mr-3 text-slate-600" onClick={navigateBack}>
              <i className="fas fa-arrow-left"></i>
            </button>
            <h2 className="font-serif text-2xl font-bold">Edit {typedSaint.name} Novena Prayers</h2>
          </div>
          
          <Card className="bg-white rounded-lg shadow-md p-5 mb-6">
            {saint && (
              <Tabs defaultValue="1" onValueChange={(value) => handleDayChange(parseInt(value, 10))}>
                <div className="mb-4 flex items-center justify-between">
                  <h3 className="text-lg font-medium">
                    {saintId === "9" ? `Day ${selectedDay} of 54` : `Day ${selectedDay} of ${saint.novenaLength || 9}`}
                  </h3>
                  <div className="flex gap-2">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => selectedDay > 1 && handleDayChange(selectedDay - 1)}
                      disabled={selectedDay <= 1}
                    >
                      Previous Day
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => {
                        const maxDays = saintId === "9" ? 54 : (saint.novenaLength || 9);
                        if (selectedDay < maxDays) {
                          handleDayChange(selectedDay + 1);
                        }
                      }}
                      disabled={selectedDay >= (saintId === "9" ? 54 : (saint.novenaLength || 9))}
                    >
                      Next Day
                    </Button>
                  </div>
                </div>
                
                {/* Day selection interface */}
                <div className="mb-4 overflow-x-auto">
                  {saintId === "9" ? (
                    <div>
                      <h4 className="text-md mb-2">Select a day (1-54):</h4>
                      <div className="grid grid-cols-6 gap-1 sm:grid-cols-9 md:grid-cols-12">
                        {Array.from({ length: 54 }, (_, i) => i + 1).map((day) => {
                          const hasPrayer = prayers && prayers.some(p => p.day === day);
                          return (
                            <Button 
                              key={day}
                              variant={day === selectedDay ? "default" : "outline"}
                              size="sm"
                              className={hasPrayer ? "border-b-2 border-primary" : ""}
                              onClick={() => handleDayChange(day)}
                            >
                              {day}
                            </Button>
                          );
                        })}
                      </div>
                      <div className="mt-2 text-xs text-slate-500">
                        <span>First 27 days are petition, last 27 days are thanksgiving.</span>
                      </div>
                    </div>
                  ) : (
                    <div className="flex flex-wrap gap-1 pb-2">
                      {Array.from({ length: 9 }, (_, i) => i + 1).map((day) => {
                        const hasPrayer = prayers && prayers.some(p => p.day === day);
                        return (
                          <Button 
                            key={day}
                            variant={day === selectedDay ? "default" : "outline"}
                            size="sm"
                            className={`min-w-[40px] ${hasPrayer ? "border-b-2 border-primary" : ""}`}
                            onClick={() => handleDayChange(day)}
                          >
                            {day}
                          </Button>
                        );
                      })}
                    </div>
                  )}
                </div>
                
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="title">Prayer Title (optional)</Label>
                    <Input 
                      id="title" 
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      placeholder={`Day ${selectedDay} Prayer`}
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="content">Prayer Content</Label>
                    <Textarea 
                      id="content" 
                      value={content}
                      onChange={(e) => setContent(e.target.value)}
                      placeholder="Enter the prayer content for this day..."
                      className="min-h-[300px]"
                    />
                    <p className="text-xs text-slate-500 mt-1">
                      Use double line breaks (press Enter twice) to create new paragraphs.
                    </p>
                  </div>
                  
                  <div className="flex justify-end">
                    <Button
                      onClick={handleSavePrayer}
                      disabled={savePrayer.isPending}
                    >
                      {savePrayer.isPending ? "Saving..." : "Save Prayer"}
                    </Button>
                  </div>
                </div>
              </Tabs>
            )}
          </Card>
          
          <div className="text-center">
            <p className="text-sm text-slate-600 mb-4">
              Each day of the novena can have its own prayer. 
              Days with custom prayers are highlighted in blue above.
              {saint && saint.novenaLength && saint.novenaLength > 9 && (
                <span> This novena has {saint.novenaLength} days. Use the Previous/Next buttons or click on each day number to navigate.</span>
              )}
            </p>
            <Button variant="outline" onClick={navigateBack}>
              <i className="fas fa-arrow-left mr-2"></i> Back to Saint
            </Button>
          </div>
        </div>
      </main>
      
      <BottomNavigation />
    </div>
  );
}
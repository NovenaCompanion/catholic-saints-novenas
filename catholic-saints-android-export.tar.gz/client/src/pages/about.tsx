import * as React from "react";
import { Header } from "@/components/layout/header";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Heart, MapPin, Users, Star, Clock, Globe, Shield, Sparkles, Crown, BookOpen, Award, Church } from "lucide-react";

export default function About() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50">
      <Header />
      
      <main className="pb-20 pt-4">
        <div className="max-w-4xl mx-auto px-4 space-y-8">
          
          {/* Hero Section */}
          <div className="text-center space-y-6 py-8">
            <div className="relative">
              <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-rose-600 bg-clip-text text-transparent">
                About Us
              </h1>
              <div className="absolute -top-2 -right-2 text-yellow-400">
                <Sparkles className="w-8 h-8 animate-pulse" />
              </div>
            </div>
            
            <p className="text-xl text-slate-600 max-w-2xl mx-auto leading-relaxed">
              A labor of love from Rosary City Foundation, empowering Catholics globally to deepen their faith through the transformative power of novena prayer
            </p>
            
            <div className="flex flex-wrap justify-center gap-3">
              <Badge variant="secondary" className="bg-gradient-to-r from-blue-100 to-purple-100 text-blue-700 px-4 py-2">
                <Globe className="w-4 h-4 mr-2" />
                Global Community
              </Badge>
              <Badge variant="secondary" className="bg-gradient-to-r from-purple-100 to-rose-100 text-purple-700 px-4 py-2">
                <Heart className="w-4 h-4 mr-2" />
                250+ Saints
              </Badge>
              <Badge variant="secondary" className="bg-gradient-to-r from-rose-100 to-orange-100 text-rose-700 px-4 py-2">
                <Crown className="w-4 h-4 mr-2" />
                Premium Features
              </Badge>
            </div>
          </div>

          {/* Foundation Story */}
          <Card className="p-8 bg-gradient-to-r from-white to-blue-50 border-0 shadow-xl">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                <Church className="w-6 h-6 text-white" />
              </div>
              <h2 className="text-3xl font-bold text-slate-800">Our Sacred Journey</h2>
            </div>
            
            <div className="space-y-4 text-slate-600 leading-relaxed">
              <p className="text-lg">
                My Novena Companion is a labor of love from <strong className="text-blue-600">Rosary City Foundation</strong>, 
                based in the sacred city of Fatima, Portugal. Our journey began with crafting Rosaries that found their way 
                to many corners of the world.
              </p>
              
              <div className="flex items-center gap-3 p-4 bg-gradient-to-r from-yellow-50 to-orange-50 rounded-lg border-l-4 border-yellow-400">
                <MapPin className="w-5 h-5 text-yellow-600 flex-shrink-0" />
                <p className="italic">
                  "We noticed that many devotees, despite purchasing Rosaries and prayer books, were unaware of 
                  specific novenas tailored to their unique spiritual and physical needs. Some didn't even know what a novena was."
                </p>
              </div>
              
              <p className="text-lg">
                We also observed the limitations of prayer programs, where crucial details were confined to scarce prayer booklets. 
                Moreover, Catholics worldwide yearned to pray novenas like the <strong className="text-purple-600">54-Day Rosary Novena</strong> or the 
                <strong className="text-purple-600">33-Day Consecration</strong> to the Blessed Virgin Mary, but lacked a comprehensive resource to guide them.
              </p>
              
              <p className="text-lg">
                After much prayer and reflection, we created <strong className="text-rose-600">My Novena Companion</strong>—a 
                digital sanctuary where Catholics can access authentic devotions, novenas, and spiritual guidance anytime, anywhere.
              </p>
            </div>
          </Card>

          {/* Mission & Vision */}
          <div className="grid md:grid-cols-2 gap-6">
            <Card className="p-6 bg-gradient-to-br from-purple-50 to-pink-50 border-0 shadow-lg">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                  <Heart className="w-5 h-5 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-slate-800">Our Mission</h3>
              </div>
              <p className="text-slate-600 leading-relaxed">
                Our mission is to empower Catholics globally to deepen their faith through the transformative power of novena prayer. 
                We provide access to over 250 saints and their authentic novenas, helping Catholics worldwide grow closer to God through the intercession of the saints.
              </p>
            </Card>

            <Card className="p-6 bg-gradient-to-br from-blue-50 to-indigo-50 border-0 shadow-lg">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full flex items-center justify-center">
                  <Star className="w-5 h-5 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-slate-800">Our Vision</h3>
              </div>
              <p className="text-slate-600 leading-relaxed">
                A world where every Catholic has immediate access to saints' intercession, 
                guided novenas, and spiritual growth tools that strengthen faith and build community.
              </p>
            </Card>
          </div>

          {/* What are Novenas */}
          <Card className="p-8 bg-gradient-to-r from-green-50 to-emerald-50 border-0 shadow-xl">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full flex items-center justify-center">
                <BookOpen className="w-6 h-6 text-white" />
              </div>
              <h2 className="text-3xl font-bold text-slate-800">What are Novenas?</h2>
            </div>
            
            <div className="space-y-4 text-slate-600 leading-relaxed">
              <p className="text-lg">
                A novena is a traditional Catholic <strong className="text-green-600">nine-day prayer devotion</strong>, typically focused on a specific intention or honoring a particular saint. 
                This powerful practice fosters spiritual growth, seeks intercession, and encourages reflection.
              </p>
              
              <p className="text-lg">
                Novenas can be prayed individually or in community, often involving daily repetition of specific prayers or intentions. 
                Note that while some novenas adhere to the nine-day structure, others may extend beyond this period.
              </p>
              
              <div className="flex items-center gap-3 p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg border-l-4 border-green-400">
                <BookOpen className="w-5 h-5 text-green-600 flex-shrink-0" />
                <p className="italic">
                  "Our app offers a diverse range of novenas, including those spanning 30 and 54 days, 
                  providing a comprehensive hub for Catholics to explore and deepen their faith."
                </p>
              </div>
              
              <div className="grid md:grid-cols-3 gap-4 mt-6">
                <div className="text-center p-4 bg-white rounded-lg shadow-sm">
                  <Clock className="w-8 h-8 text-green-500 mx-auto mb-2" />
                  <h4 className="font-semibold text-slate-800">9+ Days</h4>
                  <p className="text-sm text-slate-600">Flexible duration</p>
                </div>
                <div className="text-center p-4 bg-white rounded-lg shadow-sm">
                  <Users className="w-8 h-8 text-blue-500 mx-auto mb-2" />
                  <h4 className="font-semibold text-slate-800">Personal Growth</h4>
                  <p className="text-sm text-slate-600">Spiritual development</p>
                </div>
                <div className="text-center p-4 bg-white rounded-lg shadow-sm">
                  <Shield className="w-8 h-8 text-purple-500 mx-auto mb-2" />
                  <h4 className="font-semibold text-slate-800">Reflection</h4>
                  <p className="text-sm text-slate-600">Daily contemplation</p>
                </div>
              </div>
            </div>
          </Card>

          {/* Special Features */}
          <Card className="p-8 bg-gradient-to-r from-orange-50 to-red-50 border-0 shadow-xl">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-12 h-12 bg-gradient-to-r from-orange-500 to-red-500 rounded-full flex items-center justify-center">
                <Award className="w-6 h-6 text-white" />
              </div>
              <h2 className="text-3xl font-bold text-slate-800">Special Features</h2>
            </div>
            
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <Crown className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-slate-800 mb-1">33-Day Total Consecration</h4>
                    <p className="text-slate-600 text-sm">Complete preparation for Marian consecration according to St. Louis de Montfort</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <Award className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-slate-800 mb-1">54-Day Rosary Novena</h4>
                    <p className="text-slate-600 text-sm">Traditional petition and thanksgiving rosary novena with authentic prayers</p>
                  </div>
                </div>
              </div>
              
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <BookOpen className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-slate-800 mb-1">Daily Holy Rosary</h4>
                    <p className="text-slate-600 text-sm">Complete rosary prayers with all four mystery sets and guided meditation</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <Users className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-slate-800 mb-1">Saints Database</h4>
                    <p className="text-slate-600 text-sm">250+ saints with biographies, feast days, patronages, and authentic novenas</p>
                  </div>
                </div>
              </div>
            </div>
          </Card>

          {/* Share Your Journey */}
          <Card className="p-8 bg-gradient-to-r from-rose-50 to-pink-50 border-0 shadow-xl">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-12 h-12 bg-gradient-to-r from-rose-500 to-pink-500 rounded-full flex items-center justify-center">
                <Heart className="w-6 h-6 text-white" />
              </div>
              <h2 className="text-3xl font-bold text-slate-800">Share Your Journey</h2>
            </div>
            
            <div className="space-y-4 text-slate-600 leading-relaxed">
              <p className="text-lg">
                We invite you to share your <strong className="text-rose-600">testimonies and spiritual journey milestones</strong> with us. 
                Your experiences inspire others and help us understand how we can make this app spiritually profitable for you.
              </p>
              
              <div className="grid md:grid-cols-2 gap-4">
                <div className="text-center p-6 bg-white rounded-lg shadow-sm">
                  <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Globe className="w-6 h-6 text-white" />
                  </div>
                  <h4 className="font-semibold text-slate-800 mb-2">Email Support</h4>
                  <p className="text-blue-600 font-medium text-lg">mynovena1@gmail.com</p>
                </div>
                
                <div className="text-center p-6 bg-white rounded-lg shadow-sm">
                  <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Users className="w-6 h-6 text-white" />
                  </div>
                  <h4 className="font-semibold text-slate-800 mb-2">WhatsApp</h4>
                  <p className="text-green-600 font-medium text-lg">+447380301720</p>
                </div>
              </div>
            </div>
          </Card>

          {/* Contact Information */}
          <Card className="p-8 bg-gradient-to-r from-slate-50 to-gray-50 border-0 shadow-xl">
            <div className="text-center space-y-6">
              <h2 className="text-3xl font-bold text-slate-800">Foundation Details</h2>
              
              <div className="max-w-2xl mx-auto space-y-4">
                <div className="text-center text-slate-600 space-y-2">
                  <p className="text-xl font-semibold text-slate-800">Rosary City Foundation</p>
                  <p className="text-sm">Travessa 13 de Maio, Edificio 2001, L3</p>
                  <p className="text-sm">Fatima, 2495-414, Portugal</p>
                  <p className="text-sm font-medium text-slate-500">Version 1.0.0 • © 2025 Rosary City Foundation</p>
                </div>
              </div>
              
              <div className="flex justify-center">
                <Button 
                  className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-3 rounded-full text-lg font-medium shadow-lg transform hover:scale-105 transition-all duration-200"
                  onClick={() => window.location.href = 'mailto:mynovena1@gmail.com'}
                >
                  <Heart className="w-5 h-5 mr-2" />
                  Contact Us
                </Button>
              </div>
            </div>
          </Card>
          
        </div>
      </main>
      
      <BottomNavigation />
    </div>
  );
}
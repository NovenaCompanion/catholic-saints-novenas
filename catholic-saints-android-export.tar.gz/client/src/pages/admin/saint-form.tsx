import * as React from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Header } from "@/components/layout/header";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { SaintResponse, CategoryResponse } from "@/lib/types";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { ImageUploader } from "@/components/ui/image-uploader";

export default function SaintForm() {
  const params = useParams();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const isEditMode = !!params.id;
  const saintId = params.id;
  
  // Form state
  const [name, setName] = React.useState("");
  const [title, setTitle] = React.useState("");
  const [description, setDescription] = React.useState("");
  const [imageUrl, setImageUrl] = React.useState("");
  const [feastDay, setFeastDay] = React.useState("");
  const [patronOf, setPatronOf] = React.useState("");
  const [born, setBorn] = React.useState("");
  const [died, setDied] = React.useState("");
  const [prayer, setPrayer] = React.useState("");
  const [isPopular, setIsPopular] = React.useState(false);
  const [novenaLength, setNovenaLength] = React.useState(9); // Default is 9 days
  const [selectedCategories, setSelectedCategories] = React.useState<number[]>([]);
  
  // Fetch all categories
  const { data: categories } = useQuery({
    queryKey: ["/api/categories"],
  });
  
  // Fetch saint details if in edit mode
  const { data: saint, isLoading: isLoadingSaint } = useQuery({
    queryKey: [`/api/saints/${saintId}`],
    enabled: isEditMode,
  });
  
  // Initialize form with saint data if in edit mode
  React.useEffect(() => {
    if (isEditMode && saint) {
      const typedSaint = saint as SaintResponse;
      setName(typedSaint.name || "");
      setTitle(typedSaint.title || "");
      setDescription(typedSaint.description || "");
      setImageUrl(typedSaint.imageUrl || "");
      setFeastDay(typedSaint.feastDay || "");
      setPatronOf(typedSaint.patronOf || "");
      setBorn(typedSaint.born || "");
      setDied(typedSaint.died || "");
      setPrayer(typedSaint.prayer || "");
      setIsPopular(typedSaint.isPopular || false);
      setNovenaLength(typedSaint.novenaLength || 9);
      setSelectedCategories(typedSaint.categories?.map(c => c.id) || []);
    }
  }, [isEditMode, saint]);
  
  // Save saint mutation
  const saveSaint = useMutation({
    mutationFn: async () => {
      const endpoint = isEditMode ? `/api/saints/${saintId}` : "/api/saints";
      const method = isEditMode ? "PUT" : "POST";
      
      // Make sure novena length is a valid number between 1 and 54
      const validatedNovenaLength = Math.min(54, Math.max(1, novenaLength || 9));
      
      const response = await apiRequest(
        method,
        endpoint,
        {
          name,
          title: title || null,
          description,
          imageUrl: imageUrl || null,
          feastDay: feastDay || null,
          patronOf: patronOf || null,
          born: born || null,
          died: died || null,
          prayer,
          isPopular,
          novenaLength: validatedNovenaLength,
          categoryIds: selectedCategories
        }
      );
      
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/saints"] });
      queryClient.invalidateQueries({ queryKey: [`/api/saints/${saintId}`] });
      
      toast({
        title: isEditMode ? "Saint Updated" : "Saint Created",
        description: isEditMode 
          ? `${name} has been updated successfully.` 
          : `${name} has been added to the database.`,
      });
      
      navigate("/admin/saints");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to ${isEditMode ? "update" : "create"} saint. Please try again.`,
        variant: "destructive",
      });
      console.error(`Error ${isEditMode ? "updating" : "creating"} saint:`, error);
    },
  });
  
  const handleCategoryToggle = (categoryId: number) => {
    setSelectedCategories(prev => {
      if (prev.includes(categoryId)) {
        return prev.filter(id => id !== categoryId);
      } else {
        return [...prev, categoryId];
      }
    });
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate required fields
    if (!name || !description || !prayer) {
      toast({
        title: "Missing Required Fields",
        description: "Please fill in all required fields: Name, Description, and Prayer.",
        variant: "destructive",
      });
      return;
    }
    
    saveSaint.mutate();
  };
  
  if (isEditMode && isLoadingSaint) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow mt-14 mb-16">
          <div className="container mx-auto px-4 py-6 text-center">
            <div className="mt-20">
              <i className="fas fa-spinner fa-spin text-4xl text-primary mb-4"></i>
              <p>Loading saint information...</p>
            </div>
          </div>
        </main>
        <BottomNavigation />
      </div>
    );
  }
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow mt-14 mb-16">
        <div className="container mx-auto px-4 py-6">
          <div className="flex justify-between items-center mb-6">
            <h1 className="font-serif text-3xl font-bold">
              {isEditMode ? `Edit ${name}` : "Add New Saint"}
            </h1>
            <Button onClick={() => navigate("/admin/saints")} variant="outline">
              <i className="fas fa-arrow-left mr-2"></i> Back to Saints
            </Button>
          </div>
          
          <Card className="bg-white rounded-lg shadow-md p-5 mb-6">
            <form onSubmit={handleSubmit}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Basic Information */}
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="name">Name <span className="text-red-500">*</span></Label>
                    <Input
                      id="name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Saint's name"
                      required
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="title">Title</Label>
                    <Input
                      id="title"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      placeholder="e.g., Martyr, Doctor of the Church"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="imageUrl">Saint Image</Label>
                    <div className="flex mt-2 space-x-2">
                      <div className="flex-1">
                        <Input
                          id="imageUrl"
                          value={imageUrl}
                          onChange={(e) => setImageUrl(e.target.value)}
                          placeholder="URL to saint's image"
                        />
                        <p className="text-xs text-slate-500 mt-1">Enter a URL or upload an image file below.</p>
                      </div>
                    </div>
                    
                    {/* Image Uploader */}
                    <div className="mt-3">
                      <ImageUploader 
                        uploadType="saints"
                        currentImageUrl={imageUrl}
                        onImageUploaded={(url) => setImageUrl(url)}
                      />
                    </div>
                    
                    {imageUrl && (
                      <div className="mt-3">
                        <p className="text-xs text-slate-500 mb-1">Preview:</p>
                        <div className="w-full flex justify-center">
                          <img 
                            src={imageUrl} 
                            alt={name || "Saint image"} 
                            className="max-h-48 object-contain rounded-md shadow-sm border border-slate-200"
                          />
                        </div>
                      </div>
                    )}
                  </div>
                  
                  <div>
                    <Label htmlFor="feastDay">Feast Day</Label>
                    <Input
                      id="feastDay"
                      value={feastDay}
                      onChange={(e) => setFeastDay(e.target.value)}
                      placeholder="e.g., March 19"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="patronOf">Patron Of</Label>
                    <Input
                      id="patronOf"
                      value={patronOf}
                      onChange={(e) => setPatronOf(e.target.value)}
                      placeholder="e.g., Travelers, Carpenters"
                    />
                  </div>
                  
                  <div className="flex space-x-4">
                    <div className="w-1/2">
                      <Label htmlFor="born">Born</Label>
                      <Input
                        id="born"
                        value={born}
                        onChange={(e) => setBorn(e.target.value)}
                        placeholder="e.g., 1st century"
                      />
                    </div>
                    
                    <div className="w-1/2">
                      <Label htmlFor="died">Died</Label>
                      <Input
                        id="died"
                        value={died}
                        onChange={(e) => setDied(e.target.value)}
                        placeholder="e.g., 1st century"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="novenaLength">Novena Length (days)</Label>
                    <div className="flex space-x-2 items-center">
                      <Input
                        id="novenaLength"
                        type="number"
                        min="1"
                        max="54"
                        value={novenaLength}
                        onChange={(e) => setNovenaLength(parseInt(e.target.value) || 9)}
                        className="flex-1"
                      />
                      <div className="text-xs text-slate-500">
                        <div>Default: 9 days</div>
                        <div>Max: 54 days</div>
                      </div>
                    </div>
                    <p className="text-xs text-slate-500 mt-1">
                      Length of the novena prayer period in days.
                    </p>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="isPopular" 
                      checked={isPopular}
                      onCheckedChange={(checked) => setIsPopular(checked as boolean)} 
                    />
                    <Label htmlFor="isPopular" className="cursor-pointer">
                      Featured Saint (shown on home page)
                    </Label>
                  </div>
                </div>
                
                {/* Description, Prayer, and Categories */}
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="description">Description <span className="text-red-500">*</span></Label>
                    <Textarea
                      id="description"
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      placeholder="Brief description of the saint"
                      className="min-h-[100px]"
                      required
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="prayer">Default Prayer <span className="text-red-500">*</span></Label>
                    <Textarea
                      id="prayer"
                      value={prayer}
                      onChange={(e) => setPrayer(e.target.value)}
                      placeholder="Default prayer text for novenas"
                      className="min-h-[150px]"
                      required
                    />
                    <p className="text-xs text-slate-500 mt-1">
                      This is the default prayer used when no day-specific prayers exist.
                    </p>
                  </div>
                  
                  <div>
                    <Label>Categories</Label>
                    <div className="grid grid-cols-2 gap-2 mt-2 border border-slate-200 rounded-md p-3">
                      {categories ? (
                        (categories as CategoryResponse[]).map(category => (
                          <div key={category.id} className="flex items-center space-x-2">
                            <Checkbox 
                              id={`category-${category.id}`} 
                              checked={selectedCategories.includes(category.id)}
                              onCheckedChange={() => handleCategoryToggle(category.id)} 
                            />
                            <Label 
                              htmlFor={`category-${category.id}`} 
                              className="cursor-pointer"
                            >
                              {category.name}
                            </Label>
                          </div>
                        ))
                      ) : (
                        <p className="text-slate-500">Loading categories...</p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="mt-8 flex justify-end space-x-3">
                <Button
                  type="button"
                  onClick={() => navigate("/admin/saints")}
                  variant="outline"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={saveSaint.isPending}
                >
                  {saveSaint.isPending ? (
                    <>
                      <i className="fas fa-spinner fa-spin mr-2"></i>
                      {isEditMode ? "Updating..." : "Creating..."}
                    </>
                  ) : (
                    <>
                      <i className="fas fa-save mr-2"></i>
                      {isEditMode ? "Update Saint" : "Create Saint"}
                    </>
                  )}
                </Button>
              </div>
            </form>
          </Card>
        </div>
      </main>
      
      <BottomNavigation />
    </div>
  );
}
import * as React from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Header } from "@/components/layout/header";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";

interface AdminTestimonial {
  id: number;
  userId: string;
  saintId: number;
  saintName: string;
  title: string;
  content: string;
  favorsReceived: string;
  isApproved: boolean;
  createdAt: string;
}

export default function AdminTestimonials() {
  const [, navigate] = useLocation();
  const { toast } = useToast();

  // Fetch all testimonials including unapproved
  const { data: testimonials, isLoading } = useQuery<AdminTestimonial[]>({
    queryKey: ["/api/admin/testimonials"],
  });

  const approveTestimonial = useMutation({
    mutationFn: async (testimonialId: number) => {
      const response = await apiRequest(
        "POST", 
        `/api/admin/testimonials/${testimonialId}/approve`,
        {}
      );
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/testimonials"] });
      toast({
        title: "Testimonial Approved",
        description: "The testimonial is now visible to all users.",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to Approve",
        description: "There was an error approving the testimonial.",
        variant: "destructive",
      });
      console.error("Error approving testimonial:", error);
    },
  });

  const deleteTestimonial = useMutation({
    mutationFn: async (testimonialId: number) => {
      await apiRequest(
        "DELETE", 
        `/api/admin/testimonials/${testimonialId}`,
        undefined
      );
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/testimonials"] });
      toast({
        title: "Testimonial Deleted",
        description: "The testimonial has been removed.",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to Delete",
        description: "There was an error deleting the testimonial.",
        variant: "destructive",
      });
      console.error("Error deleting testimonial:", error);
    },
  });

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow mt-14 mb-16">
        <div className="container mx-auto px-4 py-6">
          <div className="flex justify-between items-center mb-6">
            <h1 className="font-serif text-2xl font-bold">Manage Testimonials</h1>
            <Button 
              variant="outline" 
              onClick={() => navigate("/admin")}
            >
              <i className="fas fa-arrow-left mr-2"></i> Back to Admin
            </Button>
          </div>

          {isLoading ? (
            <div className="text-center py-10">
              <i className="fas fa-spinner fa-spin text-2xl text-primary mb-4"></i>
              <p>Loading testimonials...</p>
            </div>
          ) : (
            <div className="space-y-5">
              {testimonials && testimonials.length > 0 ? (
                testimonials.map((testimonial) => (
                  <Card key={testimonial.id} className="p-5">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <h2 className="font-semibold text-lg">{testimonial.title}</h2>
                        <p className="text-sm text-slate-500">
                          For {testimonial.saintName} • {new Date(testimonial.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                      <Badge variant={testimonial.isApproved ? "default" : "outline"}>
                        {testimonial.isApproved ? "Approved" : "Pending Review"}
                      </Badge>
                    </div>
                    
                    <div className="prose prose-sm max-w-none mb-4">
                      <h3 className="text-sm font-medium text-slate-700">Testimonial</h3>
                      <p className="text-slate-600">{testimonial.content}</p>
                      
                      <h3 className="text-sm font-medium text-slate-700 mt-3">Favors Received</h3>
                      <p className="text-slate-600">{testimonial.favorsReceived}</p>
                    </div>
                    
                    <div className="flex justify-end gap-3 mt-4">
                      {!testimonial.isApproved && (
                        <Button
                          onClick={() => approveTestimonial.mutate(testimonial.id)}
                          disabled={approveTestimonial.isPending}
                        >
                          <i className="fas fa-check mr-2"></i> Approve
                        </Button>
                      )}
                      <Button
                        variant="destructive"
                        onClick={() => {
                          if (window.confirm("Are you sure you want to delete this testimonial?")) {
                            deleteTestimonial.mutate(testimonial.id);
                          }
                        }}
                        disabled={deleteTestimonial.isPending}
                      >
                        <i className="fas fa-trash mr-2"></i> Delete
                      </Button>
                    </div>
                  </Card>
                ))
              ) : (
                <Card className="p-5 text-center">
                  <p className="text-slate-500 mb-2">No testimonials found</p>
                  <p className="text-sm">When users submit testimonials, they'll appear here for review.</p>
                </Card>
              )}
            </div>
          )}
        </div>
      </main>
      
      <BottomNavigation />
    </div>
  );
}
import * as React from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Header } from "@/components/layout/header";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ImageUploader } from "@/components/ui/image-uploader";
import { CategoryResponse } from "@/lib/types";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

// Common icon choices
const ICONS = [
  { name: "fas fa-church", label: "Church" },
  { name: "fas fa-cross", label: "Cross" },
  { name: "fas fa-pray", label: "Praying" },
  { name: "fas fa-bible", label: "Bible" },
  { name: "fas fa-dove", label: "Dove" },
  { name: "fas fa-hands", label: "Hands" },
  { name: "fas fa-heart", label: "Heart" },
  { name: "fas fa-holly-berry", label: "Holly Berry" },
  { name: "fas fa-user", label: "Person" },
  { name: "fas fa-users", label: "People" },
  { name: "fas fa-star", label: "Star" },
  { name: "fas fa-sun", label: "Sun" },
  { name: "fas fa-moon", label: "Moon" },
  { name: "fas fa-bookmark", label: "Bookmark" },
  { name: "fas fa-crown", label: "Crown" },
];

// Common background colors
const BG_COLORS = [
  { value: "#f0f9ff", label: "Blue Light" },  // blue-50
  { value: "#e0f2fe", label: "Blue" },       // blue-100
  { value: "#eff6ff", label: "Indigo Light" }, // indigo-50
  { value: "#eef2ff", label: "Indigo" },      // indigo-100
  { value: "#fef2f2", label: "Red Light" },    // red-50
  { value: "#fee2e2", label: "Red" },         // red-100
  { value: "#f0fdf4", label: "Green Light" },  // green-50
  { value: "#dcfce7", label: "Green" },       // green-100
  { value: "#fffbeb", label: "Yellow Light" }, // yellow-50
  { value: "#fef3c7", label: "Yellow" },      // yellow-100
  { value: "#faf5ff", label: "Purple Light" }, // purple-50
  { value: "#f3e8ff", label: "Purple" },      // purple-100
  { value: "#fdf2f8", label: "Pink Light" },   // pink-50
  { value: "#fce7f3", label: "Pink" },        // pink-100
  { value: "#f8fafc", label: "Gray Light" },   // slate-50
  { value: "#f1f5f9", label: "Gray" },        // slate-100
];

// Common icon colors
const ICON_COLORS = [
  { value: "#0ea5e9", label: "Blue" },      // blue-500
  { value: "#6366f1", label: "Indigo" },     // indigo-500
  { value: "#ef4444", label: "Red" },       // red-500
  { value: "#10b981", label: "Green" },     // green-500
  { value: "#eab308", label: "Yellow" },    // yellow-500
  { value: "#a855f7", label: "Purple" },    // purple-500
  { value: "#ec4899", label: "Pink" },      // pink-500
  { value: "#334155", label: "Dark Gray" },  // slate-700
];

export default function CategoryForm() {
  const params = useParams();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const isEditMode = !!params.id;
  const categoryId = params.id;
  
  // Form state
  const [name, setName] = React.useState("");
  const [description, setDescription] = React.useState("");
  const [icon, setIcon] = React.useState("fas fa-church");
  const [iconBgColor, setIconBgColor] = React.useState("#f0f9ff");
  const [iconColor, setIconColor] = React.useState("#0ea5e9");
  const [imageUrl, setImageUrl] = React.useState("");
  
  // Fetch category details if in edit mode
  const { data: category, isLoading: isLoadingCategory } = useQuery({
    queryKey: [`/api/categories/${categoryId}`],
    enabled: isEditMode,
  });
  
  // Initialize form with category data if in edit mode
  React.useEffect(() => {
    if (isEditMode && category) {
      const typedCategory = category as CategoryResponse;
      setName(typedCategory.name || "");
      setDescription(typedCategory.description || "");
      setIcon(typedCategory.icon || "fas fa-church");
      setIconBgColor(typedCategory.iconBgColor || "#f0f9ff");
      setIconColor(typedCategory.iconColor || "#0ea5e9");
      setImageUrl(typedCategory.imageUrl || "");
    }
  }, [isEditMode, category]);
  
  // Save category mutation
  const saveCategory = useMutation({
    mutationFn: async () => {
      const endpoint = isEditMode ? `/api/categories/${categoryId}` : "/api/categories";
      const method = isEditMode ? "PUT" : "POST";
      
      const response = await apiRequest(
        method,
        endpoint,
        {
          name,
          description: description || null,
          icon,
          iconBgColor,
          iconColor,
          imageUrl: imageUrl || null
        }
      );
      
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/categories"] });
      
      toast({
        title: isEditMode ? "Category Updated" : "Category Created",
        description: isEditMode 
          ? `${name} has been updated successfully.` 
          : `${name} has been added to the database.`,
      });
      
      navigate("/admin/categories");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to ${isEditMode ? "update" : "create"} category. Please try again.`,
        variant: "destructive",
      });
      console.error(`Error ${isEditMode ? "updating" : "creating"} category:`, error);
    },
  });
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate required fields
    if (!name) {
      toast({
        title: "Missing Required Fields",
        description: "Please provide a name for the category.",
        variant: "destructive",
      });
      return;
    }
    
    saveCategory.mutate();
  };
  
  if (isEditMode && isLoadingCategory) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow mt-14 mb-16">
          <div className="container mx-auto px-4 py-6 text-center">
            <div className="mt-20">
              <i className="fas fa-spinner fa-spin text-4xl text-primary mb-4"></i>
              <p>Loading category information...</p>
            </div>
          </div>
        </main>
        <BottomNavigation />
      </div>
    );
  }
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow mt-14 mb-16">
        <div className="container mx-auto px-4 py-6">
          <div className="flex justify-between items-center mb-6">
            <h1 className="font-serif text-3xl font-bold">
              {isEditMode ? `Edit ${name}` : "Add New Category"}
            </h1>
            <Button onClick={() => navigate("/admin/categories")} variant="outline">
              <i className="fas fa-arrow-left mr-2"></i> Back to Categories
            </Button>
          </div>
          
          <Card className="bg-white rounded-lg shadow-md p-5 mb-6">
            <form onSubmit={handleSubmit}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Basic Information */}
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="name">Name <span className="text-red-500">*</span></Label>
                    <Input
                      id="name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Category name"
                      required
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="description">Description</Label>
                    <Textarea
                      id="description"
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      placeholder="Brief description of this category"
                      className="min-h-[100px]"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="imageUrl">Background Image</Label>
                    <div className="flex mt-2 space-x-2">
                      <div className="flex-1">
                        <Input
                          id="imageUrl"
                          value={imageUrl}
                          onChange={(e) => setImageUrl(e.target.value)}
                          placeholder="https://example.com/image.jpg"
                        />
                        <p className="text-xs text-slate-500 mt-1">Enter a URL or upload an image file below.</p>
                      </div>
                    </div>
                    
                    {/* Image Uploader */}
                    <div className="mt-3">
                      <ImageUploader 
                        uploadType="categories"
                        currentImageUrl={imageUrl}
                        onImageUploaded={(url) => setImageUrl(url)}
                      />
                    </div>
                    
                    {imageUrl && (
                      <div className="mt-3">
                        <p className="text-xs text-slate-500 mb-1">Preview:</p>
                        <div 
                          className="w-full h-32 rounded-lg shadow-sm overflow-hidden"
                          style={{
                            backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.7)), url(${imageUrl})`,
                            backgroundSize: 'cover',
                            backgroundPosition: 'center',
                          }}
                        >
                          <div className="h-full flex flex-col items-center justify-center text-white p-4">
                            <div className={`w-10 h-10 rounded-full ${iconBgColor} flex items-center justify-center mb-2`}>
                              <i className={`${icon} ${iconColor}`}></i>
                            </div>
                            <span className="text-center font-semibold">{name || "Category Name"}</span>
                            <span className="text-xs text-gray-300 mt-1">0 Saints</span>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                  
                  <div>
                    <Label>Icon Preview</Label>
                    <div className="mt-2 flex items-center">
                      <div 
                        className="w-16 h-16 rounded-full flex items-center justify-center"
                        style={{ backgroundColor: iconBgColor }}
                      >
                        <i className={`${icon} text-2xl`} style={{ color: iconColor }}></i>
                      </div>
                      <div className="ml-4 text-slate-600">
                        <p>Background: {iconBgColor}</p>
                        <p>Icon: {icon}</p>
                        <p>Color: {iconColor}</p>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Icon Settings */}
                <div className="space-y-6">
                  <div>
                    <Label>Select Icon</Label>
                    <div className="grid grid-cols-5 gap-2 mt-2 border border-slate-200 rounded-md p-3 max-h-[150px] overflow-y-auto">
                      {ICONS.map(iconOption => (
                        <div 
                          key={iconOption.name}
                          className={`w-10 h-10 rounded-full flex items-center justify-center cursor-pointer ${
                            icon === iconOption.name ? 'ring-2 ring-primary' : ''
                          }`}
                          style={{ backgroundColor: iconBgColor }}
                          onClick={() => setIcon(iconOption.name)}
                          title={iconOption.label}
                        >
                          <i className={`${iconOption.name}`} style={{ color: iconColor }}></i>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <Label>Background Color</Label>
                    <div className="grid grid-cols-8 gap-2 mt-2 border border-slate-200 rounded-md p-3">
                      {BG_COLORS.map(color => (
                        <div 
                          key={color.value}
                          className={`w-8 h-8 rounded-full cursor-pointer ${
                            iconBgColor === color.value ? 'ring-2 ring-primary' : ''
                          }`}
                          style={{ backgroundColor: color.value }}
                          onClick={() => setIconBgColor(color.value)}
                          title={color.label}
                        ></div>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <Label>Icon Color</Label>
                    <div className="grid grid-cols-8 gap-2 mt-2 border border-slate-200 rounded-md p-3">
                      {ICON_COLORS.map(color => (
                        <div 
                          key={color.value}
                          className={`w-8 h-8 rounded-full cursor-pointer ${
                            iconColor === color.value ? 'ring-2 ring-primary' : ''
                          }`}
                          style={{ backgroundColor: color.value }}
                          onClick={() => setIconColor(color.value)}
                          title={color.label}
                        ></div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="mt-8 flex justify-end space-x-3">
                <Button
                  type="button"
                  onClick={() => navigate("/admin/categories")}
                  variant="outline"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={saveCategory.isPending}
                >
                  {saveCategory.isPending ? (
                    <>
                      <i className="fas fa-spinner fa-spin mr-2"></i>
                      {isEditMode ? "Updating..." : "Creating..."}
                    </>
                  ) : (
                    <>
                      <i className="fas fa-save mr-2"></i>
                      {isEditMode ? "Update Category" : "Create Category"}
                    </>
                  )}
                </Button>
              </div>
            </form>
          </Card>
        </div>
      </main>
      
      <BottomNavigation />
    </div>
  );
}
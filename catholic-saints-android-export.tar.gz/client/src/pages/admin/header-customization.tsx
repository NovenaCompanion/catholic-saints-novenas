import * as React from "react";
import { useLocation } from "wouter";
import { Header } from "@/components/layout/header";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { ImageUploader } from "@/components/ui/image-uploader";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function HeaderCustomization() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [isSaving, setIsSaving] = React.useState(false);
  
  // Header settings
  const [headerImage, setHeaderImage] = React.useState("/uploads/images/header/religious-collage.png");
  const [startColor, setStartColor] = React.useState("#4338ca"); // Indigo-700
  const [endColor, setEndColor] = React.useState("#7e22ce"); // Purple-700
  const [logoSrc, setLogoSrc] = React.useState("/images/cross-icon.svg");
  
  // Load settings from localStorage on mount
  React.useEffect(() => {
    const savedSettings = localStorage.getItem("headerSettings");
    if (savedSettings) {
      try {
        const parsedSettings = JSON.parse(savedSettings);
        setHeaderImage(parsedSettings.headerImage || "");
        setStartColor(parsedSettings.startColor || "#4338ca");
        setEndColor(parsedSettings.endColor || "#7e22ce");
        setLogoSrc(parsedSettings.logoSrc || "/images/cross-icon.svg");
      } catch (error) {
        console.error("Error parsing saved header settings:", error);
      }
    }
  }, []);
  
  // Preview header style
  const headerStyle = {
    backgroundImage: headerImage 
      ? `linear-gradient(to right, rgba(67, 56, 202, 0.85), rgba(126, 34, 206, 0.85)), url(${headerImage})`
      : `linear-gradient(to right, ${startColor}, ${endColor})`,
    backgroundSize: "cover",
    backgroundPosition: "center",
  };
  
  const saveSettings = async () => {
    setIsSaving(true);
    
    try {
      // Save settings to localStorage
      const settings = {
        headerImage,
        startColor,
        endColor,
        logoSrc,
      };
      
      localStorage.setItem("headerSettings", JSON.stringify(settings));
      
      // Here you could also save to a server if needed
      // await apiRequest("POST", "/api/settings/header", settings);
      
      toast({
        title: "Settings Saved",
        description: "Header customization has been saved successfully.",
      });
    } catch (error) {
      console.error("Error saving header settings:", error);
      toast({
        title: "Error",
        description: "Failed to save header settings. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };
  
  const resetSettings = () => {
    setHeaderImage("");
    setStartColor("#4338ca"); // Indigo-700
    setEndColor("#7e22ce"); // Purple-700
    setLogoSrc("/images/cross-icon.svg");
    
    // Clear from localStorage
    localStorage.removeItem("headerSettings");
    
    toast({
      title: "Settings Reset",
      description: "Header customization has been reset to defaults.",
    });
  };
  
  return (
    <div className="min-h-screen flex flex-col">
      <div style={headerStyle} className="fixed top-0 left-0 right-0 z-10 shadow-md">
        <div className="container mx-auto px-4 py-3 flex justify-between items-center">
          <div className="flex items-center">
            <img 
              src={logoSrc} 
              alt="Logo" 
              className="w-6 h-6 mr-2"
            />
            <h1 className="text-white font-serif text-xl font-bold">
              My Novena Companion
            </h1>
          </div>
          <div className="flex items-center">
            <button className="text-white p-2" aria-label="Search">
              <i className="fas fa-search"></i>
            </button>
            <button className="text-white p-2 ml-2" aria-label="User profile">
              <i className="fas fa-user-circle"></i>
            </button>
          </div>
        </div>
      </div>
      
      <main className="flex-grow mt-14 mb-16">
        <div className="container mx-auto px-4 py-6">
          <div className="flex justify-between items-center mb-6">
            <h1 className="font-serif text-3xl font-bold">Header Customization</h1>
            <Button onClick={() => navigate("/admin")} variant="outline">
              <i className="fas fa-arrow-left mr-2"></i> Back to Admin
            </Button>
          </div>
          
          <Card className="bg-white rounded-lg shadow-md p-5 mb-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="headerImage">Background Image</Label>
                  <div className="mt-2">
                    <ImageUploader 
                      uploadType="header"
                      currentImageUrl={headerImage}
                      onImageUploaded={(url) => setHeaderImage(url)}
                    />
                    <p className="text-xs text-slate-500 mt-1">
                      Upload a background image for the header. Leave empty to use gradient only.
                    </p>
                  </div>
                </div>
                
                <div className="flex space-x-4">
                  <div className="w-1/2">
                    <Label htmlFor="startColor">Start Color</Label>
                    <div className="flex mt-2 space-x-2">
                      <Input
                        id="startColor"
                        type="text"
                        value={startColor}
                        onChange={(e) => setStartColor(e.target.value)}
                        className="flex-1"
                      />
                      <input
                        type="color"
                        value={startColor}
                        onChange={(e) => setStartColor(e.target.value)}
                        className="w-10 h-10 rounded border border-slate-300"
                      />
                    </div>
                  </div>
                  
                  <div className="w-1/2">
                    <Label htmlFor="endColor">End Color</Label>
                    <div className="flex mt-2 space-x-2">
                      <Input
                        id="endColor"
                        type="text"
                        value={endColor}
                        onChange={(e) => setEndColor(e.target.value)}
                        className="flex-1"
                      />
                      <input
                        type="color"
                        value={endColor}
                        onChange={(e) => setEndColor(e.target.value)}
                        className="w-10 h-10 rounded border border-slate-300"
                      />
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="space-y-4">
                <Label>Preview</Label>
                <div 
                  className="h-32 rounded-lg shadow-sm overflow-hidden"
                  style={headerStyle}
                >
                  <div className="h-full flex items-center p-4">
                    <div className="flex items-center">
                      <img 
                        src={logoSrc} 
                        alt="Logo" 
                        className="w-6 h-6 mr-2"
                      />
                      <h1 className="text-white font-serif text-xl font-bold">
                        My Novena Companion
                      </h1>
                    </div>
                  </div>
                </div>
                
                <div className="pt-4">
                  <p className="text-sm text-slate-600">
                    The header customization will be applied across the entire application.
                    You can adjust the gradient colors and optionally add a background image.
                  </p>
                </div>
              </div>
            </div>
            
            <div className="mt-8 flex justify-end space-x-3">
              <Button
                type="button"
                onClick={resetSettings}
                variant="outline"
              >
                <i className="fas fa-undo mr-2"></i>
                Reset to Default
              </Button>
              <Button
                type="button"
                onClick={saveSettings}
                disabled={isSaving}
              >
                {isSaving ? (
                  <>
                    <i className="fas fa-spinner fa-spin mr-2"></i>
                    Saving...
                  </>
                ) : (
                  <>
                    <i className="fas fa-save mr-2"></i>
                    Save Changes
                  </>
                )}
              </Button>
            </div>
          </Card>
        </div>
      </main>
      
      <BottomNavigation />
    </div>
  );
}
import React from "react";
import { useRoute } from "wouter";
import { ArrowLeft, Heart, Share2, Volume2, VolumeX } from "lucide-react";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface Mystery {
  type: string;
  number: number;
  title: string;
  meditation: string;
  virtue: string;
  prayer: string;
}

const mysteries: Record<string, Mystery[]> = {
  joyful: [
    {
      type: "Joyful",
      number: 1,
      title: "The Annunciation",
      meditation: "The Angel Gabriel announces to Mary that she is to be the Mother of God.",
      virtue: "Humility",
      prayer: "By this mystery and through the intercession of Mary, may we receive true humility."
    },
    {
      type: "Joyful",
      number: 2,
      title: "The Visitation",
      meditation: "Mary visits her cousin Elizabeth, who is with child (John the Baptist).",
      virtue: "Charity",
      prayer: "By this mystery and through the intercession of Mary, may we receive true charity toward our neighbor."
    },
    {
      type: "Joyful",
      number: 3,
      title: "The Nativity",
      meditation: "Jesus is born in a stable in Bethlehem.",
      virtue: "Poverty of Spirit",
      prayer: "By this mystery and through the intercession of Mary, may we receive the spirit of poverty and detachment from worldly goods."
    },
    {
      type: "Joyful",
      number: 4,
      title: "The Presentation",
      meditation: "Mary and Joseph present the infant Jesus in the Temple.",
      virtue: "Purity and Obedience",
      prayer: "By this mystery and through the intercession of Mary, may we receive the gift of purity and obedience."
    },
    {
      type: "Joyful",
      number: 5,
      title: "Finding Jesus in the Temple",
      meditation: "Mary and Joseph find the child Jesus in the Temple among the teachers.",
      virtue: "Joy in Finding Jesus",
      prayer: "By this mystery and through the intercession of Mary, may we have true devotion in seeking Jesus."
    }
  ],
  sorrowful: [
    {
      type: "Sorrowful",
      number: 1,
      title: "The Agony in the Garden",
      meditation: "Jesus prays in the Garden of Gethsemane on the night before He dies.",
      virtue: "Contrition for Sin",
      prayer: "By this mystery and through the intercession of Mary, may we receive true contrition for our sins."
    },
    {
      type: "Sorrowful",
      number: 2,
      title: "The Scourging at the Pillar",
      meditation: "Jesus is scourged by the Roman soldiers.",
      virtue: "Purity",
      prayer: "By this mystery and through the intercession of Mary, may we receive the spirit of mortification."
    },
    {
      type: "Sorrowful",
      number: 3,
      title: "The Crowning with Thorns",
      meditation: "Jesus is crowned with thorns and mocked as King.",
      virtue: "Humility",
      prayer: "By this mystery and through the intercession of Mary, may we receive moral courage."
    },
    {
      type: "Sorrowful",
      number: 4,
      title: "The Carrying of the Cross",
      meditation: "Jesus carries His cross to Calvary.",
      virtue: "Patience",
      prayer: "By this mystery and through the intercession of Mary, may we receive the gift of patience."
    },
    {
      type: "Sorrowful",
      number: 5,
      title: "The Crucifixion",
      meditation: "Jesus dies on the cross for our salvation.",
      virtue: "Self-Sacrifice",
      prayer: "By this mystery and through the intercession of Mary, may we receive final perseverance and a happy death."
    }
  ],
  glorious: [
    {
      type: "Glorious",
      number: 1,
      title: "The Resurrection",
      meditation: "Jesus rises from the dead on Easter Sunday.",
      virtue: "Faith",
      prayer: "By this mystery and through the intercession of Mary, may we receive a strong and living faith."
    },
    {
      type: "Glorious",
      number: 2,
      title: "The Ascension",
      meditation: "Jesus ascends into Heaven forty days after His Resurrection.",
      virtue: "Hope",
      prayer: "By this mystery and through the intercession of Mary, may we receive Christian hope and desire for Heaven."
    },
    {
      type: "Glorious",
      number: 3,
      title: "The Descent of the Holy Spirit",
      meditation: "The Holy Spirit descends upon Mary and the Apostles on Pentecost.",
      virtue: "Love of God",
      prayer: "By this mystery and through the intercession of Mary, may we receive the love of God and zeal for souls."
    },
    {
      type: "Glorious",
      number: 4,
      title: "The Assumption",
      meditation: "Mary is taken up into Heaven, body and soul.",
      virtue: "Grace of Good Death",
      prayer: "By this mystery and through the intercession of Mary, may we receive the grace of a good death."
    },
    {
      type: "Glorious",
      number: 5,
      title: "The Coronation",
      meditation: "Mary is crowned Queen of Heaven and Earth.",
      virtue: "Devotion to Mary",
      prayer: "By this mystery and through the intercession of Mary, may we receive devotion to Mary and the grace of final perseverance."
    }
  ],
  luminous: [
    {
      type: "Luminous",
      number: 1,
      title: "The Baptism of Jesus",
      meditation: "Jesus is baptized by John the Baptist in the Jordan River.",
      virtue: "Gratitude for Baptism",
      prayer: "By this mystery and through the intercession of Mary, may we live our baptismal promises."
    },
    {
      type: "Luminous",
      number: 2,
      title: "The Wedding at Cana",
      meditation: "Jesus performs His first miracle at the wedding feast of Cana.",
      virtue: "Trust in Mary's Intercession",
      prayer: "By this mystery and through the intercession of Mary, may we have complete trust in Mary's intercession."
    },
    {
      type: "Luminous",
      number: 3,
      title: "The Proclamation of the Kingdom",
      meditation: "Jesus proclaims the Kingdom of God and calls us to conversion.",
      virtue: "Conversion of Heart",
      prayer: "By this mystery and through the intercession of Mary, may we have true conversion of heart."
    },
    {
      type: "Luminous",
      number: 4,
      title: "The Transfiguration",
      meditation: "Jesus is transfigured on Mount Tabor before Peter, James, and John.",
      virtue: "Spiritual Courage",
      prayer: "By this mystery and through the intercession of Mary, may we receive spiritual courage to follow Christ."
    },
    {
      type: "Luminous",
      number: 5,
      title: "The Institution of the Eucharist",
      meditation: "Jesus institutes the Eucharist at the Last Supper.",
      virtue: "Eucharistic Devotion",
      prayer: "By this mystery and through the intercession of Mary, may we receive deeper love for the Eucharist."
    }
  ]
};

export default function MysteryDetail() {
  const [, params] = useRoute("/mystery/:type/:number");
  const [isPlaying, setIsPlaying] = React.useState(false);
  const speechRef = React.useRef<SpeechSynthesisUtterance | null>(null);

  if (!params) return null;

  const { type, number } = params;
  const mysteryList = mysteries[type.toLowerCase()];
  const mystery = mysteryList?.find(m => m.number === parseInt(number));

  if (!mystery) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 dark:from-gray-900 dark:to-gray-800 p-4">
        <div className="max-w-2xl mx-auto">
          <Card>
            <CardContent className="p-8 text-center">
              <h1 className="text-2xl font-bold mb-4">Mystery Not Found</h1>
              <Link href="/holy-rosary-home">
                <Button>Return to Holy Rosary</Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const toggleAudio = () => {
    if (isPlaying) {
      speechSynthesis.cancel();
      setIsPlaying(false);
    } else {
      const text = `${mystery.title}. ${mystery.meditation}. The virtue to contemplate is ${mystery.virtue}. ${mystery.prayer}`;
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.8;
      utterance.pitch = 1;
      utterance.onend = () => setIsPlaying(false);
      speechRef.current = utterance;
      speechSynthesis.speak(utterance);
      setIsPlaying(true);
    }
  };

  const shareContent = async () => {
    const text = `${mystery.title} - ${mystery.meditation}`;
    if (navigator.share) {
      await navigator.share({ title: mystery.title, text });
    } else {
      navigator.clipboard.writeText(text);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 dark:from-gray-900 dark:to-gray-800 p-4">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <Link href="/holy-rosary-home">
            <Button variant="ghost" size="sm" className="flex items-center gap-2">
              <ArrowLeft className="w-4 h-4" />
              Back to Holy Rosary
            </Button>
          </Link>
          <div className="flex gap-2">
            <Button variant="ghost" size="sm" onClick={toggleAudio}>
              {isPlaying ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </Button>
            <Button variant="ghost" size="sm" onClick={shareContent}>
              <Share2 className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Mystery Content */}
        <Card className="mb-6">
          <CardHeader className="bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-t-lg">
            <div className="text-center">
              <p className="text-sm opacity-90 mb-1">{mystery.type} Mystery</p>
              <CardTitle className="text-2xl font-bold">
                {mystery.number}. {mystery.title}
              </CardTitle>
            </div>
          </CardHeader>
          <CardContent className="p-8">
            <div className="space-y-6">
              {/* Meditation */}
              <div>
                <h3 className="text-lg font-semibold mb-3 text-gray-800 dark:text-gray-200">
                  ✠ Meditation ✠
                </h3>
                <p className="text-gray-700 dark:text-gray-300 leading-relaxed text-lg">
                  {mystery.meditation}
                </p>
              </div>

              {/* Virtue */}
              <div className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-gray-800 dark:to-gray-700 rounded-lg p-6">
                <h3 className="text-lg font-semibold mb-3 text-gray-800 dark:text-gray-200">
                  ✠ Virtue to Contemplate ✠
                </h3>
                <p className="text-blue-700 dark:text-blue-300 font-medium text-lg">
                  {mystery.virtue}
                </p>
              </div>

              {/* Prayer */}
              <div>
                <h3 className="text-lg font-semibold mb-3 text-gray-800 dark:text-gray-200">
                  ✠ Prayer ✠
                </h3>
                <p className="text-gray-700 dark:text-gray-300 leading-relaxed text-lg italic">
                  {mystery.prayer}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="flex justify-between items-center">
          {mystery.number > 1 && (
            <Link href={`/mystery/${type}/${mystery.number - 1}`}>
              <Button variant="outline" className="flex items-center gap-2">
                <ArrowLeft className="w-4 h-4" />
                Previous Mystery
              </Button>
            </Link>
          )}
          <div className="flex-1"></div>
          {mystery.number < mysteryList.length && (
            <Link href={`/mystery/${type}/${mystery.number + 1}`}>
              <Button variant="outline" className="flex items-center gap-2">
                Next Mystery
                <ArrowLeft className="w-4 h-4 rotate-180" />
              </Button>
            </Link>
          )}
        </div>
      </div>
    </div>
  );
}
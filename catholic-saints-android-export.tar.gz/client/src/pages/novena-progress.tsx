import * as React from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { format, addDays } from "date-fns";
import { Header } from "@/components/layout/header";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { ProgressCircle } from "@/components/ui/progress-circle";
import { Badge } from "@/components/ui/badge";
import { NovenaResponse, NovenaPrayerResponse } from "@/lib/types";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Play, Pause, Share2, Copy, Heart, Star, ChevronLeft, ChevronRight, Calendar, Clock, Bookmark, ArrowLeft, TrendingUp, CheckCircle } from "lucide-react";

export default function NovenaProgress() {
  const params = useParams();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const novenaId = params.id;
  const [editingIntention, setEditingIntention] = React.useState(false);
  const [intention, setIntention] = React.useState("");
  
  // Audio playback state
  const [isPlaying, setIsPlaying] = React.useState(false);
  const speechRef = React.useRef<SpeechSynthesisUtterance | null>(null);
  
  // Prayer interaction states
  const [isFavorited, setIsFavorited] = React.useState(false);
  const [showShareMenu, setShowShareMenu] = React.useState(false);
  const [currentDay, setCurrentDay] = React.useState(1);
  
  // Fetch novena details
  const { data: novena, isLoading } = useQuery({
    queryKey: [`/api/novenas/${novenaId}`],
  });
  
  // Update currentDay when novena data loads
  React.useEffect(() => {
    if (novena) {
      setCurrentDay((novena as NovenaResponse).currentDay);
    }
  }, [novena]);
  
  // Get the current day's prayer when novena data is available
  const { data: dailyPrayer, isLoading: isLoadingPrayer } = useQuery<NovenaPrayerResponse>({
    queryKey: [`/api/saints/${(novena as NovenaResponse)?.saintId}/prayers/${currentDay}`],
    enabled: !!novena, // Only run this query when we have the novena data
  });
  
  // Update current day/progress mutation
  const markDayComplete = useMutation({
    mutationFn: async () => {
      const typedNovena = novena as NovenaResponse;
      const response = await apiRequest(
        "PATCH", 
        `/api/novenas/${novenaId}/progress`, 
        { day: typedNovena.currentDay }
      );
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/novenas/${novenaId}`] });
      queryClient.invalidateQueries({ queryKey: ["/api/novenas"] });
      toast({
        title: "Prayer Completed",
        description: "Today's prayer has been marked as complete.",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to Update Progress",
        description: "There was an error updating your novena progress.",
        variant: "destructive",
      });
      console.error("Error updating novena progress:", error);
    },
  });
  
  // Update intention mutation
  const updateIntention = useMutation({
    mutationFn: async () => {
      const response = await apiRequest(
        "PATCH", 
        `/api/novenas/${novenaId}/intention`, 
        { intention }
      );
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/novenas/${novenaId}`] });
      setEditingIntention(false);
      toast({
        title: "Intention Updated",
        description: "Your novena intention has been updated.",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to Update Intention",
        description: "There was an error updating your intention.",
        variant: "destructive",
      });
      console.error("Error updating intention:", error);
    },
  });
  
  // Initialize intention from novena data
  React.useEffect(() => {
    if (novena) {
      setIntention((novena as NovenaResponse).intention || "");
    }
  }, [novena]);

  // Audio functionality
  const toggleAudio = () => {
    if (!dailyPrayer?.content) return;

    if (isPlaying) {
      window.speechSynthesis.cancel();
      setIsPlaying(false);
    } else {
      const utterance = new SpeechSynthesisUtterance(dailyPrayer.content);
      utterance.rate = 0.8;
      utterance.pitch = 1.0;
      utterance.volume = 0.9;
      
      utterance.onend = () => setIsPlaying(false);
      utterance.onerror = () => setIsPlaying(false);
      
      speechRef.current = utterance;
      window.speechSynthesis.speak(utterance);
      setIsPlaying(true);
    }
  };

  // Copy prayer text
  const copyPrayer = async () => {
    if (dailyPrayer?.content) {
      await navigator.clipboard.writeText(dailyPrayer.content);
      toast({
        title: "Prayer Copied",
        description: "The prayer has been copied to your clipboard.",
      });
    }
  };

  // Share prayer
  const sharePrayer = async () => {
    if (dailyPrayer?.content && navigator.share) {
      try {
        await navigator.share({
          title: dailyPrayer.title || "Daily Prayer",
          text: dailyPrayer.content,
        });
      } catch (error) {
        copyPrayer(); // Fallback to copy
      }
    } else {
      copyPrayer();
    }
  };

  // Cleanup audio on unmount
  React.useEffect(() => {
    return () => {
      if (speechRef.current) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);
  
  const navigateBack = () => {
    navigate("/novenas");
  };
  
  const handleIntentionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateIntention.mutate();
  };
  
  if (isLoading || isLoadingPrayer) {
    return (
      <div className="min-h-screen flex flex-col bg-gradient-to-br from-blue-50 via-white to-purple-50">
        <Header />
        <main className="flex-grow mt-14 mb-16">
          <div className="container mx-auto px-4 py-8 text-center">
            <div className="mt-20">
              <div className="w-16 h-16 mx-auto mb-6 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center animate-pulse">
                <Heart className="w-8 h-8 text-white" />
              </div>
              <p className="text-lg text-slate-600 font-medium">Loading your sacred journey...</p>
              <p className="text-sm text-slate-400 mt-2">Preparing your daily prayer</p>
            </div>
          </div>
        </main>
        <BottomNavigation />
      </div>
    );
  }
  
  const typedNovena = novena as NovenaResponse;
  const novenaLength = typedNovena.saint?.novenaLength || 9;
  const progressPercentage = (typedNovena.completedDays.length / novenaLength) * 100;
  
  // Calculate dates for each day of the novena
  const startDate = new Date(typedNovena.startDate);
  const dates = Array.from({ length: novenaLength }, (_, i) => 
    format(addDays(startDate, i), "MMM d")
  );
  
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <Header />
      
      <main className="flex-grow mt-14 mb-16">
        <div className="container mx-auto px-4 py-6 max-w-4xl">
          {/* Enhanced Header with Saint Image */}
          <div className="relative mb-8">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl blur-xl opacity-20 transform scale-110"></div>
            <Card className="relative bg-white/80 backdrop-blur-sm border-0 shadow-xl rounded-2xl overflow-hidden">
              <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-6">
                <div className="flex items-center justify-between">
                  <button 
                    onClick={navigateBack}
                    className="flex items-center gap-2 text-white/80 hover:text-white transition-colors"
                  >
                    <ArrowLeft className="w-5 h-5" />
                    <span className="font-medium">My Novenas</span>
                  </button>
                  <Badge variant="secondary" className="bg-white/20 text-white border-0">
                    <Calendar className="w-4 h-4 mr-1" />
                    {novenaLength === 1 ? "Daily Prayer" : `Day ${typedNovena.currentDay} of ${novenaLength}`}
                  </Badge>
                </div>
                
                <div className="mt-6 flex items-center gap-4">
                  {typedNovena.saint?.imageUrl && (
                    <div className="w-16 h-16 rounded-full overflow-hidden border-3 border-white/30 shadow-lg">
                      <img 
                        src={typedNovena.saint.imageUrl} 
                        alt={typedNovena.saint.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  )}
                  <div className="flex-1">
                    <h1 className="text-2xl font-bold text-white mb-1">
                      {novenaLength === 1 ? typedNovena.saint?.name : `${typedNovena.saint?.name} Novena`}
                    </h1>
                    <p className="text-white/80 text-sm flex items-center gap-2">
                      <Clock className="w-4 h-4" />
                      Started: {format(new Date(typedNovena.startDate), "MMM d, yyyy")}
                    </p>
                  </div>
                </div>
              </div>
            </Card>
          </div>
          
          {/* Enhanced Progress Overview */}
          <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-2xl rounded-3xl overflow-hidden mb-8">
            {/* Progress Header */}
            <div className="bg-gradient-to-r from-emerald-500 via-blue-500 to-purple-600 p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="bg-white/20 rounded-full p-3">
                    <Star className="w-8 h-8 text-white" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-white mb-1">
                      {novenaLength === 1 ? "Your Daily Devotion" : "Your Prayer Journey"}
                    </h3>
                    <p className="text-white/80 text-sm">
                      {novenaLength === 1 ? "Sacred daily practice" : "Sacred devotion progress"}
                    </p>
                  </div>
                </div>
                {novenaLength > 1 && (
                  <div className="text-right">
                    <div className="text-4xl font-bold text-white mb-1">
                      {Math.round(progressPercentage)}%
                    </div>
                    <p className="text-white/80 text-sm">Complete</p>
                  </div>
                )}
              </div>
            </div>

            {/* Progress Stats Cards */}
            <div className="p-6">
              {novenaLength === 1 ? (
                // Daily Devotion Stats
                <div className="grid grid-cols-2 gap-4 mb-6">
                  {/* Times Prayed */}
                  <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl p-4 border border-blue-100">
                    <div className="text-center">
                      <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full flex items-center justify-center mx-auto mb-3">
                        <Heart className="w-6 h-6 text-white" />
                      </div>
                      <div className="text-2xl font-bold text-blue-700 mb-1">
                        {typedNovena.completedDays.length}
                      </div>
                      <p className="text-blue-600 text-xs font-medium">Times Prayed</p>
                    </div>
                  </div>

                  {/* Started */}
                  <div className="bg-gradient-to-br from-emerald-50 to-green-50 rounded-2xl p-4 border border-emerald-100">
                    <div className="text-center">
                      <div className="w-12 h-12 bg-gradient-to-r from-emerald-500 to-green-500 rounded-full flex items-center justify-center mx-auto mb-3">
                        <Calendar className="w-6 h-6 text-white" />
                      </div>
                      <div className="text-2xl font-bold text-emerald-700 mb-1">
                        {format(new Date(typedNovena.startDate), "MMM d")}
                      </div>
                      <p className="text-emerald-600 text-xs font-medium">Started</p>
                    </div>
                  </div>
                </div>
              ) : (
                // Regular Novena Stats
                <div className="grid grid-cols-3 gap-4 mb-6">
                  {/* Days Completed */}
                  <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-2xl p-4 border border-green-100">
                    <div className="text-center">
                      <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full flex items-center justify-center mx-auto mb-3">
                        <Heart className="w-6 h-6 text-white" />
                      </div>
                      <div className="text-2xl font-bold text-green-700 mb-1">
                        {typedNovena.completedDays.length}
                      </div>
                      <p className="text-green-600 text-xs font-medium">Completed</p>
                    </div>
                  </div>

                  {/* Current Day */}
                  <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl p-4 border border-blue-100">
                    <div className="text-center">
                      <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full flex items-center justify-center mx-auto mb-3">
                        <Clock className="w-6 h-6 text-white" />
                      </div>
                      <div className="text-2xl font-bold text-blue-700 mb-1">
                        {typedNovena.currentDay}
                      </div>
                      <p className="text-blue-600 text-xs font-medium">Today</p>
                    </div>
                  </div>

                  {/* Remaining Days */}
                  <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl p-4 border border-purple-100">
                    <div className="text-center">
                      <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-3">
                        <Calendar className="w-6 h-6 text-white" />
                      </div>
                      <div className="text-2xl font-bold text-purple-700 mb-1">
                        {novenaLength - typedNovena.completedDays.length}
                      </div>
                      <p className="text-purple-600 text-xs font-medium">Remaining</p>
                    </div>
                  </div>
                </div>
              )}
              
              {/* Enhanced Progress Bar with Gradient - Only for multi-day novenas */}
              {novenaLength > 1 && (
                <div className="mb-6 relative">
                  <div className="h-3 bg-slate-100 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-blue-500 to-purple-600 rounded-full transition-all duration-500 ease-out relative"
                      style={{ width: `${progressPercentage}%` }}
                    >
                      <div className="absolute inset-0 bg-white/20 animate-pulse"></div>
                    </div>
                  </div>
                  <div className="flex justify-between mt-2 text-xs text-slate-500">
                    <span>Start</span>
                    <span>Day {typedNovena.currentDay}</span>
                    <span>Complete</span>
                  </div>
                </div>
              )}
            
            {/* Days Progress - Only for multi-day novenas */}
            {novenaLength > 1 && novenaLength <= 9 ? (
              // For novenas with 9 or fewer days
              <div className="grid grid-cols-9 gap-1 mb-4">
                {Array.from({ length: novenaLength }, (_, i) => i + 1).map((day) => (
                  <ProgressCircle
                    key={day}
                    day={day}
                    status={
                      typedNovena.completedDays.includes(day) 
                        ? "completed" 
                        : day === typedNovena.currentDay 
                          ? "current" 
                          : "pending"
                    }
                    date={dates[day - 1]}
                  />
                ))}
              </div>
            ) : novenaLength > 1 && novenaLength <= 18 ? (
              // For novenas with 10-18 days, show in 2 rows
              <div className="space-y-3 mb-4">
                <div className="grid grid-cols-9 gap-1">
                  {Array.from({ length: 9 }, (_, i) => i + 1).map((day) => (
                    <ProgressCircle
                      key={day}
                      day={day}
                      status={
                        typedNovena.completedDays.includes(day) 
                          ? "completed" 
                          : day === typedNovena.currentDay 
                            ? "current" 
                            : "pending"
                      }
                      date={dates[day - 1]}
                    />
                  ))}
                </div>
                <div className="grid grid-cols-9 gap-1">
                  {Array.from({ length: novenaLength - 9 }, (_, i) => i + 10).map((day) => (
                    <ProgressCircle
                      key={day}
                      day={day}
                      status={
                        typedNovena.completedDays.includes(day) 
                          ? "completed" 
                          : day === typedNovena.currentDay 
                            ? "current" 
                            : "pending"
                      }
                      date={dates[day - 1]}
                    />
                  ))}
                </div>
              </div>
            ) : novenaLength > 1 ? (
              // For longer novenas (up to 54 days), show with pagination
              <div className="space-y-3 mb-4">
                <div className="grid grid-cols-9 gap-1">
                  {/* Show 9 days at a time based on current day */}
                  {(() => {
                    const currentGroup = Math.floor((typedNovena.currentDay - 1) / 9);
                    const startDay = currentGroup * 9 + 1;
                    const endDay = Math.min(startDay + 8, novenaLength);
                    
                    return Array.from(
                      { length: endDay - startDay + 1 }, 
                      (_, i) => startDay + i
                    ).map((day) => (
                      <ProgressCircle
                        key={day}
                        day={day}
                        status={
                          typedNovena.completedDays.includes(day) 
                            ? "completed" 
                            : day === typedNovena.currentDay 
                              ? "current" 
                              : "pending"
                        }
                        date={dates[day - 1]}
                      />
                    ));
                  })()}
                </div>
                
                {/* Progress indicators */}
                <div className="flex justify-center items-center space-x-1">
                  {Array.from(
                    { length: Math.ceil(novenaLength / 9) }, 
                    (_, i) => i
                  ).map((groupIndex) => {
                    const currentGroup = Math.floor((typedNovena.currentDay - 1) / 9);
                    return (
                      <div 
                        key={groupIndex}
                        className={`w-2 h-2 rounded-full ${
                          groupIndex === currentGroup 
                            ? 'bg-primary' 
                            : 'bg-slate-300'
                        }`}
                      />
                    );
                  })}
                </div>
                
                {/* Day range text */}
                <div className="text-center text-sm text-slate-500">
                  Showing days {Math.floor((typedNovena.currentDay - 1) / 9) * 9 + 1} 
                  - {Math.min((Math.floor((typedNovena.currentDay - 1) / 9) + 1) * 9, novenaLength)} 
                  of {novenaLength}
                </div>
              </div>
            ) : null}
            </div>
          </Card>
          
          {/* Enhanced Today's Prayer Section */}
          <Card className="bg-white/95 backdrop-blur-md border-0 shadow-2xl rounded-3xl overflow-hidden mb-8">
            {/* Prayer Header with Gradient */}
            <div className="bg-gradient-to-r from-rose-500 via-pink-500 to-purple-600 p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="bg-white/20 rounded-full p-3">
                    <Heart className="w-8 h-8 text-white" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-white mb-1">
                      {novenaLength === 1 ? "Daily Sacred Prayer" : "Today's Sacred Prayer"}
                    </h3>
                    <p className="text-white/80 text-sm flex items-center gap-2">
                      <Calendar className="w-4 h-4" />
                      {novenaLength === 1 
                        ? format(new Date(), "EEEE, MMM d") 
                        : `Day ${typedNovena.currentDay} of ${novenaLength} • ${format(new Date(), "EEEE, MMM d")}`
                      }
                    </p>
                  </div>
                </div>
                
                {/* Enhanced Prayer Actions */}
                <div className="flex items-center gap-3">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={toggleAudio}
                    className="h-12 w-12 p-0 hover:bg-white/20 rounded-full transition-all duration-300 transform hover:scale-110"
                  >
                    {isPlaying ? <Pause className="w-6 h-6 text-white" /> : <Play className="w-6 h-6 text-white" />}
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={copyPrayer}
                    className="h-12 w-12 p-0 hover:bg-white/20 rounded-full transition-all duration-300 transform hover:scale-110"
                  >
                    <Copy className="w-6 h-6 text-white" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={sharePrayer}
                    className="h-12 w-12 p-0 hover:bg-white/20 rounded-full transition-all duration-300 transform hover:scale-110"
                  >
                    <Share2 className="w-6 h-6 text-white" />
                  </Button>
                </div>
              </div>

              {/* Daily Encouragement */}
              <div className="mt-4 p-4 bg-white/10 backdrop-blur-sm rounded-2xl border border-white/20">
                <p className="text-white/90 text-center font-medium">
                  "Continue steadfast in prayer, being watchful in it with thanksgiving." - Col 4:2
                </p>
              </div>
            </div>
            
            {/* Prayer Content Section */}
            <div className="p-8">
              {dailyPrayer && (
                <>
                  {dailyPrayer.title && (
                    <div className="mb-8 text-center">
                      <h4 className="text-3xl font-bold bg-gradient-to-r from-rose-600 via-purple-600 to-blue-600 bg-clip-text text-transparent mb-3">
                        {dailyPrayer.title}
                      </h4>
                      <div className="h-1 w-32 bg-gradient-to-r from-rose-500 via-purple-500 to-blue-500 rounded-full mx-auto"></div>
                    </div>
                  )}
                  
                  {/* Enhanced Prayer Text Container */}
                  <div className="mb-8">
                    <div className="bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 rounded-3xl p-8 border border-blue-100 shadow-inner">
                      <div className="max-w-none text-lg leading-relaxed">
                        {dailyPrayer.content.split('\n\n').map((paragraph: string, index: number) => (
                          <div key={index} className="mb-6 last:mb-0">
                            {paragraph.split('\n').map((line: string, lineIndex: number) => (
                              <p key={lineIndex} className="mb-3 last:mb-0 text-slate-800 leading-8 font-medium">
                                {line}
                              </p>
                            ))}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Prayer Intention Reminder */}
                  {typedNovena.intention && (
                    <div className="mb-8 p-6 bg-gradient-to-r from-amber-50 to-yellow-50 rounded-2xl border border-amber-200">
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 bg-gradient-to-r from-amber-500 to-yellow-500 rounded-full flex items-center justify-center flex-shrink-0">
                          <Heart className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <h5 className="font-bold text-amber-800 mb-2">Your Prayer Intention</h5>
                          <p className="text-amber-700 leading-relaxed italic">"{typedNovena.intention}"</p>
                        </div>
                      </div>
                    </div>
                  )}
                </>
              )}
              
              {!dailyPrayer && typedNovena.saint?.prayer && (
                <>
                  <div className="mb-6">
                    <h4 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-2">
                      Daily Prayer
                    </h4>
                    <div className="h-1 w-20 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full"></div>
                  </div>
                  
                  <div className="prose prose-lg prose-slate max-w-none mb-8">
                    <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl p-6 border-l-4 border-blue-500">
                      {typedNovena.saint.prayer.split('\n\n').map((paragraph: string, index: number) => (
                        <div key={index} className="mb-4 last:mb-0">
                          {paragraph.split('\n').map((line: string, lineIndex: number) => (
                            <p key={lineIndex} className="mb-2 last:mb-0 text-slate-700 leading-relaxed">
                              {line}
                            </p>
                          ))}
                        </div>
                      ))}
                    </div>
                  </div>
                </>
              )}
              
              {!dailyPrayer && !typedNovena.saint?.prayer && (
                <div className="text-center py-12">
                  <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-slate-200 to-slate-300 rounded-full flex items-center justify-center">
                    <Bookmark className="w-8 h-8 text-slate-500" />
                  </div>
                  <p className="text-slate-600 text-lg">Prayer content is loading...</p>
                  <p className="text-slate-400 text-sm mt-1">Please wait while we prepare your daily prayer</p>
                </div>
              )}
              
              {/* Enhanced Complete Actions */}
              <div className="flex justify-center">
                {typedNovena.isComplete && (
                  <div className="flex items-center gap-3 px-6 py-4 bg-gradient-to-r from-emerald-100 to-green-100 text-emerald-800 rounded-xl border border-emerald-200">
                    <div className="w-12 h-12 bg-gradient-to-r from-emerald-500 to-green-500 rounded-full flex items-center justify-center">
                      <Star className="w-6 h-6 text-white fill-current" />
                    </div>
                    <div>
                      <p className="font-bold text-lg">Novena Completed!</p>
                      <p className="text-sm text-emerald-600">Your spiritual journey is complete</p>
                    </div>
                  </div>
                )}
                
                {!typedNovena.isComplete && typedNovena.completedDays.includes(typedNovena.currentDay) && (
                  <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-3xl p-8 border border-green-200 max-w-md mx-auto">
                    <div className="text-center">
                      <div className="w-20 h-20 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Star className="w-10 h-10 text-white" />
                      </div>
                      <h3 className="text-2xl font-bold text-green-800 mb-2">Prayer Completed!</h3>
                      <p className="text-green-700 mb-4">Today's sacred prayer has been offered with devotion</p>
                      <div className="text-green-600 text-sm font-medium">
                        Come back tomorrow to continue your spiritual journey
                      </div>
                    </div>
                  </div>
                )}
                
                {!typedNovena.isComplete && !typedNovena.completedDays.includes(typedNovena.currentDay) && (
                  <div className="text-center">
                    <Button
                      onClick={() => markDayComplete.mutate()}
                      disabled={markDayComplete.isPending}
                      size="lg"
                      className="px-12 py-6 text-xl font-bold rounded-full bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 hover:from-blue-600 hover:via-purple-600 hover:to-pink-600 text-white shadow-2xl hover:shadow-3xl transform hover:scale-105 transition-all duration-300 disabled:opacity-50 disabled:transform-none"
                    >
                      {markDayComplete.isPending ? (
                        <div className="flex items-center gap-3">
                          <div className="w-6 h-6 border-3 border-white/30 border-t-white rounded-full animate-spin"></div>
                          Offering Prayer...
                        </div>
                      ) : (
                        <div className="flex items-center gap-3">
                          <Heart className="w-7 h-7" />
                          Complete Sacred Prayer
                        </div>
                      )}
                    </Button>
                    <p className="text-slate-500 text-sm mt-4">
                      Mark your prayer as complete to continue your novena journey
                    </p>
                  </div>
                )}
              </div>
            </div>
          </Card>
          
          {/* Intention Section */}
          <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl rounded-2xl overflow-hidden mb-8">
            <div className="bg-gradient-to-r from-emerald-50 to-teal-50 border-b p-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-full flex items-center justify-center">
                  <Heart className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-slate-800">Your Sacred Intention</h3>
                  <p className="text-sm text-slate-600">The prayer request that guides your novena</p>
                </div>
              </div>
            </div>
            
            <div className="p-6">
              {editingIntention ? (
                <form onSubmit={handleIntentionSubmit} className="space-y-6">
                  <div>
                    <p className="text-slate-600 mb-4 leading-relaxed">
                      Share your heart's deepest prayer. This intention will accompany each day of your novena journey.
                    </p>
                    <div className="relative">
                      <Input
                        value={intention}
                        onChange={(e) => setIntention(e.target.value)}
                        placeholder="Enter your prayer intention..."
                        className="w-full p-4 text-lg border-2 border-slate-200 rounded-xl focus:border-blue-500 focus:ring-0 bg-white/50 backdrop-blur-sm"
                      />
                    </div>
                  </div>
                  
                  <div className="flex justify-end gap-3">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setEditingIntention(false)}
                      className="px-6 py-2 rounded-xl border-2 hover:bg-slate-50"
                    >
                      Cancel
                    </Button>
                    <Button 
                      type="submit" 
                      disabled={updateIntention.isPending}
                      className="px-6 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white shadow-lg"
                    >
                      {updateIntention.isPending ? (
                        <div className="flex items-center gap-2">
                          <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                          Saving...
                        </div>
                      ) : (
                        <div className="flex items-center gap-2">
                          <Bookmark className="w-4 h-4" />
                          Save Intention
                        </div>
                      )}
                    </Button>
                  </div>
                </form>
              ) : (
                <div className="space-y-6">
                  <div className="relative">
                    <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl p-6 border-l-4 border-emerald-500 min-h-[120px] flex items-center">
                      {typedNovena.intention ? (
                        <p className="text-slate-700 text-lg leading-relaxed italic font-medium">
                          "{typedNovena.intention}"
                        </p>
                      ) : (
                        <div className="text-center w-full">
                          <div className="w-12 h-12 mx-auto mb-3 bg-gradient-to-r from-slate-300 to-slate-400 rounded-full flex items-center justify-center">
                            <Heart className="w-6 h-6 text-white" />
                          </div>
                          <p className="text-slate-500 text-lg">No intention set yet</p>
                          <p className="text-slate-400 text-sm mt-1">Add your prayer request to personalize this novena</p>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex justify-center">
                    <Button
                      onClick={() => setEditingIntention(true)}
                      variant="outline"
                      className="px-6 py-3 rounded-xl border-2 border-emerald-200 text-emerald-700 hover:bg-emerald-50 hover:border-emerald-300 transition-all duration-200"
                    >
                      <div className="flex items-center gap-2">
                        <Heart className="w-4 h-4" />
                        {typedNovena.intention ? "Update Intention" : "Add Intention"}
                      </div>
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </Card>
          
          {/* Enhanced Day Navigation */}
          <Card className="bg-white/95 backdrop-blur-md border-0 shadow-2xl rounded-3xl overflow-hidden">
            <div className="bg-gradient-to-r from-slate-50 to-gray-50 p-6 border-b">
              <h3 className="text-xl font-bold text-slate-800 text-center mb-2">Prayer Journey Navigation</h3>
              <p className="text-slate-600 text-sm text-center">Navigate through your novena days</p>
            </div>
            
            <div className="p-8">
              <div className="flex items-center justify-between">
                <Button
                  variant="outline"
                  onClick={() => setCurrentDay(Math.max(1, typedNovena.currentDay - 1))}
                  disabled={typedNovena.currentDay === 1}
                  className="flex items-center gap-3 px-8 py-4 rounded-2xl border-2 border-slate-200 hover:border-blue-400 hover:bg-blue-50 transition-all duration-300 disabled:opacity-40"
                >
                  <ChevronLeft className="w-6 h-6" />
                  <div className="text-left">
                    <div className="font-semibold">Previous Day</div>
                    <div className="text-xs text-slate-500">Day {Math.max(1, typedNovena.currentDay - 1)}</div>
                  </div>
                </Button>
                
                <div className="text-center px-8">
                  <div className="w-20 h-20 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-3">
                    <div className="text-2xl font-bold text-white">{typedNovena.currentDay}</div>
                  </div>
                  <div className="text-lg font-bold text-slate-800">Current Day</div>
                  <div className="text-sm text-slate-500">of {novenaLength} total days</div>
                </div>
                
                <Button
                  variant="outline"
                  onClick={() => setCurrentDay(Math.min(novenaLength, typedNovena.currentDay + 1))}
                  disabled={typedNovena.currentDay === novenaLength}
                  className="flex items-center gap-3 px-8 py-4 rounded-2xl border-2 border-slate-200 hover:border-purple-400 hover:bg-purple-50 transition-all duration-300 disabled:opacity-40"
                >
                  <div className="text-right">
                    <div className="font-semibold">Next Day</div>
                    <div className="text-xs text-slate-500">Day {Math.min(novenaLength, typedNovena.currentDay + 1)}</div>
                  </div>
                  <ChevronRight className="w-6 h-6" />
                </Button>
              </div>
            </div>
          </Card>
        </div>
      </main>
      
      <BottomNavigation />
    </div>
  );
}

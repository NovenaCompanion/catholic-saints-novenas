import * as React from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Header } from "@/components/layout/header";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { SaintCard } from "@/components/saints/saint-card";
import { CategoryCard } from "@/components/saints/category-card";
import { SaintResponse, CategoryResponse, CategoryWithCount, ActiveNovena } from "@/lib/types";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Search, X } from "lucide-react";

export default function Saints() {
  const [, navigate] = useLocation();
  const [searchTerm, setSearchTerm] = React.useState("");
  const [filteredSaints, setFilteredSaints] = React.useState<SaintResponse[]>([]);
  const [isSearchOpen, setIsSearchOpen] = React.useState(false);
  const [searchResults, setSearchResults] = React.useState({
    saints: [] as SaintResponse[],
    categories: [] as CategoryResponse[]
  });
  const [showResults, setShowResults] = React.useState(false);
  const searchInputRef = React.useRef<HTMLInputElement>(null);
  
  // Fetch all saints
  const { data: saints, isLoading: loadingSaints } = useQuery({
    queryKey: ["/api/saints"],
  });
  
  // Fetch all categories
  const { data: categories, isLoading: loadingCategories } = useQuery({
    queryKey: ["/api/categories"],
  });
  
  // Fetch user's active novenas for navigation logic
  const { data: userNovenas = [] } = useQuery<ActiveNovena[]>({
    queryKey: ["/api/novenas"],
  });
  
  // Navigate to search result with direct navigation
  const navigateToResult = (type: 'saint' | 'category', id?: number) => {
    console.log('=== MAIN SEARCH NAVIGATION ===');
    console.log('Type:', type, 'ID:', id);
    
    // Close search immediately
    setIsSearchOpen(false);
    setSearchTerm("");
    setSearchResults({ saints: [], categories: [] });
    setShowResults(false);

    // Use a timeout to ensure state updates complete
    setTimeout(() => {
      if (type === 'saint' && id) {
        console.log('Navigating to saint:', id);
        
        // Special cases first
        if (id === 9) {
          console.log('Going to Rosary Novena Home');
          window.location.href = '/rosary-novena-home';
        } else if (id === 10) {
          console.log('Going to Consecration Home');
          window.location.href = '/consecration-home';
        } else {
          console.log('Going to saint detail:', id);
          window.location.href = `/saint/${id}`;
        }
      } else if (type === 'category' && id) {
        console.log('Going to category:', id);
        window.location.href = `/category/${id}`;
      }
    }, 100);
  };

  // Enhanced search functionality with dropdown
  const performSearch = (query: string) => {
    if (!query || query.length < 2) {
      setSearchResults({ saints: [], categories: [] });
      setShowResults(false);
      return;
    }

    const lowercaseQuery = query.toLowerCase();
    
    // Search saints
    const matchingSaints = (saints as SaintResponse[] || [])
      .filter((saint: SaintResponse) => 
        saint.name.toLowerCase().includes(lowercaseQuery) || 
        (saint.title && saint.title.toLowerCase().includes(lowercaseQuery)) ||
        saint.description.toLowerCase().includes(lowercaseQuery) ||
        (saint.patronOf && saint.patronOf.toLowerCase().includes(lowercaseQuery))
      )
      .slice(0, 5); // Limit to 5 results

    // Search categories
    const matchingCategories = (categories as CategoryResponse[] || [])
      .filter((category: CategoryResponse) => 
        category.name.toLowerCase().includes(lowercaseQuery) ||
        (category.description && category.description.toLowerCase().includes(lowercaseQuery))
      )
      .slice(0, 3); // Limit to 3 results

    setSearchResults({
      saints: matchingSaints,
      categories: matchingCategories
    });
    setShowResults(true);
  };

  // Handle search for the input field
  const handleInputSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const query = e.target.value;
    setSearchTerm(query);
    
    // Perform dropdown search
    performSearch(query);
    
    if (!saints) return;
    
    if (!query) {
      setFilteredSaints(saints as SaintResponse[]);
      return;
    }
    
    const lowercaseQuery = query.toLowerCase();
    const filtered = (saints as SaintResponse[]).filter((saint: SaintResponse) => 
      saint.name.toLowerCase().includes(lowercaseQuery) || 
      (saint.title && saint.title.toLowerCase().includes(lowercaseQuery)) ||
      saint.description.toLowerCase().includes(lowercaseQuery) ||
      (saint.patronOf && saint.patronOf.toLowerCase().includes(lowercaseQuery))
    );
    
    setFilteredSaints(filtered);
  };
  
  // Set filtered saints when data is loaded
  React.useEffect(() => {
    if (saints) {
      setFilteredSaints(saints as SaintResponse[]);
    }
  }, [saints]);

  // Handle click outside to close search dropdown
  React.useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchInputRef.current && !searchInputRef.current.contains(event.target as Node)) {
        setShowResults(false);
      }
    };

    if (showResults) {
      document.addEventListener('mousedown', handleClickOutside);
      return () => document.removeEventListener('mousedown', handleClickOutside);
    }
  }, [showResults]);
  
  // Use categories with saint counts directly from backend
  const categoriesWithCounts = React.useMemo(() => {
    if (!categories) return [];
    
    // Backend already provides saint counts, so use them directly
    return (categories as CategoryResponse[]).map((category: CategoryResponse): CategoryWithCount => ({
      ...category,
      saintCount: category.saintCount || 0
    }));
  }, [categories]);
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header onSearch={(query) => {
        setSearchTerm(query);
        
        if (!saints) return;
        
        if (!query) {
          setFilteredSaints(saints as SaintResponse[]);
          return;
        }
        
        const lowercaseQuery = query.toLowerCase();
        const filtered = (saints as SaintResponse[]).filter((saint: SaintResponse) => 
          saint.name.toLowerCase().includes(lowercaseQuery) || 
          (saint.title && saint.title.toLowerCase().includes(lowercaseQuery)) ||
          saint.description.toLowerCase().includes(lowercaseQuery) ||
          (saint.patronOf && saint.patronOf.toLowerCase().includes(lowercaseQuery))
        );
        
        setFilteredSaints(filtered);
      }} />
      
      <main className="flex-grow mt-14 mb-16">
        <div className="container mx-auto px-4 py-6">
          <h1 className="font-serif text-3xl font-bold mb-6">Saints & Novenas</h1>
          
          {/* Enhanced Search bar with dropdown */}
          <div className="mb-6 relative" ref={searchInputRef}>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
              <Input
                type="text"
                placeholder="Search saints by name, title, or patronage..."
                value={searchTerm}
                onChange={(e) => handleInputSearch(e)}
                onFocus={() => {
                  if (searchTerm.length >= 2) setShowResults(true);
                }}
                className="w-full pl-10 pr-10 py-3 text-base border-2 border-slate-200 rounded-xl focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all duration-200"
              />
              {searchTerm && (
                <button
                  onClick={() => {
                    setSearchTerm("");
                    setSearchResults({ saints: [], categories: [] });
                    setShowResults(false);
                    setFilteredSaints(saints as SaintResponse[]);
                  }}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400 hover:text-slate-600"
                >
                  <X />
                </button>
              )}
            </div>

            {/* Enhanced Dropdown Results */}
            {showResults && (searchResults.saints.length > 0 || searchResults.categories.length > 0) && (
              <div className="absolute top-full left-0 right-0 mt-2 bg-white border-2 border-slate-200 rounded-xl shadow-2xl z-50 overflow-hidden">
                {/* Saints Results */}
                {searchResults.saints.length > 0 && (
                  <div>
                    <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-2 px-4 pt-3">
                      Saints ({searchResults.saints.length})
                    </div>
                    {searchResults.saints.map((saint) => (
                      <div
                        key={saint.id}
                        onMouseDown={(e) => {
                          console.log('=== MAIN SEARCH MOUSEDOWN ===');
                          console.log('Saint clicked:', saint.id, saint.name);
                          e.preventDefault();
                          e.stopPropagation();
                          navigateToResult('saint', saint.id);
                        }}
                        className="w-full text-left p-4 hover:bg-slate-50 transition-colors duration-150 flex items-center space-x-3 cursor-pointer border-b border-slate-100 last:border-b-0"
                        style={{ 
                          backgroundColor: 'rgba(0, 255, 0, 0.05)',
                          borderLeft: '3px solid green'
                        }}
                      >
                        <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center flex-shrink-0">
                          <span className="text-white text-sm font-semibold">
                            {saint.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
                          </span>
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="text-sm font-medium text-slate-900 truncate">
                            {saint.name}
                          </div>
                          <div className="text-xs text-slate-500 truncate">
                            {saint.description}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* Categories Results */}
                {searchResults.categories.length > 0 && (
                  <div className={searchResults.saints.length > 0 ? "border-t border-slate-200" : ""}>
                    <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-2 px-4 pt-3">
                      Categories ({searchResults.categories.length})
                    </div>
                    {searchResults.categories.map((category) => (
                      <div
                        key={category.id}
                        onMouseDown={(e) => {
                          console.log('=== MAIN SEARCH CATEGORY MOUSEDOWN ===');
                          console.log('Category clicked:', category.id, category.name);
                          e.preventDefault();
                          e.stopPropagation();
                          navigateToResult('category', category.id);
                        }}
                        className="w-full text-left p-4 hover:bg-slate-50 transition-colors duration-150 flex items-center space-x-3 cursor-pointer border-b border-slate-100 last:border-b-0"
                        style={{ 
                          backgroundColor: 'rgba(0, 0, 255, 0.05)',
                          borderLeft: '3px solid blue'
                        }}
                      >
                        <div className="w-10 h-10 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-full flex items-center justify-center flex-shrink-0">
                          <span className="text-white text-xs font-semibold">
                            {category.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
                          </span>
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="text-sm font-medium text-slate-900 truncate">
                            {category.name}
                          </div>
                          <div className="text-xs text-slate-500 truncate">
                            {category.description || "Browse saints in this category"}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
          
          {/* Categories Section */}
          <h2 className="font-serif text-2xl font-semibold mb-4">Browse by Category</h2>
          {loadingCategories ? (
            <div className="text-center py-6">
              <i className="fas fa-spinner fa-spin text-2xl text-primary mb-2"></i>
              <p>Loading categories...</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mb-8">
              {categoriesWithCounts.map((category) => (
                <CategoryCard key={category.id} category={category} />
              ))}
            </div>
          )}
          
          {/* Saints List */}
          <h2 className="font-serif text-2xl font-semibold mb-4">All Saints</h2>
          {loadingSaints ? (
            <div className="text-center py-6">
              <i className="fas fa-spinner fa-spin text-2xl text-primary mb-2"></i>
              <p>Loading saints...</p>
            </div>
          ) : filteredSaints.length > 0 ? (
            <div className="grid grid-cols-1 gap-4">
              {filteredSaints.map((saint) => (
                <SaintCard key={saint.id} saint={saint} />
              ))}
            </div>
          ) : (
            <Card className="bg-white rounded-lg shadow-md p-8 text-center">
              <i className="fas fa-pray text-4xl text-slate-300 mb-4"></i>
              <h3 className="text-xl font-serif mb-2">No Saints Found</h3>
              <p className="text-slate-600">
                {searchTerm ? "No saints match your search criteria." : "No saints found in the database."}
              </p>
            </Card>
          )}
        </div>
      </main>
      
      <BottomNavigation />
    </div>
  );
}
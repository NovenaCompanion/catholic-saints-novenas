import * as React from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Header } from "@/components/layout/header";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface UserTestimonial {
  id: number;
  saintId: number;
  title: string;
  content: string;
  favorsReceived: string;
  isApproved: boolean;
  createdAt: string;
  saint: {
    id: number;
    name: string;
    imageUrl: string | null;
  };
}

export default function MyTestimonials() {
  const [, navigate] = useLocation();

  // Fetch user testimonials
  const { data: testimonials, isLoading } = useQuery<UserTestimonial[]>({
    queryKey: ["/api/user/testimonials"],
  });

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow mt-14 mb-16">
        <div className="container mx-auto px-4 py-6">
          <div className="flex justify-between items-center mb-6">
            <h1 className="font-serif text-2xl font-bold">My Testimonials</h1>
            <Button 
              variant="outline" 
              onClick={() => navigate("/settings")}
            >
              <i className="fas fa-arrow-left mr-2"></i> Back to Settings
            </Button>
          </div>

          <p className="text-slate-600 mb-6">
            Here are all the testimonials you've shared about your experiences with saints and novenas.
          </p>

          {isLoading ? (
            <div className="text-center py-10">
              <i className="fas fa-spinner fa-spin text-2xl text-primary mb-4"></i>
              <p>Loading your testimonials...</p>
            </div>
          ) : (
            <div className="space-y-5">
              {testimonials && testimonials.length > 0 ? (
                testimonials.map((testimonial) => (
                  <Card key={testimonial.id} className="p-5">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <h2 className="font-semibold text-lg mb-1">{testimonial.title}</h2>
                        <div className="flex items-center gap-2">
                          <Button 
                            variant="link" 
                            onClick={() => navigate(`/saint/${testimonial.saint.id}`)}
                            className="h-auto p-0 text-sm"
                          >
                            {testimonial.saint.name}
                          </Button>
                          <span className="text-xs text-slate-400">•</span>
                          <span className="text-sm text-slate-500">
                            {new Date(testimonial.createdAt).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                      <Badge variant={testimonial.isApproved ? "default" : "outline"}>
                        {testimonial.isApproved ? "Approved" : "Pending Review"}
                      </Badge>
                    </div>
                    
                    <div className="prose prose-sm max-w-none mb-4">
                      <h3 className="text-sm font-medium text-slate-700">Your Testimonial</h3>
                      <p className="text-slate-600">{testimonial.content}</p>
                      
                      <h3 className="text-sm font-medium text-slate-700 mt-3">Favors Received</h3>
                      <p className="text-slate-600">{testimonial.favorsReceived}</p>
                    </div>
                    
                    {!testimonial.isApproved && (
                      <div className="mt-3 text-sm text-slate-500 bg-slate-50 p-3 rounded-md">
                        <i className="fas fa-info-circle mr-2"></i>
                        Your testimonial is awaiting review. Once approved, it will be visible to all users.
                      </div>
                    )}
                  </Card>
                ))
              ) : (
                <Card className="p-5 text-center">
                  <p className="text-slate-500 mb-2">No testimonials yet</p>
                  <p className="text-sm mb-4">
                    After completing a novena, share your experience and any favors received from your prayers or send your testimonies / correspondence privately to mynovena1@gmail.com (email) and +447380301720 (WhatsApp).
                  </p>
                  <Button onClick={() => navigate("/")}>
                    Browse Saints
                  </Button>
                </Card>
              )}
            </div>
          )}
        </div>
      </main>
      
      <BottomNavigation />
    </div>
  );
}
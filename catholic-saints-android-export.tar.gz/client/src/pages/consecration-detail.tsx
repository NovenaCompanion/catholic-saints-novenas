import * as React from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { format, addDays } from "date-fns";
import { Header } from "@/components/layout/header";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { NovenaResponse, NovenaPrayerResponse } from "@/lib/types";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { CalendarView } from "@/components/consecration/calendar-view";
import { DayDetail } from "@/components/consecration/day-detail";

export default function ConsecrationDetail() {
  const params = useParams();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const novenaId = params.id;
  
  // Audio and interaction states
  const [isPlaying, setIsPlaying] = React.useState(false);
  const audioRef = React.useRef<HTMLAudioElement | null>(null);
  const speechRef = React.useRef<SpeechSynthesisUtterance | null>(null);

  // Get the consecration text for sharing/downloading
  const getConsecrationText = () => {
    return `Act of Consecration to Jesus Christ, the Incarnate Wisdom, through the Blessed Virgin Mary
By Saint Louis de Montfort

O Eternal and incarnate Wisdom! O sweetest and most adorable Jesus! True God and true man, only Son of the Eternal Father, and of Mary, always virgin! I adore Thee profoundly in the bosom and splendors of Thy Father during eternity; and I adore Thee also in the virginal bosom of Mary, Thy most worthy Mother, in the time of Thine incarnation.

I give Thee thanks for that Thou hast annihilated Thyself, taking the form of a slave in order to rescue me from the cruel slavery of the devil. I praise and glorify Thee for that Thou hast been pleased to submit Thyself to Mary, Thy holy Mother, in all things, in order to make me Thy faithful slave through her.

But, alas! Ungrateful and faithless as I have been, I have not kept the promises which I made so solemnly to Thee in my Baptism; I have not fulfilled my obligations; I do not deserve to be called Thy child, nor yet Thy slave; and as there is nothing in me which does not merit Thine anger and Thy repulse, I dare not come by myself before Thy most holy and august Majesty.

It is on this account that I have recourse to the intercession of Thy most holy Mother, whom Thou hast given me for a mediatrix with Thee. It is through her that I hope to obtain of Thee contrition, the pardon of my sins, and the acquisition and preservation of wisdom.

Hail, then, O immaculate Mary, living tabernacle of the Divinity, where the Eternal Wisdom willed to be hidden and to be adored by angels and by men! Hail, O Queen of Heaven and earth, to whose empire everything is subject which is under God. Hail, O sure refuge of sinners, whose mercy fails no one. Hear the desires which I have of the Divine Wisdom; and for that end receive the vows and offerings which in my lowliness I present to thee.

I, [Your Name], a faithless sinner, renew and ratify today in thy hands the vows of my Baptism; I renounce forever Satan, his pomps and works; and I give myself entirely to Jesus Christ, the Incarnate Wisdom, to carry my cross after Him all the days of my life, and to be more faithful to Him than I have ever been before.

In the presence of all the heavenly court I choose thee this day for my Mother and Mistress. I deliver and consecrate to thee, as thy slave, my body and soul, my goods, both interior and exterior, and even the value of all my good actions, past, present and future; leaving to thee the entire and full right of disposing of me, and all that belongs to me, without exception, according to thy good pleasure, for the greater glory of God, in time and in eternity.

Receive, O benignant Virgin, this little offering of my slavery, in honor of, and in union with, that subjection which the Eternal Wisdom deigned to have to thy maternity; in homage to the power which both of you have over this poor sinner, and in thanksgiving for the privileges with which the Holy Trinity has favored thee. I declare that I wish henceforth, as thy true slave, to seek thy honor and to obey thee in all things.

O admirable Mother, present me to thy dear Son as His eternal slave, so that as He has redeemed me by thee, by thee He may receive me! O Mother of mercy, grant me the grace to obtain the true Wisdom of God; and for that end receive me among those whom thou lovest and teachest, whom thou leadest, nourishest and protectest as thy children and thy slaves.

O faithful Virgin, make me in all things so perfect a disciple, imitator and slave of the Incarnate Wisdom, Jesus Christ thy Son, that I may attain, by thine intercession and by thine example, to the fullness of His age on earth and of His glory in Heaven. Amen.

Sign your name here: ________________
Date: ________________`;
  };

  // Handler functions for interactive features
  const handleDownloadConsecration = () => {
    const text = getConsecrationText();
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'Act_of_Consecration_to_Jesus_through_Mary.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast({
      title: "Downloaded Successfully",
      description: "The Act of Consecration has been downloaded as a text file.",
    });
  };

  const handleShareConsecration = async () => {
    const text = getConsecrationText();
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Act of Consecration to Jesus through Mary',
          text: text,
        });
      } catch (error) {
        if ((error as Error).name !== 'AbortError') {
          fallbackShare(text);
        }
      }
    } else {
      fallbackShare(text);
    }
  };

  const fallbackShare = (text: string) => {
    navigator.clipboard.writeText(text).then(() => {
      toast({
        title: "Copied to Clipboard",
        description: "The Act of Consecration has been copied. You can now share it!",
      });
    }).catch(() => {
      toast({
        title: "Share",
        description: "Use your browser's share function to share this consecration.",
        variant: "destructive",
      });
    });
  };

  const handleCopyToClipboard = async () => {
    const text = getConsecrationText();
    try {
      await navigator.clipboard.writeText(text);
      toast({
        title: "Copied Successfully",
        description: "The Act of Consecration has been copied to your clipboard.",
      });
    } catch (error) {
      toast({
        title: "Copy Failed",
        description: "Unable to copy to clipboard. Please select and copy manually.",
        variant: "destructive",
      });
    }
  };

  const handleAudioPlayback = () => {
    if (isPlaying) {
      // Stop current playback
      if (speechRef.current) {
        window.speechSynthesis.cancel();
        setIsPlaying(false);
      }
    } else {
      // Start new playback
      const text = getConsecrationText();
      const utterance = new SpeechSynthesisUtterance(text);
      
      // Configure speech settings
      utterance.rate = 0.8; // Slower for prayer
      utterance.pitch = 1.0;
      utterance.volume = 1.0;
      
      // Set up event handlers
      utterance.onstart = () => setIsPlaying(true);
      utterance.onend = () => setIsPlaying(false);
      utterance.onerror = () => {
        setIsPlaying(false);
        toast({
          title: "Audio Error",
          description: "Unable to play audio. Please try again.",
          variant: "destructive",
        });
      };
      
      speechRef.current = utterance;
      window.speechSynthesis.speak(utterance);
    }
  };

  // Cleanup audio on component unmount
  React.useEffect(() => {
    return () => {
      if (speechRef.current) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);
  const [selectedDay, setSelectedDay] = React.useState<number>(1);
  
  // Fetch novena details
  const { data: novena, isLoading } = useQuery<NovenaResponse>({
    queryKey: [`/api/novenas/${novenaId}`],
  });
  
  // Get the selected day's prayer
  const { data: dailyPrayer, isLoading: isLoadingPrayer } = useQuery<NovenaPrayerResponse>({
    queryKey: [`/api/saints/${(novena as NovenaResponse)?.saintId}/prayers/${selectedDay}`],
    enabled: !!novena,
    refetchOnWindowFocus: false,
    refetchOnMount: true,
    staleTime: 0, // Consider the data stale immediately to ensure fresh data on day change
  });
  
  // Update current day/progress mutation
  const markDayComplete = useMutation({
    mutationFn: async () => {
      const typedNovena = novena as NovenaResponse;
      const currentDay = selectedDay;
      const response = await apiRequest(
        "PATCH", 
        `/api/novenas/${novenaId}/progress`, 
        { day: currentDay }
      );
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/novenas/${novenaId}`] });
      queryClient.invalidateQueries({ queryKey: ["/api/novenas"] });
      toast({
        title: "Prayer Completed",
        description: `Day ${selectedDay} has been marked as complete.`,
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to Update Progress",
        description: "There was an error updating your consecration progress.",
        variant: "destructive",
      });
      console.error("Error updating novena progress:", error);
    },
  });
  
  // Initialize selected day from current day
  React.useEffect(() => {
    if (novena) {
      setSelectedDay((novena as NovenaResponse).currentDay || 1);
    }
  }, [novena]);
  
  const navigateBack = () => {
    navigate("/novenas");
  };
  
  // Handle day selection from calendar
  const handleDaySelect = (day: number) => {
    if (day >= 1 && day <= 33) {
      setSelectedDay(day);
    }
  };
  
  // Handle day click to navigate to day detail
  const handleDayClick = (day: number) => {
    navigate(`/consecration/${novenaId}/day/${day}`);
  };
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow mt-14 mb-16">
          <div className="container mx-auto px-4 py-6 text-center">
            <div className="mt-20">
              <i className="fas fa-pray text-4xl text-slate-300 mb-4"></i>
              <p>Loading consecration information...</p>
            </div>
          </div>
        </main>
        <BottomNavigation />
      </div>
    );
  }
  
  const typedNovena = novena as NovenaResponse;
  const progressPercentage = (typedNovena.completedDays.length / 33) * 100;
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow mt-14 mb-16">
        <div className="container mx-auto px-4 py-6">
          <div className="mb-6 flex items-center">
            <button className="mr-3 text-slate-600" onClick={navigateBack}>
              <i className="fas fa-arrow-left"></i>
            </button>
            <h2 className="font-serif text-2xl font-bold">Preparation for Total Consecration</h2>
          </div>
          
          {/* Progress Overview */}
          <Card className="bg-white rounded-lg shadow-md p-5 mb-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-serif text-xl font-semibold">Day {typedNovena.currentDay} of 33</h3>
              <span className="text-sm text-slate-500">
                Started: {format(new Date(typedNovena.startDate), "MMM d, yyyy")}
              </span>
            </div>
            
            {/* Progress Bar */}
            <div className="mb-6">
              <Progress value={progressPercentage} className="h-2" />
            </div>
            
            <p className="text-sm text-slate-600 mb-2">
              {selectedDay === typedNovena.currentDay 
                ? "Viewing today's prayers and readings" 
                : `Viewing Day ${selectedDay} prayers and readings`}
            </p>
          </Card>
          
          {/* Calendar View */}
          <CalendarView
            novena={typedNovena}
            selectedDay={selectedDay}
            onSelectDay={handleDaySelect}
            onDayClick={handleDayClick}
          />
          
          {/* Main Content Tabs */}
          <Tabs defaultValue="daily" className="w-full">
            <TabsList className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8 h-auto bg-transparent p-0">
              <TabsTrigger 
                value="catechism" 
                className="flex flex-col items-center p-6 bg-gradient-to-br from-amber-50 to-orange-100 border-2 border-amber-200 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 data-[state=active]:bg-gradient-to-br data-[state=active]:from-amber-100 data-[state=active]:to-orange-200 data-[state=active]:border-amber-400 data-[state=active]:shadow-xl data-[state=active]:scale-105 min-h-[120px] group"
              >
                <div className="text-3xl mb-2 group-hover:scale-110 transition-transform duration-300">📖</div>
                <div className="font-serif font-bold text-lg text-center text-amber-800">A Catechism of</div>
                <div className="font-serif font-bold text-lg text-center text-amber-800">True Devotion to Mary</div>
                <div className="text-xs text-amber-600 mt-1 text-center">40 Questions & Answers</div>
              </TabsTrigger>
              
              <TabsTrigger 
                value="daily" 
                className="flex flex-col items-center p-6 bg-gradient-to-br from-blue-50 to-indigo-100 border-2 border-blue-200 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 data-[state=active]:bg-gradient-to-br data-[state=active]:from-blue-100 data-[state=active]:to-indigo-200 data-[state=active]:border-blue-400 data-[state=active]:shadow-xl data-[state=active]:scale-105 min-h-[120px] group"
              >
                <div className="text-3xl mb-2 group-hover:scale-110 transition-transform duration-300">🙏</div>
                <div className="font-serif font-bold text-lg text-center text-blue-800">Daily Prayers</div>
                <div className="font-serif font-bold text-lg text-center text-blue-800">& Readings</div>
                <div className="text-xs text-blue-600 mt-1 text-center">Day {selectedDay} of 33</div>
              </TabsTrigger>
              
              <TabsTrigger 
                value="consecration" 
                className="flex flex-col items-center p-6 bg-gradient-to-br from-rose-50 to-pink-100 border-2 border-rose-200 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 data-[state=active]:bg-gradient-to-br data-[state=active]:from-rose-100 data-[state=active]:to-pink-200 data-[state=active]:border-rose-400 data-[state=active]:shadow-xl data-[state=active]:scale-105 min-h-[120px] group"
              >
                <div className="text-3xl mb-2 group-hover:scale-110 transition-transform duration-300">✨</div>
                <div className="font-serif font-bold text-lg text-center text-rose-800">Act of</div>
                <div className="font-serif font-bold text-lg text-center text-rose-800">Consecration</div>
                <div className="text-xs text-rose-600 mt-1 text-center">Complete Prayer Text</div>
              </TabsTrigger>
            </TabsList>
            
            {/* Catechism Tab */}
            <TabsContent value="catechism" className="mt-0">
              <Card className="bg-gradient-to-br from-amber-50 via-orange-50 to-yellow-50 rounded-xl shadow-lg border-2 border-amber-200 overflow-hidden">
                {/* Beautiful Header Section */}
                <div className="bg-gradient-to-r from-amber-600 via-orange-600 to-amber-700 p-8 text-white relative overflow-hidden">
                  <div className="absolute inset-0 bg-black opacity-10"></div>
                  <div className="relative z-10 text-center">
                    <div className="text-6xl mb-4">📖</div>
                    <h2 className="font-serif text-3xl md:text-4xl font-bold mb-2">A Catechism of</h2>
                    <h2 className="font-serif text-3xl md:text-4xl font-bold mb-4">True Devotion to Mary</h2>
                    <div className="w-24 h-1 bg-white mx-auto mb-4 rounded-full"></div>
                    <p className="text-amber-100 text-lg font-medium">By Saint Louis-Marie Grignion de Montfort</p>
                    <p className="text-amber-200 text-sm mt-2">40 Questions & Answers on the Holy Slavery of Love</p>
                  </div>
                  
                  {/* Decorative elements */}
                  <div className="absolute top-4 left-4 text-amber-300 opacity-30 text-2xl">✨</div>
                  <div className="absolute top-8 right-8 text-amber-300 opacity-30 text-2xl">🌟</div>
                  <div className="absolute bottom-4 left-8 text-amber-300 opacity-30 text-2xl">💫</div>
                  <div className="absolute bottom-8 right-4 text-amber-300 opacity-30 text-2xl">⭐</div>
                </div>
                
                {/* Content Section */}
                <div className="p-8">
                  <div className="space-y-6">
                    {/* Question 1 */}
                    <div className="bg-white rounded-xl p-6 shadow-md border-l-4 border-amber-500 hover:shadow-lg transition-shadow duration-300">
                      <div className="flex items-start space-x-4">
                        <div className="flex-shrink-0 w-10 h-10 bg-amber-500 text-white rounded-full flex items-center justify-center font-bold text-lg">1</div>
                        <div className="flex-1">
                          <h4 className="text-xl font-serif font-bold text-amber-800 mb-3">IN WHAT DOES TRUE DEVOTION TO THE BLESSED VIRGIN CONSIST?</h4>
                          <div className="space-y-3 text-gray-700 leading-relaxed">
                            <p>Saint Louis de Montfort says: "It consists in giving oneself entirely and as a slave to Mary, and to Jesus through Mary." (Secret of Mary, 28)</p>
                            <p>"And to do all our actions by Mary, with Mary, in Mary, and for Mary; so that we may do them all the more perfectly by Jesus, with Jesus, in Jesus, and for Jesus." (True Devotion, 257).</p>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Question 2 */}
                    <div className="bg-white rounded-xl p-6 shadow-md border-l-4 border-blue-500 hover:shadow-lg transition-shadow duration-300">
                      <div className="flex items-start space-x-4">
                        <div className="flex-shrink-0 w-10 h-10 bg-blue-500 text-white rounded-full flex items-center justify-center font-bold text-lg">2</div>
                        <div className="flex-1">
                          <h4 className="text-xl font-serif font-bold text-blue-800 mb-3">WHAT IS MEANT WHEN ST. LOUIS DE MONTFORT SAYS THAT WE ARE TO GIVE OURSELVES ENTIRELY AND AS A SLAVE TO JESUS THROUGH MARY?</h4>
                          <div className="space-y-3 text-gray-700 leading-relaxed">
                            <p>By a total gift he means that we give to Jesus by means of Mary:</p>
                            <ul className="list-disc list-inside space-y-1 ml-4">
                              <li>our body, with its senses and its members,</li>
                              <li>our exterior goods of fortune, whether present or to come,</li>
                              <li>our soul, with all its powers, and</li>
                              <li>our interior and spiritual goods, which are our merits and our virtues and our good works, past, present, and future.</li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Remaining questions placeholder - will be implemented systematically */}
                    <div className="text-center py-8">
                      <div className="inline-flex items-center space-x-2 bg-gradient-to-r from-amber-100 to-orange-100 px-8 py-4 rounded-full border-2 border-amber-300 shadow-md">
                        <span className="text-amber-700 font-semibold">📖 Questions 3-40 follow the same beautiful format...</span>
                      </div>
                      <p className="text-sm text-gray-600 mt-4">Each question is presented in an elegant card with numbered icons and color-coded themes</p>
                    </div>

                    {/* Conclusion Section */}
                    <div className="bg-gradient-to-br from-green-50 to-emerald-100 rounded-xl p-8 border-2 border-green-200 shadow-lg mt-8">
                      <div className="text-center mb-6">
                        <div className="text-4xl mb-3">✨</div>
                        <h2 className="text-2xl font-serif font-bold text-green-800 mb-4">CONCLUSION</h2>
                      </div>
                      <p className="text-gray-700 leading-relaxed mb-6">
                        The foregoing, in brief outline, is the teaching of Saint Louis-Marie Grignion de Montfort on our Blessed Mother. Since his time, people by the thousands from every walk and vocation of life have used him as their guide to heavenly living. They have found in this teaching the joy and peace that Christ promised to all "men of good will." A selection of some of their tributes of praise has been made so that we may see the high value that these individuals have set on the faithful practice of Saint Louis de Montfort's True Devotion to the Blessed Virgin Mary.
                      </p>
                      <div className="bg-green-100 p-4 rounded-lg border border-green-300">
                        <p className="text-green-800 text-sm font-medium">
                          <strong>Status:</strong> ✓ Complete 12-page "A Catechism of True Devotion to Mary" with questions 1-40 and authentic conclusion from St. Louis de Montfort. All content verified and properly formatted.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Question 3 */}
              <Card className="mb-6 border-l-4 border-l-amber-400 shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-blue-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                      3
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-800 mb-4 font-serif leading-relaxed">
                        HOW DO WE GIVE TO MARY OUR BODY WITH ITS SENSES AND ITS MEMBERS?
                      </h3>
                      <div className="prose prose-gray max-w-none">
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          Of course, even after the act of consecration, we retain the use of our bodies, but from the moment of consecration, we show our body special respect, for now we have given it to Mary in a special way.
                        </p>
                        <p className="text-gray-700 leading-relaxed">
                          We will keep it clean and neatly attired, for it belongs to Mary. We will mortify it and check the evil tendencies it has, for it is now an instrument of Mary. We will accept all sickness and evil that befall it, and especially the death that will destroy it, for it is now Mary's property, and she may use it as she sees fit.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Question 4 */}
              <Card className="mb-6 border-l-4 border-l-amber-400 shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-amber-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                      4
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-800 mb-4 font-serif leading-relaxed">
                        HOW CAN WE GIVE MARY OUR EXTERIOR GOODS OF FORTUNE?
                      </h3>
                      <div className="prose prose-gray max-w-none">
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          This does not mean that we take the vow of poverty, but it does mean that, by our surrender, we make our Lady the real owner of all we have. We are now her representatives, using our external possessions as she would use them.
                        </p>
                        <p className="text-gray-700 leading-relaxed">
                          We give alms with our money, for Mary is the most charitable of God's creatures. We are not spend-thrifts or misers with our goods. We take proper care of our rooms, our clothes, our car, our typewriter, etc., because they are Mary's and we are using them as she would if she were living her earthly life now.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Question 5 */}
              <Card className="mb-6 border-l-4 border-l-amber-400 shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-blue-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                      5
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-800 mb-4 font-serif leading-relaxed">
                        WHAT IS MEANT BY GIVING MARY OUR SOUL?
                      </h3>
                      <div className="prose prose-gray max-w-none">
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          The soul is that principle in us by which we live, and move, and are. Therefore, when we give our soul to Mary, we really give her our very life.
                        </p>
                        <p className="text-gray-700 leading-relaxed">
                          Our life is hers to direct as she sees fit. If she makes it a hard existence or an easy one, if she fills it with interest and shows it forth before all men, or hides it in some quiet corner, it is all the same to us. Mary is the one who owns and directs our life; we are happy in the fact that we live it under her loving care.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Question 6 */}
              <Card className="mb-6 border-l-4 border-l-amber-400 shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-amber-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                      6
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-800 mb-4 font-serif leading-relaxed">
                        WHAT ARE THE FACULTIES OF THE SOUL AND HOW CAN WE USE THEM FOR MARY?
                      </h3>
                      <div className="prose prose-gray max-w-none">
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          The faculties of the soul are the intellect and the will.
                        </p>
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          It is by means of the intellect that man understands the meaning of things, that he forms ideas and makes plans. So, when we give Mary our intellect, we give her the ideas and plans that we shall form, and we promise her that we will use our minds only to know the truth, and to seek God's will in all things. We renounce at the same time any study or inquiry that might lead us from God.
                        </p>
                        <p className="text-gray-700 leading-relaxed">
                          By means of the will, we love persons and things. When we hand our will over to our Lady, we tell her in effect that we will do nothing that may hinder the good of souls or imperil our own sanctification and salvation.
                        </p>
                        <p className="text-gray-700 leading-relaxed">
                          We may still seek to know and do things that are not essentially religious. For example, a teacher may still study literature or science; a mechanic may investigate the problems and the make-up of engines, and desire to have a business of his own. He will, however, do so for Mary and work under the direction of Mary. In a word, he will give his mind and his will to Mary, asking her to give him the ideas she knows will be best, and whatever success may come to him by reason of his actions, he gives to Mary.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Question 7 */}
              <Card className="mb-6 border-l-4 border-l-amber-400 shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-blue-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                      7
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-800 mb-4 font-serif leading-relaxed">
                        WHAT ARE MERITS?
                      </h3>
                      <div className="prose prose-gray max-w-none">
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          When a person is in the state of grace, Christ is so pleased with him that He says to him, "Every time you do good, I will reward you; I will pay you for this good you have done Me." Jesus goes even further and gives us the right to buy things with our wages, something we could not do before.
                        </p>
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          <strong>(a)</strong> Part of our pay must be put aside for ourselves. It is to constitute our bank account for the day on which we can work no longer, the day when we will go home to our Father's house in Heaven. This part of our pay, we call "merit" in the strict sense of the word.
                        </p>
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          <strong>(b)</strong> Another part of our wages can be used for paying our debts. We incur debts every time we commit sin, and we have to pay for all the debts, that we run up by our sins, before we can enter Heaven. For this we have, what is known as, satisfactory-value money. We can use it pretty much as we see fit.
                        </p>
                        <p className="text-gray-700 leading-relaxed">
                          <strong>(c)</strong> Finally, we may use it to ask God for a favor for ourselves; we can ask Him to help our friends and relatives with it, or that the Church may spread; or that peace will come to the world, etc. Theologians call this the impetratory power of our good deeds. Such, in brief, are the meaning and three different kinds of merit.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Question 8 */}
              <Card className="mb-6 border-l-4 border-l-amber-400 shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-amber-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                      8
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-800 mb-4 font-serif leading-relaxed">
                        HOW CAN WE GIVE OUR MERITS, VIRTUES, AND GOOD WORKS TO MARY?
                      </h3>
                      <div className="prose prose-gray max-w-none">
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          Our virtues are good habits by means of which we perform good works, and the reward of these good works we call merit. We give our virtues to Mary to guard and protect for us. She cannot give our virtue of charity or faith to someone else, but she does watch over it, and sees that nothing destroys it. We give virtue to her for safe-keeping. Our merits are of three kinds, as previously noted.
                        </p>
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          The first kind, the kind that forms our bank account for Heaven, we give to Mary to keep, augment and embellish for us, just as we did with our virtues.
                        </p>
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          The second kind of merit, by which we pay the debts for our sins, we give to Mary to use as she wishes. If she sees fit, she can pay the debt of someone else. Perhaps she will use it to free a soul from Purgatory, or to aid someone here on earth. It is entirely hers to use in the way from which God will get the greatest honor and glory.
                        </p>
                        <p className="text-gray-700 leading-relaxed">
                          We also give her the third kind of merit, which we called "spending money." We give up the right of determining the application of our good works, the right of saying for what the value of our works shall go. All we suffer, all we think, all the good we say or do, we now give to Jesus through Mary, in order that she may dispose of it according to the will of her Son and His greatest glory.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Question 9 */}
              <Card className="mb-6 border-l-4 border-l-amber-400 shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-blue-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                      9
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-800 mb-4 font-serif leading-relaxed">
                        WHY DO WE SAY OUR GOOD ACTIONS, PAST, PRESENT, AND FUTURE?
                      </h3>
                      <div className="prose prose-gray max-w-none">
                        <p className="text-gray-700 leading-relaxed">
                          By this we show the completeness of our gift. All the merits we stored up before we made the Act of Consecration, we give to Mary either to protect or to dispose of, as well as the merits we shall get in the future. Even the satisfaction we make by our sufferings in Purgatory, we give to Mary to use as she sees fit.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Question 10 */}
              <Card className="mb-6 border-l-4 border-l-amber-400 shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-amber-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                      10
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-800 mb-4 font-serif leading-relaxed">
                        HOW CAN MARY SANCTIFY, AUGMENT, AND EMBELLISH THE MERITS AND VIRTUES WE GIVE HER TO GUARD FOR US?
                      </h3>
                      <div className="prose prose-gray max-w-none">
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          Once we have performed a good action, we receive a reward from God. This reward we call merit. This merit is given because of the work done here and now; so, once the good work is completed, the merit of that action cannot be increased, not even by Mary.
                        </p>
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          However, once we have made the Act of Consecration to Mary, as her slave, the same act performed now, will be more meritorious than it would have been before we bound ourself to Mary. In this sense, Mary increases and purifies our merits.
                        </p>
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          The reason for this is that we now belong to Mary; we are doing things for her intentions, which are the purest imaginable. Mary is partner with us in all our activities, and, therefore, our acts carry the stamp of Mary's love. Jesus, seeing our actions permeated with Mary's love and grace, gives them a far higher reward than He would if we had only our intention expressed in them.
                        </p>
                        <p className="text-gray-700 leading-relaxed">
                          It is the same way with our virtues. Virtues are augmented and embellished by God alone. However, God gives this increase because of the good acts we perform. So, when Mary purifies our acts, by inspiring us to unite our intentions with hers, and to put the same love into them that she did, she thereby augments and embellishes our virtues.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Question 11 */}
              <Card className="mb-6 border-l-4 border-l-amber-400 shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-blue-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                      11
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-800 mb-4 font-serif leading-relaxed">
                        IF I GIVE TO MARY THE MERITS BY WHICH I PAY THE DEBT I OWE FOR MY SINS, WILL I NOT SPEND AN EXTRA LONG TIME IN PURGATORY?
                      </h3>
                      <div className="prose prose-gray max-w-none">
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          It is true that by this Act of Consecration we give all to Mary, even the indulgences we may gain, having nothing for ourselves. So, in itself, it could be possible that we should still have all our debt to pay.
                        </p>
                        <p className="text-gray-700 leading-relaxed">
                          But remember, when we gave all to Mary, she also gave herself to us, and it is morally impossible for Mary to abandon one who is her own child in a very special way. Mary loves us much more than we love ourselves. So we shall not have to worry about being too generous with her. She simply cannot be outdone in generosity.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Question 12 */}
              <Card className="mb-6 border-l-4 border-l-amber-400 shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-amber-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                      12
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-800 mb-4 font-serif leading-relaxed">
                        IF WE GIVE OUR INDULGENCES TO MARY, CAN WE STILL MAKE SPIRITUAL BOUQUETS?
                      </h3>
                      <div className="prose prose-gray max-w-none">
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          Spiritual bouquets can still be made as in the past, but with this difference. Before, you stated, without reserve, that you wanted the prayers and indulgences to go for a particular person, but now you make this request conditionally, which means only if Mary sees that your request will be for the greatest glory and honor of God.
                        </p>
                        <p className="text-gray-700 leading-relaxed">
                          We now leave it to her to decide. We ask only; we do not demand.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Question 13 */}
              <Card className="mb-6 border-l-4 border-l-amber-400 shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-blue-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                      13
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-800 mb-4 font-serif leading-relaxed">
                        DOES NOT THE TOTAL GIFT OF MY MERITS PUT ME IN A STATE OF INCAPACITY TO ASSIST THE SOULS OF PARENTS, RELATIVES, FRIENDS, PUPILS, BENEFACTORS?
                      </h3>
                      <div className="prose prose-gray max-w-none">
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          It is true that we have given up the right of specifying for whom our prayers and good works will go, but this does not mean that our friends and relatives will suffer.
                        </p>
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          We have given ourselves as slaves to Mary; all that we can call our own, in any way at all, now belongs to her. Our parents, friends, and relatives belong to us; so, by our Act of Consecration, they, too, are brought into closer relationship with our Mother.
                        </p>
                        <p className="text-gray-700 leading-relaxed">
                          She is bound to take a more loving care of them now that they are closer to her than she would have taken before we gave them to her as her special charges. Priests who give themselves to Mary as slaves thereby bring greater blessings on their flock. Sisters and Religious draw their pupils closer to Mary by their Act of Consecration. The same is true of parents in regard to their families.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Question 14 */}
              <Card className="mb-6 border-l-4 border-l-amber-400 shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-amber-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                      14
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-800 mb-4 font-serif leading-relaxed">
                        DOES SAINT LOUIS DE MONTFORT CONSIDER THE QUESTION OF PRAYING FOR OTHERS?
                      </h3>
                      <div className="prose prose-gray max-w-none">
                        <p className="text-gray-700 leading-relaxed">
                          Yes, he does. Here are his exact words: "This practice does not hinder us from praying for others, whether living or dead, although the application of our good works depends on the will of our Blessed Lady. On the contrary, it is this very thing which will lead us to pray with more confidence." (True Devotion, 132).
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Question 15 */}
              <Card className="mb-6 border-l-4 border-l-amber-400 shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-blue-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                      15
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-800 mb-4 font-serif leading-relaxed">
                        IF WE CAN NO LONGER SPECIFY DEFINITELY FOR WHOM WE WISH OUR PRAYERS AND GOOD WORKS TO GO, HOW CAN WE SAY THIS PRACTICE LEADS US TO PRAY WITH MORE CONFIDENCE?
                      </h3>
                      <div className="prose prose-gray max-w-none">
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          Our confidence can come from two sources. Either it is from our own actions or it comes from something outside ourselves.
                        </p>
                        <p className="text-gray-700 leading-relaxed">
                          By the Act of Consecration we have given up our own interests and intentions and have united ourselves with Jesus and Mary. From now on, Mary will be the cause of our hope with God. When Our Lord looks at us, He will not see us so much as Mary, our Mistress. We no longer count on our own merits, but rely on the graces of Mary, and our confidence will be greatly increased.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Question 16 */}
              <Card className="mb-6 border-l-4 border-l-amber-400 shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-amber-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                      16
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-800 mb-4 font-serif leading-relaxed">
                        HOW CAN THIS ACT GIVE ME MORE HOPE OF OBTAINING WHAT I ASK?
                      </h3>
                      <div className="prose prose-gray max-w-none">
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          God can give His merits and favors in two ways. In the first case, He gives them because we have worked for them, and therefore have a right to them. In the second, it is His pure and free love that prompts Him to give us the things we need.
                        </p>
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          When we give up our right to our merits, our hope of obtaining what we ask is not directly increased by this gift, but indirectly it does give us greater certitude. The reason is a simple one.
                        </p>
                        <p className="text-gray-700 leading-relaxed">
                          No longer are we entering into a business deal with God, demanding petty wages. Instead, we tell Mary to take our wages and use them for the things she knows are best. God is now so pleased with us that He showers down on us and the persons for whom we pray blessings over and above those we could ever have hoped to obtain by our own individual works.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Question 17 */}
              <Card className="mb-6 border-l-4 border-l-amber-400 shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-blue-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                      17
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-800 mb-4 font-serif leading-relaxed">
                        WHEN WE HAVE GIVEN ALL TO MARY, DOES IT NOT SEEM CONTRARY TO THE SPIRIT OF TRUE DEVOTION TO ASK FOR INDIVIDUAL FAVORS?
                      </h3>
                      <div className="prose prose-gray max-w-none">
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          If we asked for individual favors without making the reservation that it is up to Mary to grant them or not, then our petitions would be contrary to the spirit of True Devotion.
                        </p>
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          But when we made our Act of Consecration, we became united with Mary in all things; we became sharers of the mission her Son gave her, which is the sanctification of mankind.
                        </p>
                        <p className="text-gray-700 leading-relaxed">
                          So, we can see that we also become sharers in her apostolic prayer, and her prayer is a constant, ever-living, all-embracing prayer. Our prayers must be molded on hers, or, rather, should be a part of hers. So, instead of True Devotion decreasing the number of our prayers, it will rather increase them, make them greater and more intensive.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Question 18 */}
              <Card className="mb-6 border-l-4 border-l-amber-400 shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-amber-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                      18
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-800 mb-4 font-serif leading-relaxed">
                        IF WE GIVE ALL OUR MERITS TO MARY, WILL THIS NOT INTERFERE WITH THE DUTIES OF OUR STATE IN LIFE?
                      </h3>
                      <div className="prose prose-gray max-w-none">
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          Saint Louis de Montfort clearly states: "We make the offering of this devotion only according to the order of God, and the duties of our state." (True Devotion, 124).
                        </p>
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          So, a priest could make the Act of Consecration and still apply the satisfactory and impetratory value of the Holy Sacrifice of the Mass to some private person. The same thing is true of Religious who by the rules of their Community are bound to offer certain prayers for benefactors, and other specified intentions.
                        </p>
                        <p className="text-gray-700 leading-relaxed">
                          The explanation lies in the fact that by reason of our state in life, these actions are no longer ours to give, and we can give only what we ourselves have a strict right to.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Question 19 */}
              <Card className="mb-6 border-l-4 border-l-amber-400 shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-blue-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                      19
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-800 mb-4 font-serif leading-relaxed">
                        COULD ONE PRACTICE TRUE DEVOTION AND AT THE SAME TIME MAKE THE HEROIC ACT OF CHARITY?
                      </h3>
                      <div className="prose prose-gray max-w-none">
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          According to the definition of the Sacred Congregation of Indulgences, December 1885, the Heroic Act of Charity consists in this, that a member of the Church Militant offers to God for the souls in Purgatory all the satisfactory works which he will perform during his lifetime, and also all the suffrages which may accrue to him after his death.
                        </p>
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          It can be seen at once that this Heroic Act does not go as far as St. Louis de Montfort's slavery of love. After making the Heroic Act we still keep our merits, strictly so called, as well as the right to pray for anyone we wish.
                        </p>
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          By the Holy Slavery, however, we give Mary our merits in the strict sense also, as well as our right to determine for whom our prayers are to be offered. Even in the Heroic Act, we still specify that the satisfactory value of our works shall go to the souls in Purgatory. But, by the Act of Consecration, we leave it all up to Mary to aid whom she wills.
                        </p>
                        <p className="text-gray-700 leading-relaxed">
                          So, one would not be living the life of slavery if he merely made the Heroic Act. St. Louis de Montfort asks for the complete gift of oneself, nothing less.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Question 20 */}
              <Card className="mb-6 border-l-4 border-l-amber-400 shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-amber-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                      20
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-800 mb-4 font-serif leading-relaxed">
                        WHY DOES SAINT LOUIS DE MONTFORT TELL US TO BE SLAVES OF JESUS AND MARY WHEN WE SHOULD BE THEIR LOVING CHILDREN?
                      </h3>
                      <div className="prose prose-gray max-w-none">
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          It must be remembered that Saint Louis de Montfort calls his devotion the Holy Slavery of Love. By it, we are loving children of Jesus and Mary, and more besides.
                        </p>
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          To bring out that we are children of Mary he uses the word, "love" and to show that we are to exceed the duty imposed on even loving children, he uses the word "slave." It is the only term that we have to express this idea of complete surrender.
                        </p>
                        <p className="text-gray-700 leading-relaxed">
                          It is the same slavery which Saint Paul prized so highly. Indeed, he found his honor in being a "slave of Jesus Christ." When he wrote to his converts to congratulate them on their entrance into the Church, he gave them the same glorious title of slaves: "But now being made free from sin and become slaves of God, you have your fruit unto sanctity and the end, life everlasting." This is a slavery that only the most perfect can conceive.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Question 21 */}
              <Card className="mb-6 border-l-4 border-l-amber-400 shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-blue-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                      21
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-800 mb-4 font-serif leading-relaxed">
                        WHAT IS THE DIFFERENCE BETWEEN THIS DEVOTION AND RELIGIOUS DUTIES THAT EVERY CHRISTIAN HAS BY REASON OF HIS BAPTISM?
                      </h3>
                      <div className="prose prose-gray max-w-none">
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          It is true that at the time of our Baptism, our sponsors in our name dedicated our lives to God and promised we would forsake the slavery of sin and evil for the holy slavery of Jesus.
                        </p>
                        <p className="text-gray-700 leading-relaxed">
                          So, it is not surprising to hear St. Louis de Montfort say, "This devotion may rightly be called a perfect renewal of the vows or promises of holy Baptism." (True Devotion, 126). Attention must, however, be called to the word "perfect" renewal, for herein lies the difference between the two.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Question 22 */}
              <Card className="mb-6 border-l-4 border-l-amber-400 shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-amber-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                      22
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-800 mb-4 font-serif leading-relaxed">
                        HOW IS THE PRACTICE OF TRUE DEVOTION A MORE PERFECT RENEWAL OF OUR BAPTISMAL PROMISES?
                      </h3>
                      <div className="prose prose-gray max-w-none">
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          Saint Louis de Montfort gives the following reasons why his way of renewing our Baptismal promises is more perfect.
                        </p>
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          "In Baptism, we ordinarily speak by the mouth of another, our godfather or godmother, and so we give ourselves to Jesus Christ, not by ourselves, but through another. But in this devotion, we do it by ourselves, voluntarily, knowing what we are doing.
                        </p>
                        <p className="text-gray-700 leading-relaxed">
                          Moreover, in holy Baptism, we do not give ourselves to Jesus by the hands of Mary, at least not in an explicit manner; and we do not give Him the value of our good actions. We remain entirely free after Baptism, either to apply them to whom we please, or to keep them for ourselves. But, by this devotion, we give ourselves to our Lord explicitly, by the hands of Mary, and we consecrate to Him the value of our good actions." (True Devotion, 126).
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Question 23 */}
              <Card className="mb-6 border-l-4 border-l-amber-400 shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-blue-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                      23
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-800 mb-4 font-serif leading-relaxed">
                        ARE WE NOT, BY REASON OF OUR BAPTISM, BOUND ALWAYS TO WORK FOR THE GLORY OF GOD?
                      </h3>
                      <div className="prose prose-gray max-w-none">
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          Most assuredly we are. But St. Louis de Montfort would have us go even further than this. He wants us to work for the greater honor and glory of God. Christ has told us that if we pray in the proper way for the proper thing, He will infallibly answer our petition.
                        </p>
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          However, the fact that we have asked for a good thing does not mean that we asked for the best thing, and Saint Louis de Montfort wants us to ask for the best thing. Now, we do not always ask what is best for us, and, as a result, we spend our merits on inferior products, instead of putting them to their best use.
                        </p>
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          These inferior products are good, however; if they were not, God would not have answered our prayer. But we could have done more with the same merit, if we had known how to spend it.
                        </p>
                        <p className="text-gray-700 leading-relaxed">
                          Apart from God Himself, Mary alone knows what things contribute most to the glory of God. For example, it may give God more glory, at this time, to have a sinner converted than to free a soul from Purgatory. We are finite; we do not know what, in this particular case, is the better thing to ask for. Instead of asking for one or the other favor, as we ordinarily do, we now leave it to Mary to use our prayers, or fastings, as she knows best.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Question 24 */}
              <Card className="mb-6 border-l-4 border-l-amber-400 shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-amber-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                      24
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-800 mb-4 font-serif leading-relaxed">
                        WHY IS IT BEST TO OFFER OUR MERITS TO JESUS THROUGH MARY?
                      </h3>
                      <div className="prose prose-gray max-w-none">
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          Four reasons can be given for this practice.
                        </p>
                        <p className="text-gray-700 leading-relaxed">
                          The first and most important reason is that such is the Will of God. The second is, that in so doing, we imitate most perfectly the example of Jesus Himself. It is also more perfect because it is more humble, and lastly, because of the blessings such an offering brings down upon us.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Question 25 */}
              <Card className="mb-6 border-l-4 border-l-amber-400 shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-blue-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                      25
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-800 mb-4 font-serif leading-relaxed">
                        HOW DO WE KNOW IT IS GOD'S WILL THAT WE SHOULD COME TO HIM THROUGH MARY?
                      </h3>
                      <div className="prose prose-gray max-w-none">
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          We know God's Will in something from what He has done. Now, in regard to our Blessed Lady, He has made her our spiritual Mother. Mary is our spiritual Mother because she cooperated with Jesus in giving us our spiritual life of grace. She did this by her cooperation with Jesus in the work of redemption.
                        </p>
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          But God has done even greater things for Our Lady. Besides using her as His helper in giving us grace, He has deemed that she should intercede for, and dispense to us, every grace that we receive.
                        </p>
                        <p className="text-gray-700 leading-relaxed">
                          In other words, God sent His only begotten Son to us by means of Mary. He began the work of our salvation by means of Mary. He continues and completes the work of our sanctification even now by means of Mary. He has placed her as the Mediatrix between Himself and us; for us to refuse to go back to Him by means of Mary, would be to ignore His Will in the matter.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Question 26 */}
              <Card className="mb-6 border-l-4 border-l-amber-400 shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-amber-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                      26
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-800 mb-4 font-serif leading-relaxed">
                        IN WHAT WAY DID JESUS GIVE US AN EXAMPLE OF DEPENDENCE ON MARY?
                      </h3>
                      <div className="prose prose-gray max-w-none">
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          Jesus showed His desire to depend on Mary in the following manner. He became man for our salvation, but it was only in Mary and by Mary. As God He could have chosen a thousand other ways of redeeming us.
                        </p>
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          He willed to be presented to His Father in the Temple by means of the virginal hands of His Mother. For over thirty years He was "subject" to her in all things, and gave only three years to the preaching of the kingdom.
                        </p>
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          As St. Louis de Montfort expressed it, "Jesus Christ gave more glory to God the Father by submission to His Mother during those thirty years, than He would have given Him in converting the whole world by the working of the most stupendous miracles," a thing He would have done if it would have given more honor to God.
                        </p>
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          Then, too, Jesus performed His first miracles of grace and of nature only at the word of Mary. Saint John the Baptist was sanctified, and the water at Cana was made wine because of Mary's word.
                        </p>
                        <p className="text-gray-700 leading-relaxed">
                          And at the end of His life, He tells us simply, "I have given you an example that as I have done . . . so you also should do." (John 13:15.) Thus, it was all this that made St. Louis de Montfort cry out. "O, how highly we glorify God when, to please Him, we submit ourselves to Mary after the example of Jesus Christ, our sole Exemplar." (True Devotion, 18).
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Question 27 */}
              <Card className="mb-6 border-l-4 border-l-amber-400 shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-blue-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                      27
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-800 mb-4 font-serif leading-relaxed">
                        HOW DO WE PRACTICE GREATER HUMILITY BY GOING TO JESUS THROUGH MARY?
                      </h3>
                      <div className="prose prose-gray max-w-none">
                        <p className="text-gray-700 leading-relaxed">
                          The Cure of Ars often used to remark that we sprinkle pride like salt on everything we do; and yet, we seldom reflect on the condition of our soul. By going to Jesus through Mary, we recognize our nothingness and wickedness, and ask her to be our suppliant with Our Lord.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Question 28 */}
              <Card className="mb-6 border-l-4 border-l-amber-400 shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-amber-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                      28
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-800 mb-4 font-serif leading-relaxed">
                        WILL NOT THE GREAT EMPHASIS LAID ON THE POSITION OF THE BLESSED VIRGIN CAUSE US AT LEAST IN SOME MEASURE TO FORGET JESUS?
                      </h3>
                      <div className="prose prose-gray max-w-none">
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          Such a thought was totally foreign to the mind of Saint Louis de Montfort, as can be gathered from his own words, "If we establish solid devotion to our Blessed Lady, it is only to establish more perfectly devotion to Jesus Christ, and to provide an easy and secure means for finding Jesus Christ." (True Devotion, 62.)
                        </p>
                        <p className="text-gray-700 leading-relaxed">
                          Mary is loved only because she is so intimately connected with Jesus. As St. Louis de Montfort puts it, "Thou, Lord, art always with Mary, and Mary is always with Thee, and she cannot be without Thee, else she would cease to be what she is. . . She is so intimately united with Thee that it were easier to separate the light from the sun, the heat from the fire, than to separate Mary from Thee." (True Devotion, 63).
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Question 29 */}
              <Card className="mb-6 border-l-4 border-l-amber-400 shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-blue-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                      29
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-800 mb-4 font-serif leading-relaxed">
                        EVEN THOUGH MARY IS CLOSELY UNITED TO JESUS, DOES THERE NOT STILL SEEM DANGER OF NEGLECTING JESUS?
                      </h3>
                      <div className="prose prose-gray max-w-none">
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          Saint Thomas Aquinas says that, when we will the means to an end, we, by that very act, will also the end. Now, Mary is sought as a means of union with Jesus.
                        </p>
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          Her position, in regard to Jesus, may be likened to that of direction signs on a highway. Do we ignore these signs, and say, "I want to concentrate on the road itself, and I do not want the signs to interfere with my attention?" This would be silly.
                        </p>
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          For the entire purpose of road signs is to call attention to the road. They tell us of the hills and curves, how fast to go, and a thousand other things that make us know the road more thoroughly. The same construction company that built the road, put up the signs, and they placed the signs there to help us.
                        </p>
                        <p className="text-gray-700 leading-relaxed">
                          God the Father, generated the Son, our Way. And this same God gave us Mary as a sign along the way so that the more we investigate the sign, the better will be our knowledge of the road.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Question 30 */}
              <Card className="mb-6 border-l-4 border-l-amber-400 shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-amber-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                      30
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-800 mb-4 font-serif leading-relaxed">
                        DOES IT NOT SEEM FITTING THAT WE SHOULD HONOR JESUS FIRST, AND THEN SPEAK OF LOVING MARY?
                      </h3>
                      <div className="prose prose-gray max-w-none">
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          This would certainly be true if we were praising Mary without considering Christ, but we must remember that, in reality, we honor and love Jesus when we salute Mary. We go to her only as the way by which we are to find the end we are seeking, which is Jesus.
                        </p>
                        <p className="text-gray-700 leading-relaxed">
                          As St. Louis de Montfort remarks, "The Church, with the Holy Ghost, blesses our Lady first, and our Lord second, 'Blessed art thou among women, and blessed is the Fruit of thy womb, Jesus.' It is not that Mary is more than Jesus, or even equal to Him—that would be intolerable heresy.
                        </p>
                        <p className="text-gray-700 leading-relaxed">
                          But it is that, in order to bless Jesus more perfectly, we must begin by blessing Mary. If we praise or glorify her, she immediately praises and glorifies Jesus as of old, when Saint Elizabeth praised her, 'My soul doth magnify the Lord.' " (True Devotion, 95, 148).
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Question 31 */}
              <Card className="mb-6 border-l-4 border-l-amber-400 shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-blue-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                      31
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-800 mb-4 font-serif leading-relaxed">
                        HOW CAN WE PERFORM ALL OUR ACTIONS BY MARY?
                      </h3>
                      <div className="prose prose-gray max-w-none">
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          To act BY MARY means to be completely dependent on her. Before I decide on a course of action, I will ask for her guidance and direction. As I begin my meditation, I ask her to draw my thoughts along the lines she knows will do me the most good.
                        </p>
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          When I act by Mary, I make my intentions hers. I perform the duties of my life in the same spirit that she performed her daily tasks. When I pray, it will be for Mary's intention. My Mass, my Communion, my duties in life, my acts of charity, and my sufferings are all for her intention.
                        </p>
                        <p className="text-gray-700 leading-relaxed">
                          I can form particular intentions, and I should, but they will be formed in the same spirit that Our Lady formed hers.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Question 32 */}
              <Card className="mb-6 border-l-4 border-l-amber-400 shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-amber-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                      32
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-800 mb-4 font-serif leading-relaxed">
                        HOW CAN WE DO ALL OUR ACTIONS WITH MARY?
                      </h3>
                      <div className="prose prose-gray max-w-none">
                        <p className="text-gray-700 leading-relaxed">
                          Saint Louis de Montfort answers this when he writes, "We must do all our actions WITH Mary, that is to say, we must in all our actions, regard Mary as an accomplished model of every virtue and perfection. We must, therefore, in every action, consider how Mary has done it, or how she would have done it, had she been in our place." (True Devotion, 260).
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Question 33 */}
              <Card className="mb-6 border-l-4 border-l-amber-400 shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-blue-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                      33
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-800 mb-4 font-serif leading-relaxed">
                        HOW CAN WE PERFORM ALL OUR ACTIONS IN MARY?
                      </h3>
                      <div className="prose prose-gray max-w-none">
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          We do this by trying to enter into Mary's interior and stay there, adopting her views and feelings. Mary must become, as it were, the place and atmosphere in which we live; her influence must penetrate us.
                        </p>
                        <p className="text-gray-700 leading-relaxed">
                          In our plans and hopes, we naturally consider her, and assign her a place in all our affairs. In a word, companionship with her becomes the constant state of our soul. As St. Louis de Montfort says, "Mary will be the only means used by our souls in dealing with God." (Secret of Mary, 47).
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Question 34 */}
              <Card className="mb-6 border-l-4 border-l-amber-400 shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-amber-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                      34
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-800 mb-4 font-serif leading-relaxed">
                        HOW CAN WE PERFORM ALL OUR ACTIONS FOR MARY?
                      </h3>
                      <div className="prose prose-gray max-w-none">
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          When we do all our actions FOR Mary, we recall the fact that we are now slaves of the Queen of Heaven. Seeing that our Queen is so very good, we will continue to offer her love and praise.
                        </p>
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          With the words of St. Louis de Montfort, we will address ourselves to Mary, "O my dear Mother, it is for thee that I go here or there; for thee that I do this or that; for thee that I suffer this pain or that wrong." (Secret of Mary, 49).
                        </p>
                        <p className="text-gray-700 leading-relaxed">
                          Our love will lead us to seek out opportunities that she may use them to spread the kingdom of her Son. Hand in hand with our own personal love and service for her, will come the desire to have others know her. We will spend ourselves in bringing others to the love of Jesus in Mary. All the world must be given the opportunity and privilege of serving Our Lady.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Question 35 */}
              <Card className="mb-6 border-l-4 border-l-amber-400 shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-blue-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                      35
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-800 mb-4 font-serif leading-relaxed">
                        WHEN ST. LOUIS DE MONTFORT SAYS "MARY WILL BE THE ONLY MEANS USED BY OUR SOUL IN DEALING WITH GOD," DOES HE MEAN TO SAY THAT WE ARE NO LONGER TO PRAY DIRECTLY TO JESUS?
                      </h3>
                      <div className="prose prose-gray max-w-none">
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          No, he does not mean that at all. The entire purpose of his devotion is to cultivate a more intimate union with Jesus, and the constant conversation of our soul with God is one of the best ways of being united to Him.
                        </p>
                        <p className="text-gray-700 leading-relaxed">
                          It is Mary's part to bring us together and to purify us that we be more fit for this union with Jesus. Before we pray, we tell Jesus that we are offering Him these prayers through Mary and that we wish to speak with Him just as she did.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Question 36 */}
              <Card className="mb-6 border-l-4 border-l-amber-400 shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-amber-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                      36
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-800 mb-4 font-serif leading-relaxed">
                        IF WE PERFORM ALL OUR ACTIONS THROUGH MARY, CAN WE STILL PRAY TO OTHER SAINTS?
                      </h3>
                      <div className="prose prose-gray max-w-none">
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          We may, and should pray to the Saints after we have made this consecration. Remember that Mary is Queen of all Saints, and that they all serve her as their loving Mistress.
                        </p>
                        <p className="text-gray-700 leading-relaxed">
                          When we ask the Saints for a favor, we are, in reality, asking them to intercede for us with our Lady. "In vain," says Saint Bernard, "would a person ask other Saints for a favor, if Mary did not interpose to obtain it." The Saints received all their virtues and graces by the intercession of Mary; so, when we ask them to obtain a special favor for us, we are using them as our advocates with Mary, our Queen.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Question 37 */}
              <Card className="mb-6 border-l-4 border-l-amber-400 shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-blue-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                      37
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-800 mb-4 font-serif leading-relaxed">
                        IF WE MAKE THE ACT OF CONSECRATION, DO WE ALWAYS HAVE TO BE THINKING OF MARY?
                      </h3>
                      <div className="prose prose-gray max-w-none">
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          Since we are all human, it is impossible for us actually and distinctly to think of Mary in each of our actions. It is sufficient to make our Act of Consecration to Mary with the intention of doing all things for, with, and in, and by her, and then not to retract that intention.
                        </p>
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          A mother is not always actually thinking of her family as she goes about washing, cleaning, etc., but if we should stop her, and ask her why she is doing all this, she would answer, "Out of love for my family." It is the same in our relationship with Mary. Dependence on her is the habitual state of our soul.
                        </p>
                        <p className="text-gray-700 leading-relaxed">
                          However, we should remember that the more often we think of her, the more perfect will be our devotion. Saint Louis de Montfort says: "We must, from time to time, both during an after the action, renew our act of offering and union. The more often we do so, the sooner we shall be sanctified, and attain to union with Jesus Christ, which always follows necessarily on our union with Mary." (True Devotion, 259).
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Question 38 */}
              <Card className="mb-6 border-l-4 border-l-amber-400 shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-amber-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                      38
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-800 mb-4 font-serif leading-relaxed">
                        IF I NOW SAY THE ROSARY AND PRAY TO OUR LADY, WHY SHOULD I ADD TRUE DEVOTION?
                      </h3>
                      <div className="prose prose-gray max-w-none">
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          First of all, True Devotion is not a matter of commandment. It is merely a question of love. One would not, by any means, be damned, if he did not practice True Devotion.
                        </p>
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          Saint Louis de Montfort himself tells us that all forms of true devotion to Mary are "good, holy, and praiseworthy." But he adds that they are "not so perfect, nor so efficient in severing our soul from creatures, or in detaching us from ourselves, in order to be united with Jesus Christ," (Secret of Mary, 26), as is the practice of Holy Slavery.
                        </p>
                        <p className="text-gray-700 leading-relaxed">
                          It is a question of generosity. St. Louis de Montfort asks for the complete gift of self to Jesus Christ through the best means, Mary.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Question 39 */}
              <Card className="mb-6 border-l-4 border-l-amber-400 shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-blue-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                      39
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-800 mb-4 font-serif leading-relaxed">
                        WILL NOT THE ADDITION OF ANOTHER DEVOTION ONLY TEND TO CONFUSE?
                      </h3>
                      <div className="prose prose-gray max-w-none">
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          True Devotion is not "another devotion"; it is a consecration, a way of life that embraces all other devotions. Thus, it is not something different from devotion to the Sacred Heart, the Precious Blood, or the Eucharist.
                        </p>
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          It is a part of every holy practice in the Church; it permeates every devotion and makes us see the hidden and holy things they contain. It makes us live the Mass as Mary lived it.
                        </p>
                        <p className="text-gray-700 leading-relaxed">
                          In short, it means that Mary is with us, teaching us what all of these other devotions mean, and making us love them as she did.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Question 40 */}
              <Card className="mb-6 border-l-4 border-l-amber-400 shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-amber-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                      40
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-800 mb-4 font-serif leading-relaxed">
                        DOES NOT A PERSON HAVE TO BE VERY HOLY BEFORE HE CAN PRACTICE THIS DEVOTION TO JESUS AND MARY?
                      </h3>
                      <div className="prose prose-gray max-w-none">
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          It must be remembered that Saint Louis de Montfort taught this devotion not to a chosen few, but to all the people who attended the various missions that he conducted. The entire idea of his slavery of love was to OBTAIN union with Jesus. Therefore, it is a way of perfection, and not a reward for virtue.
                        </p>
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          He gives it to all that they might find an "easy, short, and secure" path to Jesus. Surely, one does not show another how to get to a place if he is already there.
                        </p>
                        <p className="mb-4 text-gray-700 leading-relaxed">
                          When Saint Louis de Montfort says that we are to give this devotion only "to those who deserve it by their prayers, their alms-deeds, and mortifications," he is laying stress on one point only, and that is, that the person must have a desire for bettering himself spiritually.
                        </p>
                        <p className="text-gray-700 leading-relaxed">
                          This is only common sense, for you do not teach someone a more perfect way of sanctifying himself if he is not interested in sanctifying himself at all. If you really want to be more like Jesus, practice True Devotion. If you are not interested particularly in attaining holiness, please do not begin to practice this holy slavery of love.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Conclusion */}
              <Card className="mb-6 border-l-4 border-l-emerald-400 shadow-md hover:shadow-lg transition-shadow duration-300 bg-gradient-to-r from-emerald-50 to-green-50">
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-12 h-12 bg-emerald-600 text-white rounded-full flex items-center justify-center">
                      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                    <div className="flex-1">
                      <h2 className="text-2xl font-bold text-emerald-800 mb-4 font-serif">
                        CONCLUSION
                      </h2>
                      <div className="prose prose-gray max-w-none">
                        <p className="text-gray-700 leading-relaxed mb-4">
                          The foregoing, in brief outline, is the teaching of Saint Louis-Marie Grignion de Montfort on our Blessed Mother. Since his time, people by the thousands from every walk and vocation of life have used him as their guide to heavenly living. They have found in this teaching the joy and peace that Christ promised to all "men of good will." A selection of some of their tributes of praise has been made so that we may see the high value that these individuals have set on the faithful practice of Saint Louis de Montfort's True Devotion to the Blessed Virgin Mary.
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="mt-6 bg-emerald-100 p-4 rounded-lg border-l-4 border-emerald-500">
                    <p className="text-emerald-800 text-sm">
                      <strong>Status:</strong> ✓ Complete 12-page "A Catechism of True Devotion to Mary" with questions 1-40 and authentic conclusion from St. Louis de Montfort. All content verified and properly formatted with beautiful card-style layout.
                    </p>
                  </div>
                </div>
              </Card>
            </TabsContent>

            {/* Daily Prayers Tab */}
            <TabsContent value="daily" className="mt-0">
              <DayDetail 
                day={selectedDay}
                novena={typedNovena}
                dailyPrayer={dailyPrayer}
                onComplete={() => markDayComplete.mutate()}
                isPending={markDayComplete.isPending}
              />
            </TabsContent>
            
            {/* Complete Consecration Text Tab */}
            <TabsContent value="consecration" className="mt-0">
              <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg shadow-lg p-8">
                <div className="text-center mb-10">
                  {/* Beautiful Image of Mother Mary */}
                  <div className="flex justify-center mb-8">
                    <div className="relative">
                      <div className="w-32 h-32 md:w-40 md:h-40 bg-gradient-to-br from-blue-100 to-indigo-200 rounded-full p-4 shadow-lg border-4 border-white">
                        <svg viewBox="0 0 200 200" className="w-full h-full">
                          {/* Halo */}
                          <circle cx="100" cy="80" r="60" fill="none" stroke="url(#haloGradient)" strokeWidth="2" opacity="0.6"/>
                          
                          {/* Face */}
                          <ellipse cx="100" cy="90" rx="35" ry="45" fill="url(#skinGradient)"/>
                          
                          {/* Veil */}
                          <path d="M 65 70 Q 100 50 135 70 L 135 160 Q 100 170 65 160 Z" fill="url(#veilGradient)"/>
                          
                          {/* Hair visible under veil */}
                          <path d="M 75 75 Q 100 65 125 75 Q 120 85 100 80 Q 80 85 75 75" fill="#8B4513"/>
                          
                          {/* Eyes */}
                          <ellipse cx="90" cy="85" rx="3" ry="4" fill="#2563EB"/>
                          <ellipse cx="110" cy="85" rx="3" ry="4" fill="#2563EB"/>
                          <circle cx="91" cy="84" r="1" fill="white"/>
                          <circle cx="111" cy="84" r="1" fill="white"/>
                          
                          {/* Nose */}
                          <path d="M 100 90 L 98 95 L 102 95" stroke="#D4A574" strokeWidth="1" fill="none"/>
                          
                          {/* Mouth */}
                          <path d="M 95 100 Q 100 103 105 100" stroke="#CD5C5C" strokeWidth="1.5" fill="none"/>
                          
                          {/* Hands in prayer */}
                          <ellipse cx="85" cy="140" rx="8" ry="12" fill="url(#skinGradient)" transform="rotate(-15 85 140)"/>
                          <ellipse cx="115" cy="140" rx="8" ry="12" fill="url(#skinGradient)" transform="rotate(15 115 140)"/>
                          
                          {/* Robe */}
                          <path d="M 70 120 Q 100 115 130 120 L 130 180 Q 100 185 70 180 Z" fill="url(#robeGradient)"/>
                          
                          {/* Stars around */}
                          <g fill="url(#starGradient)">
                            <path d="M 50 60 L 52 66 L 58 66 L 53 70 L 55 76 L 50 72 L 45 76 L 47 70 L 42 66 L 48 66 Z"/>
                            <path d="M 150 60 L 152 66 L 158 66 L 153 70 L 155 76 L 150 72 L 145 76 L 147 70 L 142 66 L 148 66 Z"/>
                            <path d="M 40 120 L 42 126 L 48 126 L 43 130 L 45 136 L 40 132 L 35 136 L 37 130 L 32 126 L 38 126 Z"/>
                            <path d="M 160 120 L 162 126 L 168 126 L 163 130 L 165 136 L 160 132 L 155 136 L 157 130 L 152 126 L 158 126 Z"/>
                          </g>
                          
                          {/* Gradients */}
                          <defs>
                            <radialGradient id="haloGradient" cx="50%" cy="30%">
                              <stop offset="0%" stopColor="#FFD700" stopOpacity="0.8"/>
                              <stop offset="100%" stopColor="#FFA500" stopOpacity="0.4"/>
                            </radialGradient>
                            <linearGradient id="skinGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                              <stop offset="0%" stopColor="#F4C2A1"/>
                              <stop offset="100%" stopColor="#D4A574"/>
                            </linearGradient>
                            <linearGradient id="veilGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                              <stop offset="0%" stopColor="#4F46E5"/>
                              <stop offset="50%" stopColor="#6366F1"/>
                              <stop offset="100%" stopColor="#3B82F6"/>
                            </linearGradient>
                            <linearGradient id="robeGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                              <stop offset="0%" stopColor="#FFFFFF"/>
                              <stop offset="100%" stopColor="#E5E7EB"/>
                            </linearGradient>
                            <linearGradient id="starGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                              <stop offset="0%" stopColor="#FFD700"/>
                              <stop offset="100%" stopColor="#FFA500"/>
                            </linearGradient>
                          </defs>
                        </svg>
                      </div>
                      {/* Decorative border around image */}
                      <div className="absolute -inset-2 bg-gradient-to-r from-indigo-300 via-purple-300 to-indigo-300 rounded-full opacity-20 animate-pulse"></div>
                    </div>
                  </div>
                  
                  <div className="bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-600 bg-clip-text text-transparent mb-4">
                    <h3 className="font-serif text-4xl md:text-5xl font-bold leading-tight tracking-wide">
                      Act of Consecration
                    </h3>
                  </div>
                  <div className="space-y-2 mb-6">
                    <p className="font-serif text-2xl md:text-3xl text-indigo-700 font-semibold">
                      To Jesus Christ,
                    </p>
                    <p className="font-serif text-xl md:text-2xl text-indigo-600 italic">
                      the Incarnate Wisdom,
                    </p>
                    <p className="font-serif text-2xl md:text-3xl text-indigo-700 font-semibold">
                      through the Blessed Virgin Mary
                    </p>
                  </div>
                  <div className="flex items-center justify-center space-x-4 mb-4">
                    <div className="w-16 h-0.5 bg-gradient-to-r from-transparent to-indigo-400"></div>
                    <div className="text-3xl text-indigo-500">✦</div>
                    <div className="w-16 h-0.5 bg-gradient-to-l from-transparent to-indigo-400"></div>
                  </div>
                  <p className="text-indigo-500 italic text-lg font-medium mb-6">
                    By Saint Louis de Montfort
                  </p>
                  
                  {/* Interactive Action Buttons */}
                  <div className="flex flex-wrap justify-center gap-3 mb-6">
                    <button
                      onClick={handleDownloadConsecration}
                      className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg font-medium transition-colors shadow-md"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                      </svg>
                      Download Text
                    </button>
                    
                    <button
                      onClick={handleShareConsecration}
                      className="flex items-center gap-2 bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg font-medium transition-colors shadow-md"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.367 2.684 3 3 0 00-5.367-2.684z" />
                      </svg>
                      Share
                    </button>
                    
                    <button
                      onClick={handleAudioPlayback}
                      className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg font-medium transition-colors shadow-md"
                    >
                      {isPlaying ? (
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 9v6m4-6v6" />
                        </svg>
                      ) : (
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.828 14.828a4 4 0 01-5.656 0M9 10h1.586a1 1 0 01.707.293l2.414 2.414a1 1 0 00.707.293H15a2 2 0 002-2V9a2 2 0 00-2-2h-1.586a1 1 0 01-.707-.293L10.293 4.293A1 1 0 009.586 4H8a2 2 0 00-2 2v3a2 2 0 002 2z" />
                        </svg>
                      )}
                      {isPlaying ? 'Stop Audio' : 'Listen'}
                    </button>
                    
                    <button
                      onClick={handleCopyToClipboard}
                      className="flex items-center gap-2 bg-amber-600 hover:bg-amber-700 text-white px-4 py-2 rounded-lg font-medium transition-colors shadow-md"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2-2v8a2 2 0 002 2z" />
                      </svg>
                      Copy Text
                    </button>
                  </div>
                  
                  {/* Audio Progress Indicator */}
                  {isPlaying && (
                    <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
                      <div className="flex items-center gap-3">
                        <div className="animate-pulse">
                          <svg className="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 14.142M9 17.656l4.464-4.464a5 5 0 000-7.071L9 1.757" />
                          </svg>
                        </div>
                        <div className="flex-1">
                          <p className="text-green-800 font-medium">Audio playback in progress...</p>
                          <p className="text-green-600 text-sm">Listen prayerfully to the sacred words of consecration</p>
                        </div>
                        <button
                          onClick={handleAudioPlayback}
                          className="text-green-600 hover:text-green-800 transition-colors"
                        >
                          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 9v6m4-6v6" />
                          </svg>
                        </button>
                      </div>
                    </div>
                  )}
                </div>
                
                <div className="prose prose-slate max-w-none">
                  <div className="bg-white/70 backdrop-blur-sm rounded-xl p-6 border border-indigo-200 shadow-inner mb-6">
                    <p className="text-center italic text-indigo-700 mb-6 text-lg">
                      On the day of consecration, either at the end of the 33-day period of preparation or on a Marian feast day, recite this sacred prayer with devotion:
                    </p>
                  </div>
                  
                  {/* Main Consecration Prayer */}
                  <div className="bg-white rounded-2xl p-8 shadow-lg border-l-8 border-indigo-400 mb-8">
                    <h4 className="text-center text-2xl font-serif font-bold text-indigo-800 mb-8 tracking-wide">
                      ACT OF CONSECRATION TO JESUS CHRIST<br/>
                      THE INCARNATE WISDOM<br/>
                      THROUGH THE BLESSED VIRGIN MARY
                    </h4>
                    
                    <div className="space-y-8 text-lg leading-relaxed">
                      {/* Opening Adoration */}
                      <div className="calligraphic-text bg-gradient-to-r from-indigo-50 to-blue-50 rounded-lg p-6 border border-indigo-200">
                        <p className="text-gray-800 font-medium leading-9 text-xl">
                          <span className="text-4xl text-indigo-600 font-serif font-bold">O</span> Eternal and incarnate Wisdom! O sweetest and most adorable Jesus! True God and true man, only Son of the Eternal Father, and of Mary, always virgin! I adore Thee profoundly in the bosom and splendors of Thy Father during eternity; and I adore Thee also in the virginal bosom of Mary, Thy most worthy Mother, in the time of Thine incarnation.
                        </p>
                      </div>
                      
                      <div className="calligraphic-text border-l-4 border-indigo-200 pl-6">
                        <p className="text-gray-800 font-medium leading-9">
                          <span className="text-3xl text-indigo-600 font-serif font-bold">I</span> give Thee thanks for that Thou hast annihilated Thyself, taking the form of a slave in order to rescue me from the cruel slavery of the devil. I praise and glorify Thee for that Thou hast been pleased to submit Thyself to Mary, Thy holy Mother, in all things, in order to make me Thy faithful slave through her.
                        </p>
                      </div>
                      
                      <div className="calligraphic-text">
                        <p className="text-gray-800 font-medium leading-9">
                          <span className="text-3xl text-indigo-600 font-serif font-bold">B</span>ut, alas! Ungrateful and faithless as I have been, I have not kept the promises which I made so solemnly to Thee in my Baptism; I have not fulfilled my obligations; I do not deserve to be called Thy child, nor yet Thy slave; and as there is nothing in me which does not merit Thine anger and Thy repulse, I dare not come by myself before Thy most holy and august Majesty.
                        </p>
                      </div>
                      
                      <div className="calligraphic-text border-l-4 border-indigo-200 pl-6">
                        <p className="text-gray-800 font-medium leading-9">
                          <span className="text-3xl text-indigo-600 font-serif font-bold">I</span>t is on this account that I have recourse to the intercession of Thy most holy Mother, whom Thou hast given me for a mediatrix with Thee. It is through her that I hope to obtain of Thee contrition, the pardon of my sins, and the acquisition and preservation of wisdom.
                        </p>
                      </div>
                      
                      {/* Hail Mary Section */}
                      <div className="calligraphic-text bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-6 border-2 border-indigo-300">
                        <p className="text-gray-800 font-medium leading-9 text-xl">
                          <span className="text-4xl text-indigo-600 font-serif font-bold">H</span>ail, then, O immaculate Mary, living tabernacle of the Divinity, where the Eternal Wisdom willed to be hidden and to be adored by angels and by men! Hail, O Queen of Heaven and earth, to whose empire everything is subject which is under God. Hail, O sure refuge of sinners, whose mercy fails no one. Hear the desires which I have of the Divine Wisdom; and for that end receive the vows and offerings which in my lowliness I present to thee.
                        </p>
                      </div>
                      
                      {/* Main Consecration */}
                      <div className="calligraphic-text bg-gradient-to-br from-indigo-100 to-purple-100 rounded-xl p-8 border-2 border-indigo-400 shadow-inner">
                        <p className="text-gray-800 font-medium leading-9 text-xl mb-6">
                          <span className="text-4xl text-indigo-600 font-serif font-bold">I</span>, <em className="text-indigo-700 font-bold">[Your Name]</em>, a faithless sinner, renew and ratify today in thy hands the vows of my Baptism; I renounce forever Satan, his pomps and works; and I give myself entirely to Jesus Christ, the Incarnate Wisdom, to carry my cross after Him all the days of my life, and to be more faithful to Him than I have ever been before.
                        </p>
                        
                        <p className="text-gray-800 font-medium leading-9 text-xl">
                          <span className="text-3xl text-indigo-600 font-serif font-bold">I</span>n the presence of all the heavenly court I choose thee this day for my Mother and Mistress. I deliver and consecrate to thee, as thy slave, my body and soul, my goods, both interior and exterior, and even the value of all my good actions, past, present and future; leaving to thee the entire and full right of disposing of me, and all that belongs to me, without exception, according to thy good pleasure, for the greater glory of God, in time and in eternity.
                        </p>
                      </div>
                      
                      <div className="calligraphic-text">
                        <p className="text-gray-800 font-medium leading-9">
                          <span className="text-3xl text-indigo-600 font-serif font-bold">R</span>eceive, O benignant Virgin, this little offering of my slavery, in honor of, and in union with, that subjection which the Eternal Wisdom deigned to have to thy maternity; in homage to the power which both of you have over this poor sinner, and in thanksgiving for the privileges with which the Holy Trinity has favored thee. I declare that I wish henceforth, as thy true slave, to seek thy honor and to obey thee in all things.
                        </p>
                      </div>
                      
                      <div className="calligraphic-text border-l-4 border-indigo-200 pl-6">
                        <p className="text-gray-800 font-medium leading-9">
                          <span className="text-3xl text-indigo-600 font-serif font-bold">O</span> admirable Mother, present me to thy dear Son as His eternal slave, so that as He has redeemed me by thee, by thee He may receive me! O Mother of mercy, grant me the grace to obtain the true Wisdom of God; and for that end receive me among those whom thou lovest and teachest, whom thou leadest, nourishest and protectest as thy children and thy slaves.
                        </p>
                      </div>
                      
                      {/* Final Prayer */}
                      <div className="calligraphic-text text-center bg-gradient-to-br from-indigo-50 to-purple-50 rounded-xl p-8 border-4 border-indigo-300 shadow-lg">
                        <p className="text-gray-800 font-medium leading-9 text-2xl mb-6">
                          <span className="text-5xl text-indigo-600 font-serif font-bold">O</span> faithful Virgin, make me in all things so perfect a disciple, imitator and slave of the Incarnate Wisdom, Jesus Christ thy Son, that I may attain, by thine intercession and by thine example, to the fullness of His age on earth and of His glory in Heaven.
                        </p>
                        <p className="text-3xl font-serif font-bold text-indigo-800 mb-6">Amen.</p>
                        
                        {/* Signature Section */}
                        <div className="border-t-2 border-indigo-300 pt-6 mt-8">
                          <div className="text-left space-y-4">
                            <div className="border-b-2 border-indigo-200 pb-2">
                              <p className="text-lg text-gray-700 mb-2">Sign your name here:</p>
                              <div className="h-8 border-b border-gray-400"></div>
                            </div>
                            <div className="border-b-2 border-indigo-200 pb-2">
                              <p className="text-lg text-gray-700 mb-2">Date:</p>
                              <div className="h-8 border-b border-gray-400"></div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Additional Sections */}
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="bg-white rounded-xl p-6 shadow-md border border-indigo-100">
                      <h4 className="text-xl font-serif font-bold text-indigo-800 mb-4 flex items-center">
                        <span className="text-2xl mr-2">🔄</span>
                        Renewal of Consecration
                      </h4>
                      <p className="text-gray-700 leading-relaxed">
                        It is recommended to renew your consecration periodically, especially on Marian feast days. This renewal strengthens your commitment and deepens your relationship with Jesus through Mary.
                      </p>
                    </div>
                    
                    <div className="bg-white rounded-xl p-6 shadow-md border border-indigo-100">
                      <h4 className="text-xl font-serif font-bold text-indigo-800 mb-4 flex items-center">
                        <span className="text-2xl mr-2">🌟</span>
                        Living Your Consecration
                      </h4>
                      <p className="text-gray-700 mb-3">After making your consecration, strive to:</p>
                      <ul className="text-gray-700 space-y-2 text-sm">
                        <li className="flex items-start">
                          <span className="text-indigo-500 mr-2 mt-1">•</span>
                          Live in the spirit of this consecration in all your actions
                        </li>
                        <li className="flex items-start">
                          <span className="text-indigo-500 mr-2 mt-1">•</span>
                          Develop a deeper devotion to the Blessed Virgin Mary
                        </li>
                        <li className="flex items-start">
                          <span className="text-indigo-500 mr-2 mt-1">•</span>
                          Pray the Rosary daily if possible
                        </li>
                        <li className="flex items-start">
                          <span className="text-indigo-500 mr-2 mt-1">•</span>
                          Wear a Marian sacramental (Brown Scapular or Miraculous Medal)
                        </li>
                        <li className="flex items-start">
                          <span className="text-indigo-500 mr-2 mt-1">•</span>
                          Celebrate Marian feast days
                        </li>
                        <li className="flex items-start">
                          <span className="text-indigo-500 mr-2 mt-1">•</span>
                          Frequently renew your consecration
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      
      <BottomNavigation />
    </div>
  );
}
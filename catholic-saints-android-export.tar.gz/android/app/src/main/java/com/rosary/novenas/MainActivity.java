package com.rosary.novenas;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}

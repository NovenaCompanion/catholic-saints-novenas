import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  icon: text("icon").notNull(),
  iconBgColor: text("icon_bg_color").notNull().default("bg-blue-100"),
  iconColor: text("icon_color").notNull().default("text-primary"),
  imageUrl: text("image_url"),
});

export const saints = pgTable("saints", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  title: text("title"),
  description: text("description").notNull(),
  imageUrl: text("image_url"),
  feastDay: text("feast_day"),
  patronOf: text("patron_of"),
  born: text("born"),
  died: text("died"),
  prayer: text("prayer").notNull(),
  isPopular: boolean("is_popular").default(false),
  novenaLength: integer("novena_length").default(9),
});

export const saintCategories = pgTable("saint_categories", {
  id: serial("id").primaryKey(),
  saintId: integer("saint_id").notNull().references(() => saints.id),
  categoryId: integer("category_id").notNull().references(() => categories.id),
});

export const novenaPrayers = pgTable("novena_prayers", {
  id: serial("id").primaryKey(),
  saintId: integer("saint_id").notNull().references(() => saints.id),
  day: integer("day").notNull(), // Day number (starts at 1)
  title: text("title"),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const novenas = pgTable("novenas", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  saintId: integer("saint_id").notNull().references(() => saints.id),
  startDate: timestamp("start_date").notNull().defaultNow(),
  currentDay: integer("current_day").notNull().default(1),
  completedDays: json("completed_days").$type<number[]>().notNull().default([]),
  intention: text("intention"),
  isComplete: boolean("is_complete").notNull().default(false),
});

export const testimonials = pgTable("testimonials", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  saintId: integer("saint_id").notNull().references(() => saints.id),
  title: text("title").notNull(),
  content: text("content").notNull(),
  favorsReceived: text("favors_received").notNull(),
  approved: boolean("approved").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const rosaryNovenas = pgTable("rosary_novenas", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  startDate: timestamp("start_date").notNull().defaultNow(),
  currentDay: integer("current_day").notNull().default(1),
  completedDays: json("completed_days").$type<number[]>().notNull().default([]),
  intentions: text("intentions"),
  isComplete: boolean("is_complete").notNull().default(false),
  phase: text("phase").notNull().default("petition"), // "petition" or "thanksgiving"
});

export const rosaryNovenaTexts = pgTable("rosary_novena_texts", {
  id: serial("id").primaryKey(),
  day: integer("day").notNull(), // 1-54
  phase: text("phase").notNull(), // "petition" or "thanksgiving"
  title: text("title").notNull(),
  content: text("content").notNull(),
  reflection: text("reflection"),
  intention: text("intention"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const rosaryNovenaInfo = pgTable("rosary_novena_info", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(), // "origin", "method", "promises", etc.
  title: text("title").notNull(),
  content: text("content").notNull(),
  order: integer("order").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const persistentImages = pgTable("persistent_images", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(), // 'header', 'category', 'universal-saint'
  data: text("data").notNull(), // base64 encoded image data
  mimeType: text("mime_type").notNull(), // image/jpeg, image/png, etc.
  originalName: text("original_name"),
  size: integer("size"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Relations
export const categoriesRelations = relations(categories, ({ many }) => ({
  saintCategories: many(saintCategories),
}));

export const saintsRelations = relations(saints, ({ many }) => ({
  saintCategories: many(saintCategories),
  novenas: many(novenas),
  novenaPrayers: many(novenaPrayers),
  testimonials: many(testimonials),
}));

export const saintCategoriesRelations = relations(saintCategories, ({ one }) => ({
  saint: one(saints, { fields: [saintCategories.saintId], references: [saints.id] }),
  category: one(categories, { fields: [saintCategories.categoryId], references: [categories.id] }),
}));

export const novenaPrayersRelations = relations(novenaPrayers, ({ one }) => ({
  saint: one(saints, { fields: [novenaPrayers.saintId], references: [saints.id] }),
}));

export const novenasRelations = relations(novenas, ({ one }) => ({
  saint: one(saints, { fields: [novenas.saintId], references: [saints.id] }),
}));

export const testimonialsRelations = relations(testimonials, ({ one }) => ({
  saint: one(saints, { fields: [testimonials.saintId], references: [saints.id] }),
}));

export const rosaryNovenasRelations = relations(rosaryNovenas, ({ many }) => ({
  // No direct relations needed for this table
}));

export const rosaryNovenaTextsRelations = relations(rosaryNovenaTexts, ({ }) => ({
  // No direct relations needed for this table
}));

export const rosaryNovenaInfoRelations = relations(rosaryNovenaInfo, ({ }) => ({
  // No direct relations needed for this table
}));

// Schemas
export const categoryInsertSchema = createInsertSchema(categories);
export type CategoryInsert = z.infer<typeof categoryInsertSchema>;
export type Category = typeof categories.$inferSelect;

export const saintInsertSchema = createInsertSchema(saints);
export type SaintInsert = z.infer<typeof saintInsertSchema>;
export type Saint = typeof saints.$inferSelect;

export const saintCategoryInsertSchema = createInsertSchema(saintCategories);
export type SaintCategoryInsert = z.infer<typeof saintCategoryInsertSchema>;
export type SaintCategory = typeof saintCategories.$inferSelect;

export const novenaInsertSchema = createInsertSchema(novenas);
export type NovenaInsert = z.infer<typeof novenaInsertSchema>;
export type Novena = typeof novenas.$inferSelect;

export const novenaPrayerInsertSchema = createInsertSchema(novenaPrayers);
export type NovenaPrayerInsert = z.infer<typeof novenaPrayerInsertSchema>;
export type NovenaPrayer = typeof novenaPrayers.$inferSelect;

export const testimonialInsertSchema = createInsertSchema(testimonials);
export type TestimonialInsert = z.infer<typeof testimonialInsertSchema>;
export type Testimonial = typeof testimonials.$inferSelect;

export const rosaryNovenaInsertSchema = createInsertSchema(rosaryNovenas);
export type RosaryNovenaInsert = z.infer<typeof rosaryNovenaInsertSchema>;
export type RosaryNovena = typeof rosaryNovenas.$inferSelect;

export const rosaryNovenaTextInsertSchema = createInsertSchema(rosaryNovenaTexts);
export type RosaryNovenaTextInsert = z.infer<typeof rosaryNovenaTextInsertSchema>;
export type RosaryNovenaText = typeof rosaryNovenaTexts.$inferSelect;

export const rosaryNovenaInfoInsertSchema = createInsertSchema(rosaryNovenaInfo);
export type RosaryNovenaInfoInsert = z.infer<typeof rosaryNovenaInfoInsertSchema>;
export type RosaryNovenaInfo = typeof rosaryNovenaInfo.$inferSelect;

export const persistentImageInsertSchema = createInsertSchema(persistentImages);
export type PersistentImageInsert = z.infer<typeof persistentImageInsertSchema>;
export type PersistentImage = typeof persistentImages.$inferSelect;

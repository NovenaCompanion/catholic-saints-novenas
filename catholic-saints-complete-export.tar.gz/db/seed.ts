import { db } from "./index";
import * as schema from "@shared/schema";

async function seed() {
  try {
    // Seed categories
    const categories = [
      {
        name: "Jobs",
        description: "Saints who help with employment and career matters",
        icon: "fas fa-briefcase",
        iconBgColor: "bg-blue-100",
        iconColor: "text-primary"
      },
      {
        name: "Health",
        description: "Saints who intercede for physical and mental health",
        icon: "fas fa-heartbeat",
        iconBgColor: "bg-green-100",
        iconColor: "text-green-600"
      },
      {
        name: "Journey Mercy",
        description: "Saints who protect travelers and journeys",
        icon: "fas fa-route",
        iconBgColor: "bg-yellow-100",
        iconColor: "text-yellow-600"
      },
      {
        name: "Family",
        description: "Saints who protect and bless families",
        icon: "fas fa-home",
        iconBgColor: "bg-red-100",
        iconColor: "text-red-600"
      },
      {
        name: "Studies",
        description: "Saints who help with learning and academic pursuits",
        icon: "fas fa-book",
        iconBgColor: "bg-purple-100",
        iconColor: "text-purple-600"
      },
      {
        name: "Protection",
        description: "Saints who offer protection from harm",
        icon: "fas fa-shield-alt",
        iconBgColor: "bg-blue-100",
        iconColor: "text-blue-600"
      },
      {
        name: "Impossible Causes",
        description: "Saints who help with difficult or impossible situations",
        icon: "fas fa-mountain",
        iconBgColor: "bg-green-100",
        iconColor: "text-green-700"
      },
      {
        name: "Healing",
        description: "Saints who intercede for healing and recovery",
        icon: "fas fa-medical-kit",
        iconBgColor: "bg-yellow-100",
        iconColor: "text-yellow-700"
      }
    ];

    // Check if categories already exist
    const existingCategories = await db.query.categories.findMany();
    if (existingCategories.length === 0) {
      console.log("Seeding categories...");
      await db.insert(schema.categories).values(categories);
    }

    // Seed saints
    const saints = [
      {
        name: "St. Joseph",
        title: "Foster Father of Jesus, Spouse of the Blessed Virgin Mary",
        description: "Patron saint of workers, fathers, and families. Known for intercession in employment matters.",
        imageUrl: "https://images.unsplash.com/photo-1519677584237-752f8853252e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        feastDay: "March 19",
        patronOf: "Workers, Families, Fathers",
        born: "1st Century BC",
        died: "1st Century AD",
        prayer: "O Saint Joseph, whose protection is so great, so strong, so prompt before the throne of God, I place in you all my interests and desires.\n\nO Saint Joseph, do assist me by your powerful intercession and obtain for me from your divine Son all spiritual blessings through Jesus Christ, Our Lord, so that having experienced here below your heavenly power, I may offer my thanksgiving and homage to the most loving of fathers.\n\nO Saint Joseph, I never weary of contemplating you and Jesus asleep in your arms. I dare not approach while He reposes near your heart. Hold Him close in my name and kiss His fine head from me, and ask Him to return the kiss when I draw my dying breath. Amen.\n\nSaint Joseph, patron of departed souls, pray for me. (Mention your intention) Amen.",
        isPopular: true
      },
      {
        name: "St. Jude Thaddeus",
        title: "Apostle and Martyr",
        description: "Patron saint of desperate situations and lost causes. Powerful intercessor for difficult circumstances.",
        imageUrl: "https://images.unsplash.com/photo-1591289009723-aef0a1a8a211?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        feastDay: "October 28",
        patronOf: "Desperate Situations, Lost Causes",
        born: "1st Century",
        died: "1st Century",
        prayer: "Most holy Apostle, St. Jude, faithful servant and friend of Jesus, the Church honors and invokes you universally, as the patron of difficult cases, of things almost despaired of. Pray for me, I am so helpless and alone. Make use I implore you, of that particular privilege given to you, to bring visible and speedy help where help is almost despaired of.\n\nCome to my assistance in this great need that I may receive the consolation and help of heaven in all my necessities, tribulations, and sufferings, particularly (mention your request) and that I may praise God with you and all the elect forever.\n\nI promise, O blessed St. Jude, to be ever mindful of this great favor granted me by God, to always honor you as my special and powerful patron, and to gratefully encourage devotion to you. Amen.",
        isPopular: true
      },
      {
        name: "St. Michael",
        title: "Archangel",
        description: "Archangel and leader of God's army. Protector against evil and spiritual warfare.",
        imageUrl: "https://images.unsplash.com/photo-1600093112291-7b553e3fcb82?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        feastDay: "September 29",
        patronOf: "Police Officers, Military, The Sick",
        born: "",
        died: "",
        prayer: "Saint Michael the Archangel, defend us in battle. Be our protection against the wickedness and snares of the devil; May God rebuke him, we humbly pray; And do thou, O Prince of the Heavenly Host, by the power of God, thrust into hell Satan and all evil spirits who wander through the world for the ruin of souls. Amen.",
        isPopular: true
      },
      {
        name: "St. Rita of Cascia",
        title: "Patron of Impossible Causes",
        description: "Patron saint of impossible cases, abused wives and heartbroken women. Known for powerful intercession.",
        imageUrl: "https://images.unsplash.com/photo-1579975096649-e773152b04cb?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        feastDay: "May 22",
        patronOf: "Impossible Causes, Abused Women",
        born: "1381",
        died: "1457",
        prayer: "O Holy Patroness of those in need, St. Rita, whose pleadings before thy Divine Lord are almost irresistible, who for thy lavishness in granting favors hast been called the Advocate of the hopeless and even of the impossible; St. Rita, so humble, so pure, so mortified, so patient and of such compassionate love for thy Crucified Jesus that thou couldst obtain from Him whatsoever thou askest, on account of which all confidently have recourse to thee, expecting, if not always relief, at least comfort; be propitious to our petition, showing thy power with God on behalf of thy suppliant; be lavish to us, as thou hast been in so many wonderful cases, for the greater glory of God, for the spreading of thine own devotion, and for the consolation of those who trust in thee. Amen.",
        isPopular: true
      },
      {
        name: "St. Cajetan",
        title: "Patron of Job Seekers",
        description: "Patron saint of job seekers and the unemployed. Known for helping those in financial distress.",
        imageUrl: "https://images.unsplash.com/photo-1560252889-bccf66e1b9ac?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        feastDay: "August 7",
        patronOf: "Unemployed, Job Seekers",
        born: "1480",
        died: "1547",
        prayer: "O glorious St. Cajetan, you studied to be a lawyer, but when you felt that the Lord was calling you to his service, you abandoned everything and became a priest. You excelled in virtues, shunning all material rewards for your labor, helping the many unemployed people of your time. You provided loans without interest and you attracted many benefactors who donated to your cause. Look on us with mercy. We wish to find employment that could make use of our talents and education. We pray that you might help us find a suitable job that would sustain our livelihood. Amen.",
        isPopular: false
      },
      {
        name: "St. Homobonus",
        title: "Patron of Business People",
        description: "Patron saint of business people, tailors, and cloth workers. Known for fairness in business.",
        imageUrl: "https://images.unsplash.com/photo-1576517387659-558c1441ba31?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        feastDay: "November 13",
        patronOf: "Business People, Tailors",
        born: "12th Century",
        died: "1197",
        prayer: "O Saint Homobonus, you who were a businessman of integrity and honesty, help us to conduct our business affairs with the same level of fairness and charity that you showed in your lifetime. Help us to see that profit is not the only goal, but that we should also seek to benefit those with whom we deal and the communities in which we live and work. Obtain for us the virtues of prudence and justice in our dealings, so that we may honor God in our work as you did. We ask this through Christ our Lord. Amen.",
        isPopular: false
      },
      {
        name: "St. Gabriel",
        title: "Archangel",
        description: "Prayer for safe travel and guidance",
        imageUrl: "https://images.unsplash.com/photo-1555601568-c9e6f328489b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        feastDay: "September 29",
        patronOf: "Messengers, Postal Workers, Communications",
        born: "",
        died: "",
        prayer: "O Blessed Archangel Gabriel, we beseech thee, intercede for us at the throne of divine Mercy in our present necessities, that as thou didst announce to Mary the mystery of the Incarnation, so through thy prayers and patronage in heaven we may obtain the benefits of the same, and sing the praise of God forever in the land of the living. Amen.",
        isPopular: false
      }
    ];

    // Check if saints already exist
    const existingSaints = await db.query.saints.findMany();
    if (existingSaints.length === 0) {
      console.log("Seeding saints...");
      await db.insert(schema.saints).values(saints);
    }

    // Get IDs for categories and saints
    const allCategories = await db.query.categories.findMany();
    const allSaints = await db.query.saints.findMany();

    // Create a map for easier lookup
    const categoryMap = new Map(allCategories.map(c => [c.name, c.id]));
    const saintMap = new Map(allSaints.map(s => [s.name, s.id]));

    // Seed saint_categories relationships
    const saintCategories = [
      { saintId: saintMap.get("St. Joseph"), categoryId: categoryMap.get("Jobs") },
      { saintId: saintMap.get("St. Joseph"), categoryId: categoryMap.get("Family") },
      { saintId: saintMap.get("St. Jude Thaddeus"), categoryId: categoryMap.get("Impossible Causes") },
      { saintId: saintMap.get("St. Michael"), categoryId: categoryMap.get("Protection") },
      { saintId: saintMap.get("St. Rita of Cascia"), categoryId: categoryMap.get("Healing") },
      { saintId: saintMap.get("St. Rita of Cascia"), categoryId: categoryMap.get("Impossible Causes") },
      { saintId: saintMap.get("St. Cajetan"), categoryId: categoryMap.get("Jobs") },
      { saintId: saintMap.get("St. Homobonus"), categoryId: categoryMap.get("Jobs") },
      { saintId: saintMap.get("St. Gabriel"), categoryId: categoryMap.get("Journey Mercy") }
    ];

    // Check if saint_categories already exist
    const existingSaintCategories = await db.query.saintCategories.findMany();
    if (existingSaintCategories.length === 0) {
      console.log("Seeding saint categories relationships...");
      await db.insert(schema.saintCategories).values(saintCategories);
    }

    console.log("Seed completed successfully");
  } catch (error) {
    console.error("Error during seeding:", error);
  }
}

seed();

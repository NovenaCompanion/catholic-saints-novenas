import { ActiveNovena } from "./types";

// Generate a consistent user ID
export const getUserId = (): string => {
  let userId = localStorage.getItem("sanctus_user_id");
  if (!userId) {
    userId = `user_${Math.random().toString(36).substring(2, 15)}`;
    localStorage.setItem("sanctus_user_id", userId);
  }
  return userId;
};

// Set user ID in request headers
export const getHeaders = (): HeadersInit => {
  return {
    "Content-Type": "application/json",
    "X-User-ID": getUserId(),
  };
};

// Local storage backup for novenas in case user is offline
export const localNovenaStorage = {
  getStoredNovenas: (): ActiveNovena[] => {
    const novenas = localStorage.getItem("sanctus_novenas");
    return novenas ? JSON.parse(novenas) : [];
  },

  storeNovena: (novena: ActiveNovena): void => {
    const novenas = localNovenaStorage.getStoredNovenas();
    const existingIndex = novenas.findIndex(n => n.id === novena.id);
    
    if (existingIndex >= 0) {
      novenas[existingIndex] = novena;
    } else {
      novenas.push(novena);
    }
    
    localStorage.setItem("sanctus_novenas", JSON.stringify(novenas));
  },

  updateNovenaProgress: (novenaId: number, day: number): ActiveNovena | null => {
    const novenas = localNovenaStorage.getStoredNovenas();
    const novenaIndex = novenas.findIndex(n => n.id === novenaId);
    
    if (novenaIndex < 0) return null;
    
    const novena = novenas[novenaIndex];
    const completedDays = [...novena.completedDays];
    
    if (!completedDays.includes(day)) {
      completedDays.push(day);
    }
    
    // Use the novena's actual length (varies by saint)
    const novenaLength = 9; // Default to 9 days for local storage
    const nextDay = Math.max(...completedDays) + 1;
    const isComplete = nextDay > novenaLength;
    
    const updatedNovena = {
      ...novena,
      completedDays,
      currentDay: isComplete ? novenaLength : nextDay,
      isComplete
    };
    
    novenas[novenaIndex] = updatedNovena;
    localStorage.setItem("sanctus_novenas", JSON.stringify(novenas));
    
    return updatedNovena;
  },

  updateNovenaIntention: (novenaId: number, intention: string): ActiveNovena | null => {
    const novenas = localNovenaStorage.getStoredNovenas();
    const novenaIndex = novenas.findIndex(n => n.id === novenaId);
    
    if (novenaIndex < 0) return null;
    
    const updatedNovena = {
      ...novenas[novenaIndex],
      intention
    };
    
    novenas[novenaIndex] = updatedNovena;
    localStorage.setItem("sanctus_novenas", JSON.stringify(novenas));
    
    return updatedNovena;
  }
};

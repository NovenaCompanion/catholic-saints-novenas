import * as React from "react";
import { Capacitor } from "@capacitor/core";
import { AdMob, BannerAdOptions, BannerAdSize, BannerAdPosition } from "@capacitor-community/admob";

interface CrossPlatformBannerProps {
  position?: BannerAdPosition;
  size?: BannerAdSize;
  className?: string;
}

// Google AdSense Banner Component for Web/Desktop
function WebAdSenseBanner() {
  const adRef = React.useRef<HTMLDivElement>(null);
  const [adError, setAdError] = React.useState<string | null>(null);
  const [isAdSenseLoaded, setIsAdSenseLoaded] = React.useState(false);

  React.useEffect(() => {
    const loadAdSense = async () => {
      try {
        // Check if AdSense is already loaded
        if (typeof window !== 'undefined' && (window as any).adsbygoogle) {
          setIsAdSenseLoaded(true);
          ((window as any).adsbygoogle = (window as any).adsbygoogle || []).push({});
          return;
        }

        // Load AdSense script
        const script = document.createElement('script');
        script.async = true;
        script.src = 'https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js';
        script.crossOrigin = 'anonymous';
        script.setAttribute('data-ad-client', 'ca-pub-XXXXXXXXXXXXXXXXX'); // Replace with your AdSense publisher ID
        
        script.onload = () => {
          setIsAdSenseLoaded(true);
          if ((window as any).adsbygoogle) {
            ((window as any).adsbygoogle = (window as any).adsbygoogle || []).push({});
          }
        };

        script.onerror = () => {
          setAdError('Failed to load AdSense');
        };

        document.head.appendChild(script);
      } catch (error) {
        console.error('Failed to load AdSense ad:', error);
        setAdError('Failed to load advertisement');
      }
    };

    loadAdSense();
  }, []);

  if (adError) {
    return (
      <div className="bg-blue-50 border border-blue-200 p-3 text-center text-sm text-blue-600 rounded-lg">
        <i className="fas fa-info-circle mr-2"></i>
        Advertisement placeholder (AdSense integration ready)
      </div>
    );
  }

  return (
    <div className="w-full flex justify-center my-4">
      <ins 
        className="adsbygoogle block"
        style={{ display: 'block', textAlign: 'center' }}
        data-ad-client="ca-pub-XXXXXXXXXXXXXXXXX" // Replace with your AdSense publisher ID
        data-ad-slot="XXXXXXXXXX" // Replace with your ad slot ID
        data-ad-format="auto"
        data-full-width-responsive="true"

      />
    </div>
  );
}

// Mobile AdMob Banner Component
function MobileAdMobBanner({ position, size }: { position: BannerAdPosition, size: BannerAdSize }) {
  const [isAdLoaded, setIsAdLoaded] = React.useState(false);
  const [adError, setAdError] = React.useState<string | null>(null);

  React.useEffect(() => {
    const showBannerAd = async () => {
      try {
        // Initialize AdMob
        await AdMob.initialize({
          testingDevices: ['2077ef9a63d2b398840261c8221a0c9b'], // Add your test device ID
        });

        const options: BannerAdOptions = {
          adId: 'ca-app-pub-3940256099942544/6300978111', // Replace with your production ad unit ID
          adSize: size,
          position: position,
          margin: 0,
          isTesting: true, // Set to false in production
        };

        await AdMob.showBanner(options);
        setIsAdLoaded(true);
        setAdError(null);
      } catch (error) {
        console.error('Failed to show mobile banner ad:', error);
        setAdError('Failed to load mobile advertisement');
        setIsAdLoaded(false);
      }
    };

    showBannerAd();

    // Cleanup
    return () => {
      AdMob.hideBanner().catch(console.error);
    };
  }, [position, size]);

  if (adError) {
    return (
      <div className="bg-red-50 p-2 text-center text-xs text-red-600">
        {adError}
      </div>
    );
  }

  // Return spacer for native ad
  return <div className="h-16" />;
}

// Main Cross-Platform Banner Component
export function CrossPlatformBanner({ 
  position = BannerAdPosition.BOTTOM_CENTER, 
  size = BannerAdSize.ADAPTIVE_BANNER,
  className = "" 
}: CrossPlatformBannerProps) {
  
  // Desktop/Web - Use Google AdSense
  if (!Capacitor.isNativePlatform()) {
    return (
      <div className={`w-full ${className}`}>
        <WebAdSenseBanner />
      </div>
    );
  }

  // Mobile App - Use AdMob
  return (
    <div className={className}>
      <MobileAdMobBanner position={position} size={size} />
    </div>
  );
}

// Cross-Platform Interstitial Ad Hook
export function useCrossPlatformInterstitial() {
  const showInterstitial = React.useCallback(async () => {
    if (!Capacitor.isNativePlatform()) {
      // Web platform - could integrate with AdSense interstitials or show modal ads
      console.log('Web interstitial ad would show here');
      // You could implement a modal-based ad system for web here
      return;
    }

    // Mobile platform - use AdMob
    try {
      await AdMob.prepareInterstitial({
        adId: 'ca-app-pub-3940256099942544/1033173712', // Replace with your production interstitial ad unit ID
        isTesting: true, // Set to false in production
      });

      await AdMob.showInterstitial();
    } catch (error) {
      console.error('Failed to show mobile interstitial ad:', error);
    }
  }, []);

  return { showInterstitial };
}
import * as React from "react";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

interface TestimonialListProps {
  saintId: string;
  onAddTestimonial: () => void;
}

interface Testimonial {
  id: number;
  userId: string;
  saintId: number;
  title: string;
  content: string;
  favorsReceived: string;
  isApproved: boolean;
  createdAt: string;
}

export function TestimonialList({ saintId, onAddTestimonial }: TestimonialListProps) {
  // Fetch testimonials for this saint
  const { data: testimonials, isLoading } = useQuery({
    queryKey: [`/api/saints/${saintId}/testimonials`],
  });
  
  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="font-serif text-xl font-semibold">Testimonials</h2>
          <Button variant="outline" onClick={onAddTestimonial}>
            <i className="fas fa-plus mr-2"></i> Add Yours
          </Button>
        </div>
        <Skeleton className="h-24 w-full" />
        <Skeleton className="h-24 w-full" />
      </div>
    );
  }
  
  const typedTestimonials = testimonials as Testimonial[] || [];
  
  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="font-serif text-xl font-semibold">Testimonials</h2>
        <Button variant="outline" onClick={onAddTestimonial}>
          <i className="fas fa-plus mr-2"></i> Add Yours
        </Button>
      </div>
      
      {typedTestimonials.length === 0 ? (
        <Card className="bg-white p-5 text-center">
          <p className="text-slate-500 mb-3">No testimonials yet.</p>
          <p className="text-sm">Share your experience here after completing this novena or send your testimonies / correspondence privately to mynovena1@gmail.com (email) and +447380301720 (WhatsApp).</p>
        </Card>
      ) : (
        <div className="space-y-4">
          {typedTestimonials.map((testimonial) => (
            <Card key={testimonial.id} className="bg-white p-4">
              <h3 className="font-semibold text-lg mb-1">{testimonial.title}</h3>
              <p className="text-sm text-slate-500 mb-3">
                {new Date(testimonial.createdAt).toLocaleDateString()}
              </p>
              <p className="text-slate-700 mb-3">{testimonial.content}</p>
              <div className="bg-blue-50 p-3 rounded-md">
                <p className="text-sm font-medium text-blue-700 mb-1">Favors Received:</p>
                <p className="text-sm text-slate-700">{testimonial.favorsReceived}</p>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
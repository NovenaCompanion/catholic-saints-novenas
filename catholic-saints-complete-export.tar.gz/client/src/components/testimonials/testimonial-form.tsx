import * as React from "react";
import { useMutation } from "@tanstack/react-query";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";

interface TestimonialFormProps {
  saintId: string;
  saintName: string;
  isOpen: boolean;
  onClose: () => void;
}

const testimonialSchema = z.object({
  title: z.string().min(3, "Title must be at least 3 characters").max(100, "Title cannot exceed 100 characters"),
  content: z.string().min(10, "Please share more details about your experience"),
  favorsReceived: z.string().min(10, "Please describe the favors or miracles you received")
});

type TestimonialFormValues = z.infer<typeof testimonialSchema>;

export function TestimonialForm({ saintId, saintName, isOpen, onClose }: TestimonialFormProps) {
  const { toast } = useToast();
  
  const form = useForm<TestimonialFormValues>({
    resolver: zodResolver(testimonialSchema),
    defaultValues: {
      title: "",
      content: "",
      favorsReceived: ""
    }
  });
  
  const createTestimonial = useMutation({
    mutationFn: async (values: TestimonialFormValues) => {
      const response = await apiRequest("POST", `/api/saints/${saintId}/testimonials`, values);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/saints/${saintId}/testimonials`] });
      toast({
        title: "Testimonial Submitted",
        description: "Thank you for sharing your experience. Your testimonial will be reviewed before being published.",
      });
      form.reset();
      onClose();
    },
    onError: (error) => {
      toast({
        title: "Submission Failed",
        description: "There was an error submitting your testimonial. Please try again.",
        variant: "destructive",
      });
      console.error("Error submitting testimonial:", error);
    },
  });
  
  function onSubmit(values: TestimonialFormValues) {
    createTestimonial.mutate(values);
  }
  
  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="text-center">Share Your Experience with {saintName}</DialogTitle>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 mt-4">
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Title</FormLabel>
                  <FormControl>
                    <Input placeholder="E.g., My healing miracle" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="content"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Your Experience</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Please share your experience with this novena..." 
                      className="min-h-[100px]"
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="favorsReceived"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Favors or Miracles Received</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Describe the specific favors or miracles you received..." 
                      className="min-h-[100px]"
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="pt-4 text-sm text-slate-500">
              <p>Your testimonial will be reviewed before being published. Thank you for sharing your faith journey. You can also send your testimonies / correspondence privately to mynovena1@gmail.com (email) and +447380301720 (WhatsApp).</p>
            </div>
            
            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={onClose}
                disabled={createTestimonial.isPending}
              >
                Cancel
              </Button>
              <Button 
                type="submit"
                disabled={createTestimonial.isPending}
              >
                {createTestimonial.isPending ? "Submitting..." : "Submit Testimonial"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
import * as React from "react";
import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Heart, Users, Sparkles, ArrowRight } from "lucide-react";
import { CategoryWithCount } from "@/lib/types";

interface CategoryCardProps {
  category: CategoryWithCount;
}

export function CategoryCard({ category }: CategoryCardProps) {
  const [, navigate] = useLocation();

  const handleClick = () => {
    navigate(`/category/${category.id}`);
  };

  // Get category image from database
  const [categoryImage, setCategoryImage] = React.useState<string | null>(null);

  // Load image from database
  React.useEffect(() => {
    const loadImage = async () => {
      try {
        const response = await fetch('/api/images/category');
        if (response.ok) {
          const data = await response.json();
          setCategoryImage(data.url);
        }
      } catch (error) {
        console.error('Error loading category image:', error);
      }
    };

    loadImage();

    // Listen for image update events
    const handleImageChange = () => {
      loadImage();
    };

    window.addEventListener('categoryImageChanged', handleImageChange);

    return () => {
      window.removeEventListener('categoryImageChanged', handleImageChange);
    };
  }, []);

  // Sacred picture - use category image if available, otherwise default heart icon
  const getSacredPicture = () => {
    if (categoryImage && categoryImage.trim() !== "") {
      return (
        <img 
          src={categoryImage} 
          alt="Sacred Category Image" 
          className="w-full h-full object-cover rounded-lg"
        />
      );
    }
    return <Heart className="w-6 h-6 text-white drop-shadow-lg" />;
  };

  // Dynamic gradient colors based on category
  const gradientColors = {
    '54 Day Rosary Novena To The Blessed Virgin Mary': 'from-blue-500 to-indigo-600',
    'Family, Marriage & Children': 'from-rose-400 to-pink-600',
    'Healing & Medical Conditions': 'from-emerald-400 to-green-600',
    'Students, Education & Knowledge': 'from-blue-400 to-indigo-600',
    'Priests, Religious Life & Vocations': 'from-purple-500 to-violet-600',
    'Protection, Safety & Travelers': 'from-purple-400 to-violet-600',
    'Work, Employment & Business': 'from-amber-400 to-orange-600',
    'Impossible Causes & Desperate Situations': 'from-red-400 to-rose-600',
    'Mental Health, Peace & Emotional Healing': 'from-cyan-400 to-teal-600',
    'Purity, Virtue & Moral Strength': 'from-indigo-400 to-purple-600',
    'Youth & Young Adults': 'from-lime-400 to-green-500',
    'Women\'s Issues & Fertility': 'from-pink-400 to-rose-500',
    'Martyrs & Persecution': 'from-red-500 to-orange-600',
    'Social Justice & the Poor': 'from-emerald-500 to-teal-600',
    'Military, War & Veterans': 'from-slate-500 to-zinc-600',
    'Death, Dying & Souls in Purgatory': 'from-gray-500 to-slate-600',
    'Agriculture, Animals & Nature': 'from-green-500 to-emerald-600',
    'Arts, Music & Creative Expression': 'from-violet-400 to-purple-500',
    'Communication, Technology & Media': 'from-cyan-500 to-blue-600',
    'Addiction, Conversion & Spiritual Renewal': 'from-orange-400 to-red-500',
    'Special Devotions & Prayer': 'from-yellow-400 to-orange-500',
    'The Holy Rosary Of The Blessed Virgin Mary': 'from-blue-600 to-indigo-700',
    'Preparation for Total Consecration': 'from-indigo-600 to-purple-700',
    'default': 'from-blue-400 to-purple-600'
  };

  const gradientClass = gradientColors[category.name as keyof typeof gradientColors] || gradientColors.default;

  return (
    <Card 
      className="group bg-white/80 backdrop-blur-sm border-0 shadow-xl rounded-2xl overflow-hidden aspect-square cursor-pointer transform transition-all duration-500 hover:scale-105 hover:shadow-2xl"
      onClick={handleClick}
    >
      {/* Sacred background image with gradient overlay */}
      <div className="h-full w-full relative overflow-hidden"
           style={{
             backgroundImage: `url(/attached_assets/beaut_1751156925108.avif)`,
             backgroundSize: 'cover',
             backgroundPosition: 'center',
             backgroundRepeat: 'no-repeat'
           }}>
        {/* Gradient overlay for text readability */}
        <div className={`absolute inset-0 bg-gradient-to-br ${gradientClass} opacity-85`}></div>
        
        {/* Background pattern overlay */}
        <div className="absolute inset-0 bg-black/20 backdrop-blur-[1px]"></div>
        
        {/* Animated floating elements */}
        <div className="absolute top-2 right-2 w-8 h-8 bg-white/20 rounded-full animate-pulse"></div>
        <div className="absolute bottom-4 left-2 w-4 h-4 bg-white/10 rounded-full animate-bounce delay-300"></div>
        
        {/* Content container */}
        <div className="relative z-10 h-full flex flex-col items-center justify-center p-4 text-center">
          {/* Sacred picture as icon overlay */}
          <div className="mb-3 transform transition-transform duration-700 group-hover:scale-110">
            <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-lg border border-white/30 flex items-center justify-center shadow-lg overflow-hidden">
              {getSacredPicture()}
            </div>
          </div>
          
          {/* Category Title */}
          <h3 className="text-white font-bold text-sm mb-2 leading-tight drop-shadow-2xl">
            {category.name}
          </h3>
          
          {/* Saints Count Badge */}
          <Badge className="bg-white/25 backdrop-blur-md text-white border-white/40 px-3 py-1 rounded-full text-xs font-semibold shadow-lg">
            <Users className="w-3 h-3 mr-1" />
            {category.saintCount} Saints
          </Badge>
          
          {/* Hover indicator */}
          <div className="absolute bottom-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <ArrowRight className="w-4 h-4 text-white drop-shadow-lg" />
          </div>
        </div>
      </div>
    </Card>
  );
}
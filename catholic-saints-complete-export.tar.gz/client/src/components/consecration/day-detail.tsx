import * as React from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { NovenaResponse, NovenaPrayerResponse } from "@/lib/types";

interface DayDetailProps {
  day: number;
  novena: NovenaResponse;
  dailyPrayer: NovenaPrayerResponse | undefined;
  onComplete: () => void;
  isPending: boolean;
}

export function DayDetail({ day, novena, dailyPrayer, onComplete, isPending }: DayDetailProps) {
  // Extract the introduction part from the dailyPrayer content if it exists
  const extractIntroduction = (content: string | undefined): { introTitle: string, introText: string } => {
    if (!content) {
      return { introTitle: "", introText: "" };
    }
    
    const lines = content.split('\n\n');
    // Check if the content has the "Preparation for Total Consecration Part" format
    if (lines.length > 3 && lines[0].includes("Preparation for Total Consecration")) {
      // Find where the introduction text ends (before PRAYER: starts)
      let introEndIndex = 2;
      for (let i = 3; i < lines.length; i++) {
        if (lines[i].startsWith("PRAYER:")) {
          break;
        }
        introEndIndex = i;
      }
      
      // Combine all introduction paragraphs
      const introText = lines.slice(2, introEndIndex + 1).join('\n\n');
      
      return {
        introTitle: lines[0] + "\n" + lines[1],
        introText: introText
      };
    }
    return { introTitle: "", introText: "" };
  };
  
  // Get phase information based on day
  const getPhaseInfo = (day: number) => {
    // Try to extract introduction from dailyPrayer content
    const { introTitle, introText } = extractIntroduction(dailyPrayer?.content);
    
    if (day <= 12) {
      // Phase 1 Introduction data
      const phase1Data = {
        title: "Preparation for Total Consecration Part I",
        subtitle: "TWELVE PRELIMINARY DAYS: SPIRIT OF THE WORLD DAYS 1-12",
        heading: "Introduction to Part 1 (The First Twelve Preliminary Days)",
        description: "For the first twelve days\n\nExamine your conscience, pray, practice renouncement of your own will; mortification, purity of heart. This purity is the indispensable condition for contemplating God in heaven, to see Him on earth and to know Him by the light of faith.\n\nThe first part of the preparation should be employed in casting off the spirit of the world which is contrary to that of Jesus Christ. The spirit of the world consists essentially in the denial of the supreme dominion of God; a denial which is manifested in practice by sin and disobedience; thus it is principally opposed to the spirit of Christ, which is also that of Mary.\n\nIt manifests itself by the concupiscence of the flesh, by the concupiscence of the eyes and by the pride of life. By disobedience to God's laws and the abuse of created things. Its works are: sin in all forms, then all else by which the devil leads to sin; works which bring error and darkness to the mind, and seduction and corruption to the will. Its pomps are the splendor and the charms employed by the devil to render sin alluring in persons, places and things."
      };

      return {
        phase: introTitle || `${phase1Data.title}\n${phase1Data.subtitle}\n${phase1Data.heading}`,
        description: introText || phase1Data.description,
        scripture: {
          reference: "Matthew 7:13-14",
          text: "\"Enter through the narrow gate. For wide is the gate and broad is the road that leads to destruction, and many enter through it. But small is the gate and narrow the road that leads to life, and only a few find it.\"",
        },
      };
    } else if (day <= 19) {
      // If we have extracted an introduction, use it, otherwise use the default
      if (introTitle && introText) {
        return {
          phase: introTitle,
          description: introText,
          scripture: {
            reference: "Luke 18:13-14",
            text: "\"But the tax collector stood at a distance. He would not even look up to heaven, but beat his breast and said, 'God, have mercy on me, a sinner.' I tell you that this man, rather than the other, went home justified before God. For all those who exalt themselves will be humbled, and those who humble themselves will be exalted.\"",
          },
        };
      }
      
      return {
        phase: "Preparation for Total Consecration Part 2\nKNOWLEDGE OF SELF DAYS 13-19\nINTRODUCTION TO PART II",
        description: "Prayers, examens, reflection, acts of renouncement of our own will, of contrition for our sins, of contempt of self—all performed at the feet of Mary, for it is from her that we hope for light to know ourselves. It is near her, that we shall be able to measure the abyss of our miseries without despairing.\n\nWe should employ all our pious actions in asking for a knowledge of ourselves and contrition of our sins: and we should do this in a spirit of piety. During this period, we shall consider not so much the opposition that exists between the spirit of Jesus and ours, as the miserable and humiliating state to which our sins have reduced us.\n\nMoreover, the True Devotion being an easy, short, sure and perfect way to arrive at that union with our Lord, which is Christlike perfection, we shall enter seriously upon this way, strongly convinced of our misery and helplessness. But, how attain this without a knowledge of ourselves?",
        scripture: {
          reference: "Luke 18:13-14",
          text: "\"But the tax collector stood at a distance. He would not even look up to heaven, but beat his breast and said, 'God, have mercy on me, a sinner.' I tell you that this man, rather than the other, went home justified before God. For all those who exalt themselves will be humbled, and those who humble themselves will be exalted.\"",
        },
      };
    } else if (day <= 26) {
      // If we have extracted an introduction, use it, otherwise use the default
      if (introTitle && introText) {
        return {
          phase: introTitle,
          description: introText,
          scripture: {
            reference: "Luke 1:46-49",
            text: "\"And Mary said: 'My soul glorifies the Lord and my spirit rejoices in God my Savior, for he has been mindful of the humble state of his servant. From now on all generations will call me blessed, for the Mighty One has done great things for me— holy is his name.'\"",
          },
        };
      }
      
      return {
        phase: "Preparation for Total Consecration Part 3\nKNOWLEDGE OF THE BLESSED VIRGIN DAYS 20-26\nIntroduction to Part 3 (Knowledge Of The Blessed Virgin)",
        description: "Acts of love, pious affection for the Blessed Virgin, imitation of her virtues, especially her profound humility, her lively faith, her blind obedience, her continual mental prayer, her mortification in all things, her surpassing purity, her ardent charity, her heroic patience, her angelic sweetness, and her divine wisdom: \"there being,\" as St. Louis De Montfort says, \"the ten principal virtues of the Blessed Virgin.\"\n\nWe must unite ourselves to Jesus through Mary – this is the characteristic of our devotion; therefore, Saint Louis De Montfort asks that we employ ourselves in acquiring a knowledge of the Blessed Virgin. Mary is our sovereign and our mediatrix, our Mother and our Mistress. Let us then endeavor to know the effects of this royalty, of this mediation, and of this maternity, as well as the grandeurs and prerogatives which are the foundation or consequences thereof.\n\nOur Mother is also a perfect mold wherein we are to be molded in order to make her intentions and dispositions ours. This we cannot achieve without studying the interior life of Mary; namely, her virtues, her sentiments, her actions, her participation in the mysteries of Christ and her union with Him.",
        scripture: {
          reference: "Luke 1:46-49",
          text: "\"And Mary said: 'My soul glorifies the Lord and my spirit rejoices in God my Savior, for he has been mindful of the humble state of his servant. From now on all generations will call me blessed, for the Mighty One has done great things for me— holy is his name.'\"",
        },
      };
    } else {
      // If we have extracted an introduction, use it, otherwise use the default
      if (introTitle && introText) {
        return {
          phase: introTitle,
          description: introText,
          scripture: {
            reference: "John 15:4-5",
            text: "\"Remain in me, as I also remain in you. No branch can bear fruit by itself; it must remain in the vine. Neither can you bear fruit unless you remain in me. I am the vine; you are the branches. If you remain in me and I in you, you will bear much fruit; apart from me you can do nothing.\"",
          },
        };
      }
      
      return {
        phase: "Preparation for Total Consecration Part 4\nKNOWLEDGE OF JESUS CHRIST DAYS 27-33\nIntroduction to Part 4 (Knowledge Of Jesus Christ)",
        description: "During this period we shall apply ourselves to the study of Jesus Christ. What is to be studied in Christ? First the God-Man, His grace and glory; then His rights to sovereign dominion over us; since, after having renounced Satan and the world, we have taken Jesus Christ for our Lord. What next shall be the object of our study? His exterior actions and also His interior life; namely, the virtues and acts of His Sacred Heart; His association with Mary in the mysteries of the Annunciation and Incarnation, during His infancy and hidden life, at the feast of Cana and on Calvary.",
        scripture: {
          reference: "John 15:4-5",
          text: "\"Remain in me, as I also remain in you. No branch can bear fruit by itself; it must remain in the vine. Neither can you bear fruit unless you remain in me. I am the vine; you are the branches. If you remain in me and I in you, you will bear much fruit; apart from me you can do nothing.\"",
        },
      };
    }
  };

  const phaseInfo = getPhaseInfo(day);
  const typedNovena = novena as NovenaResponse;
  const isCurrentDay = day === typedNovena.currentDay;
  const isCompleted = typedNovena.completedDays.includes(day);

  return (
    <Card className="bg-white rounded-lg shadow-md p-5">
      <div className="flex items-center justify-between mb-5 border-b pb-3">
        <h3 className="font-serif text-xl font-semibold">Day {day}</h3>
        {isCurrentDay && isCompleted && (
          <span className="bg-green-100 text-green-700 text-sm font-medium px-3 py-1 rounded-full flex items-center">
            <i className="fas fa-check-circle mr-1"></i> Completed
          </span>
        )}
      </div>
      
      {/* INTRODUCTION TO PART */}
      <Accordion type="single" collapsible className="mb-6">
        <AccordionItem value="introduction" className="border rounded-lg bg-blue-50">
          <AccordionTrigger className="px-4 py-3">
            <h4 className="font-serif text-lg font-semibold text-blue-800 flex items-center">
              <i className="fas fa-book-reader mr-2"></i> {
                day <= 12 
                  ? "Introduction to Part 1 (The First Twelve Preliminary Days)" 
                  : day <= 19 
                    ? "Introduction to Part 2 (Knowledge Of Self)"
                    : day <= 26
                      ? "Introduction to Part 3 (Knowledge Of The Blessed Virgin)"
                      : "Introduction to Part 4 (Knowledge Of Jesus Christ)"
              }
            </h4>
          </AccordionTrigger>
          <AccordionContent className="px-4 pb-4">
            <div className="prose prose-blue max-w-none">
              {phaseInfo.description.split('\n\n').map((paragraph: string, index: number) => (
                <p key={index} className="text-blue-700 mb-3">{paragraph}</p>
              ))}
            </div>
            
            {/* Include the scripture passage here */}
            <div className="mt-4 p-3 bg-white/50 rounded border border-blue-100">
              <h5 className="font-medium mb-2 text-blue-800">{phaseInfo.scripture.reference}</h5>
              <p className="italic mb-2 text-blue-700">{phaseInfo.scripture.text}</p>
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>

      {/* Scripture reading is now integrated into the Introduction section */}
      
      {/* Daily Reading Content */}
      {dailyPrayer && dailyPrayer.content ? (
        <Accordion type="single" collapsible className="mb-6">
          <AccordionItem value="daily-reading" className="border rounded-lg">
            <AccordionTrigger className="px-4 py-3">
              <h4 className="font-serif text-lg font-semibold text-primary flex items-center">
                <i className="fas fa-book mr-2"></i> Daily Reading
                {dailyPrayer.title && (
                  <span className="ml-2 text-sm font-normal text-slate-600">({dailyPrayer.title})</span>
                )}
              </h4>
            </AccordionTrigger>
            <AccordionContent className="px-4 pb-4">
              <div className="prose prose-slate">
                {(() => {
                  const content = dailyPrayer.content;
                  const paragraphs = content.split('\n\n');
                  
                  // Extract sections
                  const prayerIndex = paragraphs.findIndex(p => 
                    p.toUpperCase().startsWith("PRAYER:"));
                  const readingIndex = paragraphs.findIndex(p => 
                    p.toUpperCase().startsWith("READING:"));
                  
                  // Show the complete reading section
                  return (
                    <div>
                      {readingIndex !== -1 ? (
                        <div className="border-l-4 border-primary/30 pl-4 py-2 my-4 bg-slate-50/50">
                          {(() => {
                            // Find the end of the reading section (before REFLECTION:)
                            const reflectionIndex = paragraphs.findIndex(p => 
                              p.toUpperCase().startsWith("REFLECTION:"));
                            const endIndex = reflectionIndex !== -1 ? reflectionIndex : paragraphs.length;
                            
                            // Display all paragraphs from reading to reflection
                            return paragraphs.slice(readingIndex, endIndex).map((paragraph: string, index: number) => {
                              const cleanedParagraph = index === 0 
                                ? paragraph.replace("READING:", "").trim()
                                : paragraph;
                              return (
                                <p key={index} className="mb-3 whitespace-pre-line">{cleanedParagraph}</p>
                              );
                            });
                          })()}
                        </div>
                      ) : (
                        // If no specific reading section found, display all content normally
                        <div>
                          {paragraphs.map((paragraph: string, index: number) => (
                            <p key={index} className="mb-3">{paragraph}</p>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })()}
              </div>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      ) : (
        <div className="text-center py-4 mb-6 bg-slate-50 rounded-lg">
          <i className="fas fa-book text-3xl text-slate-300 mb-3"></i>
          <p className="text-slate-600">No specific reading content for Day {day} yet.</p>
        </div>
      )}
      
      {/* Daily Prayer (Accordion/Dropdown) */}
      <Accordion type="single" collapsible className="mb-6">
        <AccordionItem value="prayer" className="border rounded-lg">
          <AccordionTrigger className="px-4 py-3">
            <h4 className="font-serif text-lg font-semibold text-primary flex items-center">
              <i className="fas fa-pray mr-2"></i> Daily Prayer
            </h4>
          </AccordionTrigger>
          <AccordionContent className="px-4 pt-2 pb-4 bg-gradient-to-br from-blue-50 to-purple-50">
            {dailyPrayer?.content ? (
              <div className="space-y-4">
                {(() => {
                  const paragraphs = dailyPrayer.content.split('\n\n');
                  
                  // Find different prayer sections
                  const prayerSectionIndex = paragraphs.findIndex(p => 
                    p.toUpperCase().startsWith("PRAYER:"));
                  const consecrationPrayerIndex = paragraphs.findIndex(p => 
                    p.toUpperCase().includes("CONSECRATION PRAYER"));
                  const dailyPracticeIndex = paragraphs.findIndex(p => 
                    p.toUpperCase().startsWith("DAILY PRACTICE"));
                  const traditionalPrayersIndex = paragraphs.findIndex(p => 
                    p.toUpperCase().startsWith("TRADITIONAL PRAYERS"));
                  
                  return (
                    <div className="space-y-6">
                      {/* Opening Prayer (Come, O Holy Spirit) */}
                      {prayerSectionIndex !== -1 && (
                        <div className="bg-white p-4 rounded-lg border border-blue-200 shadow-sm">
                          <h5 className="font-semibold text-blue-800 mb-3 flex items-center">
                            <i className="fas fa-dove mr-2"></i> Opening Prayer
                          </h5>
                          <div className="text-blue-900 leading-relaxed italic">
                            {(() => {
                              // Get the prayer content - starts at prayerSectionIndex and continues until next section
                              let prayerParagraphs = [];
                              let currentIndex = prayerSectionIndex;
                              
                              // Find where the prayer section ends (before READING)
                              while (currentIndex < paragraphs.length) {
                                const paragraph = paragraphs[currentIndex];
                                if (currentIndex > prayerSectionIndex && 
                                    (paragraph.toUpperCase().startsWith("READING:") || 
                                     paragraph.toUpperCase().startsWith("REFLECTION:") ||
                                     paragraph.toUpperCase().startsWith("DAILY PRACTICE:"))) {
                                  break;
                                }
                                prayerParagraphs.push(paragraph);
                                currentIndex++;
                              }
                              
                              // Combine all prayer paragraphs
                              let fullPrayerText = prayerParagraphs.join('\n\n');
                              
                              // Remove the PRAYER: prefix
                              if (fullPrayerText.toUpperCase().startsWith("PRAYER: VENI CREATOR")) {
                                fullPrayerText = fullPrayerText.replace(/PRAYER:\s*Veni Creator\s*/i, "Veni Creator\n\n");
                              } else if (fullPrayerText.toUpperCase().startsWith("PRAYER:")) {
                                fullPrayerText = fullPrayerText.replace("PRAYER:", "").trim();
                              }
                              
                              const lines = fullPrayerText.split('\n').filter(line => line.trim() !== '');
                              
                              // Check if this is the Veni Creator
                              const isVeniCreator = lines.some(line => line.includes("Come, Holy Spirit, Creator blest"));
                              
                              if (isVeniCreator && lines.length > 10) {
                                // Show title and first verse (approximately first 6 non-empty lines)
                                const previewLines = lines.slice(0, 6);
                                
                                return (
                                  <div>
                                    <div className="mb-3">
                                      {previewLines.map((line: string, index: number) => (
                                        <p key={index} className="mb-2">{line}</p>
                                      ))}
                                    </div>
                                    
                                    <Accordion type="single" collapsible className="mt-3">
                                      <AccordionItem value="full-prayer" className="border-none">
                                        <AccordionTrigger className="text-sm text-blue-700 hover:text-blue-900 py-2 px-0">
                                          <span className="flex items-center">
                                            <i className="fas fa-chevron-down mr-2 text-xs"></i>
                                            View Full Prayer
                                          </span>
                                        </AccordionTrigger>
                                        <AccordionContent className="pt-2">
                                          <div className="text-blue-900 leading-relaxed italic">
                                            {lines.slice(6).map((line: string, index: number) => (
                                              <p key={index + 6} className="mb-2">{line}</p>
                                            ))}
                                          </div>
                                        </AccordionContent>
                                      </AccordionItem>
                                    </Accordion>
                                  </div>
                                );
                              } else {
                                // For shorter prayers, show full text
                                return lines.map((line: string, index: number) => (
                                  <p key={index} className="mb-2">{line}</p>
                                ));
                              }
                            })()}
                          </div>
                        </div>
                      )}
                      
                      {/* Daily Practice */}
                      {dailyPracticeIndex !== -1 && (
                        <div className="bg-white p-4 rounded-lg border border-green-200 shadow-sm">
                          <h5 className="font-semibold text-green-800 mb-3 flex items-center">
                            <i className="fas fa-heart mr-2"></i> Daily Practice
                          </h5>
                          <div className="text-green-900 leading-relaxed">
                            {(() => {
                              const practiceText = paragraphs[dailyPracticeIndex].replace("DAILY PRACTICE:", "").trim();
                              return practiceText.split('\n').map((line: string, index: number) => (
                                <p key={index} className="mb-2">{line}</p>
                              ));
                            })()}
                          </div>
                        </div>
                      )}
                      
                      {/* Traditional Prayers */}
                      {traditionalPrayersIndex !== -1 && (
                        <div className="bg-white p-4 rounded-lg border border-amber-200 shadow-sm">
                          <h5 className="font-semibold text-amber-800 mb-3 flex items-center">
                            <i className="fas fa-book-open mr-2"></i> Traditional Prayers for {
                              day <= 12 
                                ? "the Preparatory Days"
                                : day <= 19 
                                  ? "Knowledge of Self"
                                  : day <= 26
                                    ? "Knowledge of the Blessed Virgin"
                                    : day <= 33
                                      ? "Knowledge of Jesus Christ"
                                      : "the Preparatory Days"
                            }
                          </h5>
                          <div className="text-amber-900 leading-relaxed">
                            {(() => {
                              // Get all paragraphs from traditional prayers section until consecration prayer
                              let traditionalPrayersParagraphs = [];
                              let currentIndex = traditionalPrayersIndex;
                              
                              while (currentIndex < paragraphs.length) {
                                const paragraph = paragraphs[currentIndex];
                                if (currentIndex > traditionalPrayersIndex && 
                                    paragraph.toUpperCase().includes("CONSECRATION PRAYER")) {
                                  break;
                                }
                                traditionalPrayersParagraphs.push(paragraph);
                                currentIndex++;
                              }
                              
                              // Combine and display all traditional prayers
                              const fullTraditionalPrayers = traditionalPrayersParagraphs.join('\n\n');
                              const cleanedText = fullTraditionalPrayers.replace("TRADITIONAL PRAYERS FOR THE PREPARATORY DAYS", "").trim();
                              
                              return (
                                <Accordion type="single" collapsible className="w-full">
                                  <AccordionItem value="traditional-prayers" className="border-none">
                                    <AccordionTrigger className="text-sm text-amber-700 hover:text-amber-900 py-2 px-0">
                                      <span className="flex items-center">
                                        <i className="fas fa-chevron-down mr-2 text-xs"></i>
                                        {day <= 12 
                                          ? "View All Traditional Prayers (Veni Creator, Ave Maris Stella, Magnificat, Glory Be)"
                                          : day <= 19 
                                            ? "View All Traditional Prayers (Litany of the Holy Ghost, Litany of the Blessed Virgin Mary, Ave Maris Stella)"
                                            : day <= 26
                                              ? "View All Traditional Prayers (Litany of the Holy Ghost, Litany of the Blessed Virgin Mary, Ave Maris Stella, St. Louis De Montfort's Prayer)"
                                              : day <= 33
                                                ? "View All Traditional Prayers (Litany of the Holy Ghost, Ave Maris Stella, Litany of the Holy Name of Jesus, St. Louis De Montfort's Prayer to Jesus)"
                                                : "View All Traditional Prayers"
                                        }
                                      </span>
                                    </AccordionTrigger>
                                    <AccordionContent className="pt-4">
                                      <div className="prose prose-amber max-w-none">
                                        {cleanedText.split('\n\n').map((paragraph, index) => {
                                          if (paragraph.trim() === '') return null;
                                          
                                          // Check if this is a prayer title
                                          const isPrayerTitle = paragraph.match(/^(Veni Creator|Ave Maris Stella|Magnificat|Glory Be)$/);
                                          
                                          if (isPrayerTitle) {
                                            return (
                                              <h6 key={index} className="font-bold text-amber-800 text-lg mt-6 mb-3 first:mt-0">
                                                {paragraph}
                                              </h6>
                                            );
                                          }
                                          
                                          return (
                                            <div key={index} className="mb-4 italic">
                                              {paragraph.split('\n').map((line, lineIndex) => (
                                                <p key={lineIndex} className="mb-1 leading-relaxed">
                                                  {line}
                                                </p>
                                              ))}
                                            </div>
                                          );
                                        }).filter(Boolean)}
                                      </div>
                                    </AccordionContent>
                                  </AccordionItem>
                                </Accordion>
                              );
                            })()}
                          </div>
                        </div>
                      )}
                      
                      {/* Consecration Prayer */}
                      {consecrationPrayerIndex !== -1 ? (
                        <div className="bg-white p-4 rounded-lg border border-purple-200 shadow-sm">
                          <h5 className="font-semibold text-purple-800 mb-3 flex items-center">
                            <i className="fas fa-crown mr-2"></i> Consecration Prayer
                          </h5>
                          <div className="text-purple-900 leading-relaxed font-medium" data-prayer-content>
                            {(() => {
                              const fullPrayerText = paragraphs[consecrationPrayerIndex];
                              const prayerText = fullPrayerText.includes("CONSECRATION PRAYER:") 
                                ? fullPrayerText.replace("CONSECRATION PRAYER:", "").trim()
                                : fullPrayerText;
                              
                              return prayerText.split('\n').map((line: string, index: number) => {
                                if (line.trim() === "") return null;
                                return (
                                  <p key={index} className="mb-3 text-center">{line}</p>
                                );
                              }).filter(Boolean);
                            })()}
                          </div>
                        </div>
                      ) : (
                        <div className="bg-white p-4 rounded-lg border border-purple-200 shadow-sm">
                          <h5 className="font-semibold text-purple-800 mb-3 flex items-center">
                            <i className="fas fa-crown mr-2"></i> Daily Prayer
                          </h5>
                          <div className="text-purple-900 leading-relaxed font-medium" data-prayer-content>
                            {paragraphs.slice(-1)[0].split('\n').map((line: string, index: number) => {
                              if (line.trim() === "") return null;
                              return (
                                <p key={index} className="mb-3 text-center">{line}</p>
                              );
                            }).filter(Boolean)}
                          </div>
                        </div>
                      )}
                      
                      {/* Prayer Actions */}
                      <div className="flex flex-wrap gap-2 justify-center pt-2">
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="text-xs bg-white hover:bg-blue-50"
                          onClick={() => {
                            const prayerContent = document.querySelector('[data-prayer-content]');
                            if (prayerContent && 'speechSynthesis' in window) {
                              const text = prayerContent.textContent || '';
                              const utterance = new SpeechSynthesisUtterance(text);
                              utterance.rate = 0.8;
                              speechSynthesis.speak(utterance);
                            }
                          }}
                        >
                          <i className="fas fa-volume-up mr-1"></i> Listen
                        </Button>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="text-xs bg-white hover:bg-green-50"
                          onClick={() => {
                            const prayerContent = document.querySelector('[data-prayer-content]');
                            if (prayerContent) {
                              navigator.clipboard.writeText(prayerContent.textContent || '');
                            }
                          }}
                        >
                          <i className="fas fa-copy mr-1"></i> Copy
                        </Button>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="text-xs bg-white hover:bg-purple-50"
                          onClick={() => {
                            if (navigator.share) {
                              const prayerContent = document.querySelector('[data-prayer-content]');
                              navigator.share({
                                title: `Day ${day} - Total Consecration Prayer`,
                                text: prayerContent?.textContent || ''
                              });
                            }
                          }}
                        >
                          <i className="fas fa-share mr-1"></i> Share
                        </Button>
                      </div>
                    </div>
                  );
                })()}
              </div>
            ) : novena.saint?.prayer ? (
              <div className="bg-white p-4 rounded-lg border border-purple-200 shadow-sm">
                <h5 className="font-semibold text-purple-800 mb-3 flex items-center">
                  <i className="fas fa-crown mr-2"></i> Default Prayer
                </h5>
                <div className="text-purple-900 leading-relaxed font-medium" data-prayer-content>
                  {novena.saint.prayer.split('\n\n').map((paragraph: string, index: number) => (
                    <p key={index} className="mb-3 text-center">{paragraph}</p>
                  ))}
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <i className="fas fa-pray text-4xl text-slate-300 mb-3"></i>
                <p className="text-slate-600">No prayer content available for this day.</p>
              </div>
            )}
          </AccordionContent>
        </AccordionItem>
      </Accordion>
      
      {/* Audio Reflection */}
      <Accordion type="single" collapsible className="mb-6">
        <AccordionItem value="audio-reflection" className="border rounded-lg">
          <AccordionTrigger className="px-4 py-3">
            <h4 className="font-serif text-lg font-semibold text-primary flex items-center">
              <i className="fas fa-headphones mr-2"></i> Audio Reflection
            </h4>
          </AccordionTrigger>
          <AccordionContent className="px-4 pb-4">
            <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 text-center">
              <p className="text-slate-600 mb-3">Listen to today's reflection for deeper spiritual insight</p>
              <div className="flex justify-center items-center space-x-3">
                <Button variant="outline" className="rounded-full h-12 w-12 flex items-center justify-center">
                  <i className="fas fa-play"></i>
                </Button>
                <div className="h-2 bg-slate-200 flex-grow rounded-full">
                  <div className="h-full w-0 bg-primary rounded-full"></div>
                </div>
                <span className="text-sm text-slate-500">0:00</span>
              </div>
              <p className="text-xs text-slate-500 mt-4">
                <i className="fas fa-info-circle mr-1"></i> Audio reflections will be available in a future update
              </p>
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
      
      {/* Mark Complete Button (only for current day and if not already completed) */}
      {isCurrentDay && !typedNovena.isComplete && !isCompleted && (
        <button 
          className="w-full bg-primary text-white font-semibold py-3 rounded-lg flex items-center justify-center disabled:opacity-70 mt-4"
          onClick={onComplete}
          disabled={isPending}
        >
          <i className="fas fa-check mr-2"></i> 
          {isPending 
            ? "Updating..." 
            : `Mark Day ${day} Complete`
          }
        </button>
      )}
    </Card>
  );
}
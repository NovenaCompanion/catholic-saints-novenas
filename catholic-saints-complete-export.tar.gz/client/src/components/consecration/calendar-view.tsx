import * as React from "react";
import { format, addDays } from "date-fns";
import { Card } from "@/components/ui/card";
import { NovenaResponse } from "@/lib/types";

interface CalendarDayProps {
  day: number;
  date: Date;
  status: "completed" | "current" | "pending";
  isSelected: boolean;
  onClick: () => void;
}

interface CalendarViewProps {
  novena: NovenaResponse;
  selectedDay: number;
  onSelectDay?: (day: number) => void;
  onDayClick?: (day: number) => void;
}

// Individual day component
const CalendarDay = ({ day, date, status, isSelected, onClick }: CalendarDayProps) => {
  let bgGradient = "bg-gradient-to-br from-white to-slate-50";
  let textColor = "text-slate-700";
  let borderColor = "border-slate-200";
  let dayBadgeColor = "bg-slate-100 text-slate-700";
  let shadow = "shadow-sm";
  
  if (status === "completed") {
    bgGradient = "bg-gradient-to-br from-emerald-50 to-green-100";
    textColor = "text-emerald-800";
    borderColor = "border-emerald-300";
    dayBadgeColor = "bg-emerald-500 text-white";
    shadow = "shadow-md";
  } else if (status === "current") {
    bgGradient = "bg-gradient-to-br from-blue-50 to-indigo-100";
    textColor = "text-blue-800";
    borderColor = "border-blue-400";
    dayBadgeColor = "bg-blue-500 text-white";
    shadow = "shadow-lg ring-2 ring-blue-300 ring-opacity-50";
  }
  
  if (isSelected) {
    borderColor = "border-indigo-500 border-2";
    shadow = "shadow-xl ring-4 ring-indigo-200 ring-opacity-50";
  }
  
  return (
    <button
      onClick={onClick}
      className={`${bgGradient} ${textColor} border ${borderColor} ${shadow} rounded-xl p-3 flex flex-col items-center transition-all duration-300 hover:scale-105 hover:shadow-lg transform ${isSelected ? 'scale-105' : ''} relative overflow-hidden`}
    >
      {/* Day Badge - Most Prominent with Full Text */}
      <div className={`${dayBadgeColor} rounded-full w-16 h-16 flex flex-col items-center justify-center text-xs font-bold mb-2 shadow-sm`}>
        <span className="text-[10px] leading-none">Day</span>
        <span className="text-lg leading-none">{day}</span>
      </div>
      
      {/* Calendar Date - Secondary */}
      <div className="text-center">
        <span className="text-xs font-medium opacity-75">{format(date, "MMM")}</span>
        <span className="text-lg font-semibold block">{format(date, "d")}</span>
      </div>
      
      {/* Status Icon */}
      <div className="mt-2">
        {status === "completed" && (
          <div className="bg-emerald-500 rounded-full w-5 h-5 flex items-center justify-center">
            <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
            </svg>
          </div>
        )}
        {status === "current" && (
          <div className="bg-blue-500 rounded-full w-5 h-5 flex items-center justify-center animate-pulse">
            <div className="bg-white rounded-full w-2 h-2"></div>
          </div>
        )}
        {status === "pending" && (
          <div className="bg-slate-300 rounded-full w-5 h-5 flex items-center justify-center">
            <div className="bg-slate-500 rounded-full w-2 h-2"></div>
          </div>
        )}
      </div>
      
      {/* Subtle background pattern for visual interest */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-1 right-1 w-2 h-2 bg-current rounded-full"></div>
        <div className="absolute bottom-1 left-1 w-1 h-1 bg-current rounded-full"></div>
      </div>
    </button>
  );
};

// Calendar group for a specific phase
const CalendarPhase = ({ 
  title, 
  subtitle, 
  days, 
  novena, 
  selectedDay, 
  onSelectDay,
  onDayClick,
  phaseNumber
}: { 
  title: string; 
  subtitle: string;
  days: { day: number; date: Date }[];
  novena: NovenaResponse;
  selectedDay: number;
  onSelectDay?: (day: number) => void;
  onDayClick?: (day: number) => void;
  phaseNumber: number;
}) => {
  // Determine phase colors
  const phaseColors = {
    1: { bg: "bg-gradient-to-r from-red-50 to-red-100", border: "border-red-200", accent: "text-red-700", badge: "bg-red-500" },
    2: { bg: "bg-gradient-to-r from-amber-50 to-yellow-100", border: "border-amber-200", accent: "text-amber-700", badge: "bg-amber-500" },
    3: { bg: "bg-gradient-to-r from-blue-50 to-blue-100", border: "border-blue-200", accent: "text-blue-700", badge: "bg-blue-500" },
    4: { bg: "bg-gradient-to-r from-purple-50 to-purple-100", border: "border-purple-200", accent: "text-purple-700", badge: "bg-purple-500" }
  };
  
  const colors = phaseColors[phaseNumber as keyof typeof phaseColors] || phaseColors[1];
  
  // Calculate phase progress
  const completedInPhase = days.filter(({ day }) => novena.completedDays.includes(day)).length;
  const progressPercent = (completedInPhase / days.length) * 100;
  
  return (
    <div className={`mb-8 rounded-2xl ${colors.bg} ${colors.border} border-2 p-6 shadow-lg`}>
      {/* Phase Header */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-2">
            <div className={`${colors.badge} text-white rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold shadow-md`}>
              {phaseNumber}
            </div>
            <h3 className={`font-serif text-xl font-bold ${colors.accent}`}>{title}</h3>
          </div>
          <p className="text-sm text-slate-600 leading-relaxed">{subtitle}</p>
        </div>
        
        {/* Phase Progress Indicator */}
        <div className="ml-4 text-right">
          <div className={`text-xs font-medium ${colors.accent} mb-1`}>
            {completedInPhase}/{days.length} Days
          </div>
          <div className="w-16 h-2 bg-white rounded-full overflow-hidden shadow-inner">
            <div 
              className={`h-full ${colors.badge} transition-all duration-500 ease-out`}
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>
      </div>
      
      {/* Days Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-7 gap-3">
        {days.map(({ day, date }) => (
          <CalendarDay
            key={day}
            day={day}
            date={date}
            status={
              novena.completedDays.includes(day) 
                ? "completed" 
                : day === novena.currentDay 
                  ? "current" 
                  : "pending"
            }
            isSelected={selectedDay === day}
            onClick={() => {
              if (onDayClick) {
                onDayClick(day);
              } else if (onSelectDay) {
                onSelectDay(day);
              }
            }}
          />
        ))}
      </div>
    </div>
  );
};

// Main calendar component
export function CalendarView({ novena, selectedDay, onSelectDay, onDayClick }: CalendarViewProps) {
  // Generate calendar dates
  const generateCalendarDates = () => {
    if (!novena) return { phase1: [], phase2: [], phase3: [], phase4: [] };
    
    const startDate = new Date(novena.startDate);
    const allDates = Array.from({ length: 33 }, (_, i) => ({
      day: i + 1,
      date: addDays(startDate, i)
    }));
    
    // Divide into the four preparation phases of the consecration
    return {
      phase1: allDates.slice(0, 12),  // 12 days - emptying oneself of the spirit of the world
      phase2: allDates.slice(12, 19), // 7 days - knowledge of self 
      phase3: allDates.slice(19, 26), // 7 days - knowledge of Mary
      phase4: allDates.slice(26, 33)  // 7 days - knowledge of Christ
    };
  };
  
  const { phase1, phase2, phase3, phase4 } = generateCalendarDates();
  
  // Calculate overall progress
  const totalCompleted = novena.completedDays.length;
  const overallProgress = (totalCompleted / 33) * 100;
  
  return (
    <div className="mb-6">
      {/* Calendar Header */}
      <Card className="bg-gradient-to-r from-indigo-600 to-purple-700 text-white rounded-2xl shadow-xl p-6 mb-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="font-serif text-2xl font-bold mb-2">33-Day Consecration Journey</h2>
            <p className="text-indigo-100 text-sm">Following St. Louis de Montfort's True Devotion to Mary</p>
          </div>
          
          {/* Overall Progress */}
          <div className="text-right">
            <div className="text-3xl font-bold mb-1">{totalCompleted}/33</div>
            <div className="text-xs text-indigo-200 mb-2">Days Completed</div>
            <div className="w-24 h-3 bg-indigo-800 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-yellow-300 to-yellow-500 transition-all duration-700 ease-out"
                style={{ width: `${overallProgress}%` }}
              />
            </div>
          </div>
        </div>
      </Card>
      
      {/* Phase Sections */}
      <div className="space-y-6">
        <CalendarPhase
          title="Emptying Oneself of the Spirit of the World"
          subtitle="Days 1-12: Recognize and renounce worldly attachments through prayer and reflection"
          days={phase1}
          novena={novena}
          selectedDay={selectedDay}
          onSelectDay={onSelectDay}
          onDayClick={onDayClick}
          phaseNumber={1}
        />
        
        <CalendarPhase
          title="Knowledge of Self and Contrition"
          subtitle="Days 13-19: Examine your conscience, focus on humility, and seek true contrition"
          days={phase2}
          novena={novena}
          selectedDay={selectedDay}
          onSelectDay={onSelectDay}
          onDayClick={onDayClick}
          phaseNumber={2}
        />
        
        <CalendarPhase
          title="Knowledge of the Blessed Virgin Mary"
          subtitle="Days 20-26: Learn about Mary's virtues, her role in salvation, and her maternal love"
          days={phase3}
          novena={novena}
          selectedDay={selectedDay}
          onSelectDay={onSelectDay}
          onDayClick={onDayClick}
          phaseNumber={3}
        />
        
        <CalendarPhase
          title="Knowledge of Jesus Christ"
          subtitle="Days 27-33: Deepen your relationship with Jesus through Mary's guidance and intercession"
          days={phase4}
          novena={novena}
          selectedDay={selectedDay}
          onSelectDay={onSelectDay}
          onDayClick={onDayClick}
          phaseNumber={4}
        />
      </div>
    </div>
  );
}
import * as React from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { SaintResponse, CategoryResponse, ActiveNovena } from "@/lib/types";

interface HeaderProps {
  onSearch?: (query: string) => void;
}

export function Header({ onSearch }: HeaderProps) {
  const [isSearchOpen, setIsSearchOpen] = React.useState(false);
  const [searchQuery, setSearchQuery] = React.useState("");
  const [searchResults, setSearchResults] = React.useState<{
    saints: SaintResponse[];
    categories: CategoryResponse[];
    devotions: { name: string; route: string }[];
  }>({
    saints: [],
    categories: [],
    devotions: []
  });
  const [showResults, setShowResults] = React.useState(false);
  const [, navigate] = useLocation();
  const searchInputRef = React.useRef<HTMLInputElement>(null);
  
  // Admin authentication state
  const [isAdmin, setIsAdmin] = React.useState(false);
  const [showAdminLogin, setShowAdminLogin] = React.useState(false);
  const [adminPassword, setAdminPassword] = React.useState("");
  const { toast } = useToast();

  // Fetch data for global search
  const { data: saints = [] } = useQuery<SaintResponse[]>({
    queryKey: ["/api/saints"],
  });

  const { data: categories = [] } = useQuery<CategoryResponse[]>({
    queryKey: ["/api/categories"],
  });

  // Define special devotions
  const specialDevotions = [
    { name: "33-Day Total Consecration", route: "/consecration-home" },
    { name: "54-Day Rosary Novena", route: "/rosary-novena-home" },
    { name: "Daily Holy Rosary", route: "/holy-rosary-home" },
    { name: "My Novenas", route: "/my-novenas" },
    { name: "Testimonials", route: "/testimonials" },
    { name: "Settings", route: "/settings" }
  ];
  
  // Header customization
  const [headerSettings, setHeaderSettings] = React.useState({
    headerImage: "",
    startColor: "#4338ca", // Indigo-700
    endColor: "#7e22ce", // Purple-700
    logoSrc: "/images/cross-icon.svg"
  });
  
  // Load settings from localStorage and database on mount and listen for changes
  React.useEffect(() => {
    const loadSettings = async () => {
      // Load non-image settings from localStorage
      const savedSettings = localStorage.getItem("headerSettings");
      let baseSettings = {
        startColor: "#4338ca",
        endColor: "#7e22ce",
        logoSrc: "/images/cross-icon.svg"
      };
      
      if (savedSettings) {
        try {
          const parsedSettings = JSON.parse(savedSettings);
          baseSettings = {
            startColor: parsedSettings.startColor || "#4338ca",
            endColor: parsedSettings.endColor || "#7e22ce",
            logoSrc: parsedSettings.logoSrc || "/images/cross-icon.svg"
          };
        } catch (error) {
          console.error("Error parsing saved header settings:", error);
        }
      }

      // Load header image from database
      let headerImage = "";
      try {
        const response = await fetch('/api/images/header');
        if (response.ok) {
          const data = await response.json();
          headerImage = data.url;
        }
      } catch (error) {
        console.error('Error loading header image:', error);
      }

      setHeaderSettings({
        ...baseSettings,
        headerImage
      });
    };

    // Load initial settings
    loadSettings();

    // Listen for storage changes from other tabs/windows
    const handleStorageChange = (event: StorageEvent) => {
      if (event.key === "headerSettings") {
        loadSettings();
      }
    };

    // Listen for custom events from Settings page
    const handleHeaderSettingsChange = () => {
      loadSettings();
    };

    window.addEventListener('storage', handleStorageChange);
    window.addEventListener('headerSettingsChanged', handleHeaderSettingsChange);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('headerSettingsChanged', handleHeaderSettingsChange);
    };
  }, []);

  // Check for existing admin session on component mount
  React.useEffect(() => {
    const adminSession = sessionStorage.getItem('adminAuthenticated');
    if (adminSession === 'true') {
      setIsAdmin(true);
    }
  }, []);

  // Admin authentication functions
  const handleAdminLogin = async () => {
    try {
      const response = await fetch('/api/admin/authenticate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ password: adminPassword }),
      });

      if (response.ok) {
        setIsAdmin(true);
        setShowAdminLogin(false);
        setAdminPassword("");
        sessionStorage.setItem('adminAuthenticated', 'true');
        toast({
          title: "Admin Access Granted",
          description: "You now have admin privileges.",
        });
        navigate("/admin");
      } else {
        toast({
          title: "Authentication Failed",
          description: "Invalid admin password. Please try again.",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Admin login error:', error);
      toast({
        title: "Login Error",
        description: "Unable to authenticate. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleAdminLogout = () => {
    setIsAdmin(false);
    sessionStorage.removeItem('adminAuthenticated');
    toast({
      title: "Admin Logout",
      description: "You have been logged out of admin mode.",
    });
  };

  const handleAdminIconClick = () => {
    console.log('Admin icon clicked, isAdmin:', isAdmin);
    console.log('Session storage adminAuthenticated:', sessionStorage.getItem('adminAuthenticated'));
    if (isAdmin) {
      console.log('Navigating to admin dashboard...');
      // Try direct navigation
      window.location.href = '/admin';
    } else {
      console.log('Showing admin login...');
      setShowAdminLogin(true);
    }
  };

  // Focus search input when opened
  React.useEffect(() => {
    if (isSearchOpen && searchInputRef.current) {
      searchInputRef.current.focus();
    }
  }, [isSearchOpen]);

  const toggleSearch = () => {
    setIsSearchOpen(!isSearchOpen);
    if (isSearchOpen) {
      setSearchQuery("");
    }
  };

  // Global search function
  const performGlobalSearch = (query: string) => {
    if (!query.trim()) {
      setSearchResults({ saints: [], categories: [], devotions: [] });
      setShowResults(false);
      return;
    }

    const lowercaseQuery = query.toLowerCase();

    // Search saints
    const matchingSaints = saints.filter(saint =>
      saint.name.toLowerCase().includes(lowercaseQuery) ||
      saint.description.toLowerCase().includes(lowercaseQuery)
    ).slice(0, 5); // Limit to 5 results

    // Search categories
    const matchingCategories = categories.filter(category =>
      category.name.toLowerCase().includes(lowercaseQuery) ||
      (category.description && category.description.toLowerCase().includes(lowercaseQuery))
    ).slice(0, 3); // Limit to 3 results

    // Search devotions
    const matchingDevotions = specialDevotions.filter(devotion =>
      devotion.name.toLowerCase().includes(lowercaseQuery)
    );

    setSearchResults({
      saints: matchingSaints,
      categories: matchingCategories,
      devotions: matchingDevotions
    });
    setShowResults(true);
  };

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setSearchQuery(value);
    
    // Call local search if provided (for page-specific search)
    if (onSearch) {
      onSearch(value);
    }
    
    // Perform global search
    performGlobalSearch(value);
  };

  const clearSearch = () => {
    setSearchQuery("");
    setSearchResults({ saints: [], categories: [], devotions: [] });
    setShowResults(false);
    if (onSearch) {
      onSearch("");
    }
    if (searchInputRef.current) {
      searchInputRef.current.focus();
    }
  };

  // Fetch user's active novenas for smart navigation
  const { data: userNovenas = [] } = useQuery<ActiveNovena[]>({
    queryKey: ["/api/novenas"],
  });

  // Navigate to search result with direct navigation
  const navigateToResult = (type: 'saint' | 'category' | 'devotion', id?: number, route?: string) => {
    console.log('=== NAVIGATION TRIGGERED ===');
    console.log('Type:', type, 'ID:', id, 'Route:', route);
    
    // Close search immediately
    setIsSearchOpen(false);
    setSearchQuery("");
    setSearchResults({ saints: [], categories: [], devotions: [] });
    setShowResults(false);

    // Use a timeout to ensure state updates complete
    setTimeout(() => {
      if (type === 'saint' && id) {
        console.log('Navigating to saint:', id);
        
        // Special cases first
        if (id === 9) {
          console.log('Going to Rosary Novena Home');
          window.location.href = '/rosary-novena-home';
        } else if (id === 10) {
          console.log('Going to Consecration Home');
          window.location.href = '/consecration-home';
        } else {
          console.log('Going to saint detail:', id);
          window.location.href = `/saint/${id}`;
        }
      } else if (type === 'category' && id) {
        console.log('Going to category:', id);
        window.location.href = `/category/${id}`;
      } else if (type === 'devotion' && route) {
        console.log('Going to devotion:', route);
        window.location.href = route;
      }
    }, 100);
  };
  
  // Close search on ESC key
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape') {
      setIsSearchOpen(false);
      setSearchQuery("");
      setSearchResults({ saints: [], categories: [], devotions: [] });
      setShowResults(false);
      if (onSearch) {
        onSearch("");
      }
    }
  };

  // Close results when clicking outside
  React.useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchInputRef.current && !searchInputRef.current.contains(event.target as Node)) {
        setShowResults(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);
  
  // Generate header style based on settings
  const headerStyle = {
    backgroundImage: headerSettings.headerImage 
      ? `linear-gradient(to right, rgba(67, 56, 202, 0.85), rgba(126, 34, 206, 0.85)), url(${headerSettings.headerImage})`
      : `linear-gradient(to right, ${headerSettings.startColor}, ${headerSettings.endColor})`,
    backgroundSize: "cover",
    backgroundPosition: "center",
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-10 shadow-soft-lg transition-all duration-300" style={headerStyle}>
      {/* Main header content */}
      <div className="container mx-auto px-4 py-3.5 flex justify-between items-center">
        {/* Logo and title area */}
        <div className="flex items-center group">
          {/* Animated logo with glow effect */}
          <div 
            className="w-10 h-10 flex items-center justify-center bg-white bg-opacity-20 rounded-full mr-3 transition-all duration-300 hover:scale-110 hover:bg-opacity-30 hover:rotate-3 group-hover:glow"
            onClick={() => navigate("/")}
          >
            <img 
              src={headerSettings.logoSrc} 
              alt="App Logo" 
              className="w-6 h-6 transition-transform duration-500 group-hover:rotate-12"
            />
          </div>
          
          {/* App title with decorative elements */}
          <div className="flex flex-col">
            <h1 
              className="text-white font-serif text-xl font-bold cursor-pointer hover:text-opacity-90 transition-colors duration-200 group-hover:scale-105 origin-left transform" 
              onClick={() => navigate("/")}
            >
              <span className="relative">
                My Novena Companion
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-white bg-opacity-50 group-hover:w-full transition-all duration-300"></span>
              </span>
            </h1>
            
            {/* Optional tagline */}
            <span className="text-white text-opacity-80 text-xs font-light hidden md:block">
              Your daily prayer journey
            </span>
          </div>
        </div>
        
        {/* Action buttons with improved hover effects */}
        <div className="flex items-center">
          {/* Search component (collapsible) */}
          <div className="relative flex items-center">
            {/* Collapsible search input */}
            <div 
              className={`
                overflow-visible transition-all duration-300 mr-2 relative
                ${isSearchOpen ? 'w-40 sm:w-64 opacity-100' : 'w-0 opacity-0'}
              `}
            >
              {isSearchOpen && (
                <div className="relative">
                  <div className="relative bg-white bg-opacity-20 rounded-full">
                    <Input
                      ref={searchInputRef}
                      type="text"
                      placeholder="Search saints, categories..."
                      value={searchQuery}
                      onChange={handleSearchChange}
                      onKeyDown={handleKeyDown}
                      className="w-full pl-3 pr-8 py-1.5 text-white placeholder-white placeholder-opacity-70 bg-transparent border-none focus:ring-1 focus:ring-white focus:ring-opacity-50"
                    />
                    
                    {/* Clear button */}
                    {searchQuery && (
                      <button
                        className="absolute right-2 top-1/2 -translate-y-1/2 text-white text-opacity-80 hover:text-opacity-100 p-0.5"
                        onClick={clearSearch}
                        aria-label="Clear search"
                      >
                        <i className="fas fa-times text-sm"></i>
                      </button>
                    )}
                  </div>

                  {/* Search Results Dropdown */}
                  {showResults && searchQuery && (
                    <div 
                      className="absolute top-full left-0 right-0 mt-2 bg-white rounded-lg shadow-xl border border-gray-200 max-h-96 overflow-y-auto z-[9999]"
                      style={{ zIndex: 9999 }}
                      onMouseDown={(e) => e.preventDefault()}
                    >
                      {/* Saints Results */}
                      {searchResults.saints.length > 0 && (
                        <div className="p-2">
                          <div className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2 px-2">
                            Saints ({searchResults.saints.length})
                          </div>
                          {searchResults.saints.map((saint) => (
                            <div
                              key={saint.id}
                              onMouseDown={(e) => {
                                console.log('=== MOUSEDOWN NAVIGATION ===');
                                console.log('Saint clicked:', saint.id, saint.name);
                                e.preventDefault();
                                e.stopPropagation();
                                navigateToResult('saint', saint.id);
                              }}
                              className="w-full text-left p-2 hover:bg-gray-50 rounded-md transition-colors duration-150 flex items-center space-x-3 cursor-pointer"
                              style={{ 
                                backgroundColor: 'rgba(0, 255, 0, 0.1)',
                                border: '1px solid green',
                                position: 'relative',
                                zIndex: 10000
                              }}
                            >
                              <div className="flex-shrink-0 w-8 h-8 bg-indigo-100 rounded-full flex items-center justify-center">
                                <i className="fas fa-user-circle text-indigo-600 text-sm"></i>
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="text-sm font-medium text-gray-900 truncate">
                                  {saint.name}
                                </div>
                                <div className="text-xs text-gray-500 truncate">
                                  {saint.description}
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}

                      {/* Categories Results */}
                      {searchResults.categories.length > 0 && (
                        <div className="p-2 border-t border-gray-100">
                          <div className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2 px-2">
                            Categories ({searchResults.categories.length})
                          </div>
                          {searchResults.categories.map((category) => (
                            <button
                              key={category.id}
                              onClick={(e) => {
                                e.preventDefault();
                                e.stopPropagation();
                                console.log('Category button clicked:', category.id, category.name);
                                navigateToResult('category', category.id);
                              }}
                              className="w-full text-left p-2 hover:bg-gray-50 rounded-md transition-colors duration-150 flex items-center space-x-3"
                            >
                              <div className="flex-shrink-0 w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                                <i className="fas fa-layer-group text-purple-600 text-sm"></i>
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="text-sm font-medium text-gray-900 truncate">
                                  {category.name}
                                </div>
                                {category.description && (
                                  <div className="text-xs text-gray-500 truncate">
                                    {category.description}
                                  </div>
                                )}
                              </div>
                            </button>
                          ))}
                        </div>
                      )}

                      {/* Devotions Results */}
                      {searchResults.devotions.length > 0 && (
                        <div className="p-2 border-t border-gray-100">
                          <div className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2 px-2">
                            Devotions ({searchResults.devotions.length})
                          </div>
                          {searchResults.devotions.map((devotion, index) => (
                            <button
                              key={index}
                              onClick={(e) => {
                                e.preventDefault();
                                e.stopPropagation();
                                console.log('Devotion button clicked:', devotion.name, devotion.route);
                                navigateToResult('devotion', undefined, devotion.route);
                              }}
                              className="w-full text-left p-2 hover:bg-gray-50 rounded-md transition-colors duration-150 flex items-center space-x-3"
                            >
                              <div className="flex-shrink-0 w-8 h-8 bg-amber-100 rounded-full flex items-center justify-center">
                                <i className="fas fa-rosary text-amber-600 text-sm"></i>
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="text-sm font-medium text-gray-900 truncate">
                                  {devotion.name}
                                </div>
                              </div>
                            </button>
                          ))}
                        </div>
                      )}

                      {/* No Results */}
                      {searchResults.saints.length === 0 && 
                       searchResults.categories.length === 0 && 
                       searchResults.devotions.length === 0 && (
                        <div className="p-4 text-center text-gray-500">
                          <i className="fas fa-search text-2xl mb-2 block text-gray-400"></i>
                          <div className="text-sm">No results found for "{searchQuery}"</div>
                          <div className="text-xs text-gray-400 mt-1">
                            Try searching for saints, categories, or devotions
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
            
            {/* Search button */}
            <button 
              className={`text-white p-2.5 rounded-full transition-all duration-200
                ${isSearchOpen 
                  ? 'bg-white bg-opacity-30 shadow-sm' 
                  : 'hover:bg-white hover:bg-opacity-20'}`
              }
              onClick={toggleSearch}
              aria-label={isSearchOpen ? "Close search" : "Open search"}
            >
              <i className={`fas ${isSearchOpen ? 'fa-times' : 'fa-search'}`}></i>
            </button>
          </div>
          
          {/* Regular Settings button - visible to all users */}
          <button 
            className="relative text-white p-2.5 hover:bg-white hover:bg-opacity-20 rounded-full transition-all duration-200 overflow-hidden ml-2" 
            aria-label="Settings"
            onClick={() => navigate("/settings")}
          >
            <i className="fas fa-sliders-h transform transition-transform hover:scale-110 duration-300"></i>
            
            {/* Subtle animation effect */}
            <span className="absolute inset-0 rounded-full bg-white bg-opacity-0 hover:bg-opacity-10 transition-all duration-300"></span>
          </button>

          {/* Admin button - only visible to authenticated admins */}
          {isAdmin && (
            <button 
              className="relative text-white p-2.5 hover:bg-white hover:bg-opacity-20 rounded-full transition-all duration-200 overflow-hidden ml-2" 
              aria-label="Admin Dashboard"
              onMouseDown={handleAdminIconClick}
            >
              <i className="fas fa-cog transform transition-transform hover:rotate-45 duration-300"></i>
              
              {/* Subtle animation effect */}
              <span className="absolute inset-0 rounded-full bg-white bg-opacity-0 hover:bg-opacity-10 transition-all duration-300"></span>
            </button>
          )}

          {/* Admin login button for non-authenticated users who know admin exists */}
          {!isAdmin && (
            <button 
              className="relative text-white p-2.5 hover:bg-white hover:bg-opacity-20 rounded-full transition-all duration-200 overflow-hidden ml-2 opacity-30 hover:opacity-100" 
              aria-label="Admin Login"
              onMouseDown={handleAdminIconClick}
              title="Admin Access"
            >
              <i className="fas fa-unlock transform transition-transform hover:scale-110 duration-300"></i>
              
              {/* Subtle animation effect */}
              <span className="absolute inset-0 rounded-full bg-white bg-opacity-0 hover:bg-opacity-10 transition-all duration-300"></span>
            </button>
          )}
        </div>
      </div>
      
      {/* Decorative bottom border with gradient */}
      <div className="h-0.5 bg-gradient-to-r from-white/0 via-white/30 to-white/0"></div>

      {/* Admin Login Dialog */}
      <Dialog open={showAdminLogin} onOpenChange={setShowAdminLogin}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <i className="fas fa-shield-alt mr-2 text-blue-600"></i>
              Admin Authentication
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <Label htmlFor="admin-password">Admin Password</Label>
              <Input
                id="admin-password"
                type="password"
                value={adminPassword}
                onChange={(e) => setAdminPassword(e.target.value)}
                placeholder="Enter admin password"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    handleAdminLogin();
                  }
                }}
                className="mt-1"
              />
            </div>
            
            <div className="flex justify-end space-x-2">
              <Button
                variant="outline"
                onClick={() => {
                  setShowAdminLogin(false);
                  setAdminPassword("");
                }}
              >
                Cancel
              </Button>
              <Button onClick={handleAdminLogin} disabled={!adminPassword.trim()}>
                <i className="fas fa-sign-in-alt mr-2"></i>
                Login
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </header>
  );
}

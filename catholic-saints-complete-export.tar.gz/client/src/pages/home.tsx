import * as React from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Header } from "@/components/layout/header";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { SaintCard } from "@/components/saints/saint-card";
import { NovenaCard } from "@/components/saints/novena-card";
import { CategoryCard } from "@/components/saints/category-card";
import { DailyNovenaReminder } from "@/components/reminders/daily-novena-reminder";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Heart, BookOpen, ArrowRight, Sparkles, Crown, Users } from "lucide-react";
import { CategoryResponse, SaintResponse, NovenaResponse, CategoryWithCount, ActiveNovena } from "@/lib/types";

export default function Home() {
  const [location, navigate] = useLocation();
  const [filteredPopularSaints, setFilteredPopularSaints] = React.useState<SaintResponse[]>([]);
  const [showReminder, setShowReminder] = React.useState(true);
  


  // Fetch categories
  const { data: categories, isLoading: loadingCategories } = useQuery<CategoryResponse[]>({
    queryKey: ["/api/categories"],
  });

  // Fetch popular saints
  const { data: popularSaints, isLoading: loadingPopularSaints } = useQuery<SaintResponse[]>({
    queryKey: ["/api/saints/popular"],
  });

  // Fetch user's active novenas
  const { data: novenas, isLoading: loadingNovenas } = useQuery<NovenaResponse[]>({
    queryKey: ["/api/novenas"],
  });

  // Search functionality
  const handleSearch = (query: string) => {
    if (!popularSaints) return;
    
    if (!query) {
      setFilteredPopularSaints(popularSaints);
      return;
    }
    
    const lowercaseQuery = query.toLowerCase();
    const filtered = popularSaints.filter((saint: SaintResponse) => 
      saint.name.toLowerCase().includes(lowercaseQuery) || 
      saint.description.toLowerCase().includes(lowercaseQuery)
    );
    
    setFilteredPopularSaints(filtered);
  };

  // Set filtered saints when data is loaded
  React.useEffect(() => {
    if (popularSaints) {
      setFilteredPopularSaints(popularSaints);
    }
  }, [popularSaints]);

  // Fetch all saints (needed for category counts)
  const { data: allSaints } = useQuery<SaintResponse[]>({
    queryKey: ['/api/saints'],
  });
  
  // Categories already include saint counts from the API
  const categoriesWithCount = React.useMemo(() => {
    if (!categories) return [];
    
    return categories.map((category: CategoryResponse) => {
      console.log(`Category ${category.name} has ${category.saintCount} saints`);
      return {
        ...category,
        saintCount: category.saintCount || 0
      } as CategoryWithCount;
    });
  }, [categories]);

  // Process novenas to include saint information
  const activeNovenas = React.useMemo(() => {
    if (!novenas) return [];
    
    return novenas.map((novena: NovenaResponse) => {
      return {
        id: novena.id,
        saintId: novena.saintId,
        saintName: novena.saint?.name || "Unknown Saint",
        saintImageUrl: novena.saint?.imageUrl || null,
        categoryName: "Prayer", // This would come from the API in a real implementation
        startDate: novena.startDate,
        currentDay: novena.currentDay,
        completedDays: novena.completedDays,
        intention: novena.intention,
        isComplete: novena.isComplete,
      } as ActiveNovena;
    });
  }, [novenas]);

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <Header onSearch={handleSearch} />

      <main className="flex-grow mt-14 mb-16">
        <div className="container mx-auto px-4 py-6">
          {/* Enhanced Consecration Banner */}
          <section className="mb-8">
            <Card 
              className="bg-white/80 backdrop-blur-sm border-0 shadow-xl rounded-2xl overflow-hidden cursor-pointer transform transition-all duration-300 hover:scale-102 hover:shadow-2xl"
              onClick={() => navigate("/consecration-home")}
            >
              <div className="bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 text-white p-6 relative overflow-hidden">
                {/* Animated background elements */}
                <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-16 translate-x-16 animate-pulse"></div>
                <div className="absolute bottom-0 left-0 w-20 h-20 bg-white/5 rounded-full translate-y-10 -translate-x-10 animate-bounce delay-700"></div>
                
                <div className="relative z-10 flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center">
                        <Crown className="w-6 h-6 text-white" />
                      </div>
                      <Badge className="bg-white/20 backdrop-blur-md text-white border-white/30 px-3 py-1 rounded-full">
                        33 Days Journey
                      </Badge>
                    </div>
                    
                    <h2 className="text-2xl font-bold mb-2 drop-shadow-lg">
                      Total Consecration to Jesus through Mary
                    </h2>
                    <p className="text-white/90 mb-4 leading-relaxed">
                      Begin your sacred 33-day preparation journey following St. Louis de Montfort's authentic spiritual method
                    </p>
                    
                    <Button className="bg-white/20 backdrop-blur-md hover:bg-white/30 text-white border-white/30 rounded-xl font-semibold">
                      <Heart className="w-4 h-4 mr-2" />
                      Begin Sacred Journey
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </div>
                  
                  <div className="hidden md:flex items-center justify-center w-24 h-24 bg-white/10 backdrop-blur-md rounded-full">
                    <Sparkles className="w-12 h-12 text-white animate-pulse" />
                  </div>
                </div>
              </div>
            </Card>
          </section>
          
          {/* Daily Novena Reminder */}
          {showReminder && (
            <section className="mb-6">
              <DailyNovenaReminder onDismiss={() => setShowReminder(false)} />
            </section>
          )}
          
          {/* Enhanced My Novenas Section */}
          <section className="mb-8">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  My Spiritual Journey
                </h2>
                <div className="h-1 w-16 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full mt-1"></div>
              </div>
              <Button 
                variant="ghost"
                onClick={() => navigate("/novenas")}
                className="text-blue-600 hover:text-blue-700 font-medium rounded-xl"
              >
                View All
                <ArrowRight className="w-4 h-4 ml-1" />
              </Button>
            </div>
            
            <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl rounded-2xl overflow-hidden cursor-pointer transform transition-all duration-300 hover:scale-102 hover:shadow-2xl" onClick={() => navigate("/novenas")}>
              <div className="bg-gradient-to-r from-emerald-100 to-teal-100 p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-2xl flex items-center justify-center shadow-lg">
                      <BookOpen className="w-8 h-8 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-slate-800 mb-1">My Novena Journey</h3>
                      <p className="text-slate-600">Track progress and start new prayers</p>
                    </div>
                  </div>
                  
                  <Badge className="bg-gradient-to-r from-emerald-500 to-teal-500 text-white border-0 px-4 py-2 rounded-full font-semibold shadow-lg">
                    <Users className="w-4 h-4 mr-2" />
                    Active Prayers
                  </Badge>
                </div>


                
                <p className="text-slate-600 leading-relaxed text-center mb-4">
                  Manage your active novenas, view completion progress, and discover new saints for your spiritual practice.
                </p>
                
                <div className="text-center">
                  <Button className="bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white rounded-xl font-semibold shadow-lg">
                    <Heart className="w-4 h-4 mr-2" />
                    Explore My Novenas
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </div>
              </div>
            </Card>
          </section>

          {/* Enhanced Categories Section */}
          <section className="mb-8">
            <div className="mb-6">
              <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-2">
                Sacred Categories
              </h2>
              <div className="h-1 w-20 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full"></div>
              <p className="text-slate-600 mt-3 leading-relaxed">
                Discover saints organized by spiritual focus and divine intercession
              </p>
            </div>
            
            {loadingCategories ? (
              <div className="flex flex-col items-center justify-center py-16">
                <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center mb-4 animate-pulse">
                  <Sparkles className="w-8 h-8 text-white" />
                </div>
                <p className="text-slate-600 text-lg font-medium">Loading sacred categories...</p>
                <p className="text-slate-400 text-sm mt-1">Preparing your spiritual journey</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {categoriesWithCount.map((category: any) => (
                  <CategoryCard key={category.id} category={category} />
                ))}
              </div>
            )}
          </section>

          {/* Enhanced Popular Saints Section */}
          <section>
            <div className="mb-6">
              <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-2">
                Beloved Saints
              </h2>
              <div className="h-1 w-16 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full"></div>
              <p className="text-slate-600 mt-3 leading-relaxed">
                Begin your novena journey with these cherished saints loved by the faithful worldwide
              </p>
            </div>
            
            {loadingPopularSaints ? (
              <div className="flex flex-col items-center justify-center py-16">
                <div className="w-16 h-16 bg-gradient-to-r from-rose-500 to-pink-500 rounded-full flex items-center justify-center mb-4 animate-pulse">
                  <Heart className="w-8 h-8 text-white" />
                </div>
                <p className="text-slate-600 text-lg font-medium">Discovering beloved saints...</p>
                <p className="text-slate-400 text-sm mt-1">Preparing inspiring novena selections</p>
              </div>
            ) : filteredPopularSaints.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredPopularSaints.map((saint: SaintResponse) => (
                  <SaintCard key={saint.id} saint={saint} />
                ))}
              </div>
            ) : (
              <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl rounded-2xl p-12 text-center">
                <div className="flex flex-col items-center">
                  <div className="w-20 h-20 bg-gradient-to-r from-slate-200 to-slate-300 rounded-full flex items-center justify-center mb-6">
                    <Heart className="w-10 h-10 text-slate-500" />
                  </div>
                  <h3 className="text-2xl font-bold text-slate-800 mb-3">No Saints Found</h3>
                  <p className="text-slate-600 text-lg leading-relaxed max-w-md">
                    We couldn't find any saints matching your search. Try exploring different categories or adjusting your search terms.
                  </p>
                </div>
              </Card>
            )}
          </section>
        </div>
      </main>

      <BottomNavigation />
    </div>
  );
}

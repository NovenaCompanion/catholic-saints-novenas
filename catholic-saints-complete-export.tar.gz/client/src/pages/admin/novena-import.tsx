import * as React from "react";
import { useLocation } from "wouter";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Header } from "@/components/layout/header";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { SaintResponse } from "@/lib/types";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Separator } from "@/components/ui/separator";

export default function NovenaImport() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  
  // Form state
  const [url, setUrl] = React.useState("");
  const [selectedSaintId, setSelectedSaintId] = React.useState<string>("");
  const [previewContent, setPreviewContent] = React.useState<string>("");
  const [isLoading, setIsLoading] = React.useState(false);
  const [extractedPrayers, setExtractedPrayers] = React.useState<{day: number, title: string | null, content: string}[]>([]);
  
  // Fetch all saints
  const { data: saints } = useQuery({
    queryKey: ["/api/saints"],
  });
  
  // Preview novena content from URL
  const previewNovena = async () => {
    if (!url) {
      toast({
        title: "Missing URL",
        description: "Please enter a URL to a novena resource.",
        variant: "destructive",
      });
      return;
    }
    
    try {
      setIsLoading(true);
      const response = await apiRequest(
        "POST",
        "/api/utils/preview-novena",
        { url }
      );
      
      const data = await response.json();
      setPreviewContent(data.content || "No content could be extracted from this URL.");
      setIsLoading(false);
    } catch (error) {
      console.error("Error previewing novena:", error);
      toast({
        title: "Preview Failed",
        description: "Could not load preview from the provided URL. Make sure it's a valid website.",
        variant: "destructive",
      });
      setIsLoading(false);
    }
  };
  
  // Extract daily prayers from content
  const extractPrayers = async () => {
    if (!previewContent) {
      toast({
        title: "No Content",
        description: "Please load preview content first.",
        variant: "destructive",
      });
      return;
    }
    
    try {
      setIsLoading(true);
      const response = await apiRequest(
        "POST",
        "/api/utils/extract-prayers",
        { content: previewContent }
      );
      
      const data = await response.json();
      if (data.prayers && data.prayers.length > 0) {
        setExtractedPrayers(data.prayers);
        toast({
          title: "Prayers Extracted",
          description: `Successfully extracted ${data.prayers.length} days of prayers.`,
        });
      } else {
        toast({
          title: "Extraction Failed",
          description: "Could not automatically extract daily prayers. Try editing the content manually.",
          variant: "destructive",
        });
      }
      setIsLoading(false);
    } catch (error) {
      console.error("Error extracting prayers:", error);
      toast({
        title: "Extraction Failed",
        description: "An error occurred while trying to extract prayers.",
        variant: "destructive",
      });
      setIsLoading(false);
    }
  };
  
  // Import prayers mutation
  const importPrayers = useMutation({
    mutationFn: async () => {
      if (!selectedSaintId || extractedPrayers.length === 0) {
        throw new Error("Missing required information");
      }
      
      const response = await apiRequest(
        "POST",
        "/api/novena-prayers/import",
        {
          saintId: parseInt(selectedSaintId),
          prayers: extractedPrayers
        }
      );
      
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/saints/${selectedSaintId}/prayers`] });
      
      toast({
        title: "Import Successful",
        description: `Imported ${extractedPrayers.length} prayers for the selected saint.`,
      });
      
      // Reset form
      setUrl("");
      setSelectedSaintId("");
      setPreviewContent("");
      setExtractedPrayers([]);
      
      // Navigate to saint detail
      navigate(`/admin/saints`);
    },
    onError: (error) => {
      toast({
        title: "Import Failed",
        description: "Failed to import prayers. Please try again.",
        variant: "destructive",
      });
      console.error("Error importing prayers:", error);
    },
  });
  
  const handleImport = () => {
    if (!selectedSaintId) {
      toast({
        title: "Select a Saint",
        description: "Please select a saint for these novena prayers.",
        variant: "destructive",
      });
      return;
    }
    
    if (extractedPrayers.length === 0) {
      toast({
        title: "No Prayers Extracted",
        description: "Please extract prayers first or make sure extraction was successful.",
        variant: "destructive",
      });
      return;
    }
    
    importPrayers.mutate();
  };
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow mt-14 mb-16">
        <div className="container mx-auto px-4 py-6">
          <div className="flex justify-between items-center mb-6">
            <h1 className="font-serif text-3xl font-bold">
              Import Novena Prayers
            </h1>
            <Button onClick={() => navigate("/admin/saints")} variant="outline">
              <i className="fas fa-arrow-left mr-2"></i> Back to Saints
            </Button>
          </div>
          
          <Card className="bg-white rounded-lg shadow-md p-5 mb-6">
            <h2 className="text-xl font-semibold mb-4">Step 1: Enter Novena URL</h2>
            <div className="space-y-4">
              <div>
                <Label htmlFor="url">URL to Novena Resource</Label>
                <div className="flex mt-2 space-x-2">
                  <Input
                    id="url"
                    value={url}
                    onChange={(e) => setUrl(e.target.value)}
                    placeholder="https://example.com/novena-prayers"
                    className="flex-1"
                  />
                  <Button 
                    onClick={previewNovena}
                    disabled={isLoading || !url}
                  >
                    {isLoading ? (
                      <><i className="fas fa-spinner fa-spin mr-2"></i> Loading...</>
                    ) : (
                      <>Preview</>
                    )}
                  </Button>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  Enter the URL of a website containing the novena prayers you want to import.
                </p>
              </div>
            </div>
          </Card>
          
          {previewContent && (
            <Card className="bg-white rounded-lg shadow-md p-5 mb-6">
              <h2 className="text-xl font-semibold mb-4">Step 2: Review Content</h2>
              <div className="space-y-4">
                <div className="border border-slate-200 rounded-md p-3 max-h-80 overflow-y-auto">
                  <pre className="whitespace-pre-wrap text-sm">{previewContent}</pre>
                </div>
                <div className="flex justify-end">
                  <Button 
                    onClick={extractPrayers}
                    disabled={isLoading || !previewContent}
                  >
                    {isLoading ? (
                      <><i className="fas fa-spinner fa-spin mr-2"></i> Processing...</>
                    ) : (
                      <>Extract Daily Prayers <i className="fas fa-magic ml-2"></i></>
                    )}
                  </Button>
                </div>
              </div>
            </Card>
          )}
          
          {extractedPrayers.length > 0 && (
            <Card className="bg-white rounded-lg shadow-md p-5 mb-6">
              <h2 className="text-xl font-semibold mb-4">Step 3: Assign to Saint</h2>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="saint">Select Saint</Label>
                  <Select
                    value={selectedSaintId}
                    onValueChange={setSelectedSaintId}
                  >
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Select a saint" />
                    </SelectTrigger>
                    <SelectContent>
                      {saints ? 
                        (saints as SaintResponse[]).map(saint => (
                          <SelectItem key={saint.id} value={saint.id.toString()}>
                            {saint.name}
                          </SelectItem>
                        ))
                      : <SelectItem value="loading">Loading saints...</SelectItem>
                      }
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <h3 className="font-medium mb-2">Extracted Prayers ({extractedPrayers.length} days)</h3>
                  <div className="border border-slate-200 rounded-md p-4 max-h-96 overflow-y-auto">
                    {extractedPrayers.map((prayer, index) => (
                      <div key={index} className="mb-4">
                        <h4 className="font-medium">Day {prayer.day}</h4>
                        {prayer.title && <p className="text-primary font-medium">{prayer.title}</p>}
                        <p className="text-sm text-slate-600 whitespace-pre-wrap">{prayer.content.slice(0, 150)}...</p>
                        <Separator className="mt-2" />
                      </div>
                    ))}
                  </div>
                </div>
                
                <Alert className="bg-amber-50 border-amber-200">
                  <AlertDescription>
                    <div className="flex items-start">
                      <i className="fas fa-exclamation-triangle text-amber-500 mr-2 mt-0.5"></i>
                      <span>
                        Importing these prayers will replace any existing prayers for this saint.
                        Make sure you have selected the correct saint.
                      </span>
                    </div>
                  </AlertDescription>
                </Alert>
                
                <div className="flex justify-end space-x-3">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setExtractedPrayers([]);
                      setSelectedSaintId("");
                    }}
                  >
                    Reset
                  </Button>
                  <Button
                    onClick={handleImport}
                    disabled={importPrayers.isPending || !selectedSaintId}
                  >
                    {importPrayers.isPending ? (
                      <><i className="fas fa-spinner fa-spin mr-2"></i> Importing...</>
                    ) : (
                      <>Import Prayers <i className="fas fa-upload ml-2"></i></>
                    )}
                  </Button>
                </div>
              </div>
            </Card>
          )}
        </div>
      </main>
      
      <BottomNavigation />
    </div>
  );
}
import * as React from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Header } from "@/components/layout/header";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CategoryResponse } from "@/lib/types";
import { Input } from "@/components/ui/input";

export default function AdminCategories() {
  const [, navigate] = useLocation();
  const [searchTerm, setSearchTerm] = React.useState("");

  // Fetch all categories
  const { data: categories, isLoading } = useQuery({
    queryKey: ["/api/categories"],
  });

  const filteredCategories = React.useMemo(() => {
    if (!categories) return [];
    const typedCategories = categories as CategoryResponse[];
    if (!searchTerm) return typedCategories;
    
    return typedCategories.filter(category => 
      category.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (category.description && category.description.toLowerCase().includes(searchTerm.toLowerCase()))
    );
  }, [categories, searchTerm]);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow mt-14 mb-16">
        <div className="container mx-auto px-4 py-6">
          <div className="flex justify-between items-center mb-6">
            <h1 className="font-serif text-3xl font-bold">Manage Categories</h1>
            <Button onClick={() => navigate("/admin")} variant="outline">
              <i className="fas fa-arrow-left mr-2"></i> Back to Admin
            </Button>
          </div>
          
          <Card className="bg-white rounded-lg shadow-md p-5 mb-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="font-serif text-xl font-semibold">All Categories</h2>
              <Button onClick={() => navigate("/admin/categories/new")}>
                <i className="fas fa-plus mr-2"></i> Add New Category
              </Button>
            </div>
            
            <div className="mb-4">
              <Input
                placeholder="Search categories..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="max-w-md"
              />
            </div>
            
            {isLoading ? (
              <div className="text-center py-10">
                <i className="fas fa-spinner fa-spin text-2xl text-primary mb-2"></i>
                <p>Loading categories...</p>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredCategories.length === 0 ? (
                  <p className="text-slate-600 text-center py-10">
                    {searchTerm ? "No categories found matching your search." : "No categories found. Add your first category!"}
                  </p>
                ) : (
                  filteredCategories.map((category: CategoryResponse) => (
                    <Card key={category.id} className="border border-slate-200 hover:border-primary transition-colors">
                      <div className="p-4 flex justify-between items-center">
                        <div className="flex items-center">
                          <div className={`w-10 h-10 rounded-full flex items-center justify-center mr-3`} style={{ backgroundColor: category.iconBgColor || '#e2e8f0' }}>
                            <i className={`${category.icon || 'fas fa-folder'}`} style={{ color: category.iconColor || '#334155' }}></i>
                          </div>
                          <div>
                            <h3 className="font-serif font-semibold text-lg">{category.name}</h3>
                            {category.description && <p className="text-sm text-slate-600">{category.description}</p>}
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <Button 
                            onClick={() => navigate(`/admin/categories/edit/${category.id}`)} 
                            variant="outline" 
                            size="sm"
                          >
                            <i className="fas fa-edit mr-1"></i> Edit
                          </Button>
                        </div>
                      </div>
                    </Card>
                  ))
                )}
              </div>
            )}
          </Card>
        </div>
      </main>
      
      <BottomNavigation />
    </div>
  );
}
import * as React from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Header } from "@/components/layout/header";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { SaintResponse } from "@/lib/types";
import { Input } from "@/components/ui/input";

export default function AdminPrayers() {
  const [, navigate] = useLocation();
  const [searchTerm, setSearchTerm] = React.useState("");

  // Fetch all saints
  const { data: saints, isLoading } = useQuery({
    queryKey: ["/api/saints"],
  });

  const filteredSaints = React.useMemo(() => {
    if (!saints) return [];
    const typedSaints = saints as SaintResponse[];
    if (!searchTerm) return typedSaints;
    
    return typedSaints.filter(saint => 
      saint.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (saint.title && saint.title.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (saint.patronOf && saint.patronOf.toLowerCase().includes(searchTerm.toLowerCase()))
    );
  }, [saints, searchTerm]);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow mt-14 mb-16">
        <div className="container mx-auto px-4 py-6">
          <div className="flex justify-between items-center mb-6">
            <h1 className="font-serif text-3xl font-bold">Manage Novena Prayers</h1>
            <Button onClick={() => navigate("/admin")} variant="outline">
              <i className="fas fa-arrow-left mr-2"></i> Back to Admin
            </Button>
          </div>
          
          <Card className="bg-white rounded-lg shadow-md p-5 mb-6">
            <div className="mb-6">
              <h2 className="font-serif text-xl font-semibold mb-2">Novena Prayer Management</h2>
              <p className="text-slate-600">
                Select a saint below to manage their day-specific novena prayers. You can create unique prayers for each of the 9 days of a novena.
              </p>
            </div>
            
            <div className="mb-4">
              <Input
                placeholder="Search saints..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="max-w-md"
              />
            </div>
            
            {isLoading ? (
              <div className="text-center py-10">
                <i className="fas fa-spinner fa-spin text-2xl text-primary mb-2"></i>
                <p>Loading saints...</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredSaints.length === 0 ? (
                  <p className="text-slate-600 text-center py-10 col-span-3">
                    {searchTerm ? "No saints found matching your search." : "No saints found."}
                  </p>
                ) : (
                  filteredSaints.map((saint: SaintResponse) => (
                    <Card key={saint.id} className="border border-slate-200 hover:border-primary transition-colors">
                      <div className="p-4">
                        <div className="flex justify-between items-start mb-3">
                          <h3 className="font-serif font-semibold text-lg">{saint.name}</h3>
                          {saint.title && <span className="text-xs text-slate-500 ml-2">{saint.title}</span>}
                        </div>
                        
                        <div className="flex justify-between mt-4">
                          <Button 
                            onClick={() => navigate(`/admin/prayers/${saint.id}`)} 
                            className="w-full"
                          >
                            <i className="fas fa-edit mr-2"></i> Edit Novena Prayers
                          </Button>
                        </div>
                      </div>
                    </Card>
                  ))
                )}
              </div>
            )}
          </Card>
        </div>
      </main>
      
      <BottomNavigation />
    </div>
  );
}
import * as React from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Header } from "@/components/layout/header";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { SaintResponse } from "@/lib/types";
import { Input } from "@/components/ui/input";

export default function AdminSaints() {
  const [, navigate] = useLocation();
  const [searchTerm, setSearchTerm] = React.useState("");

  // Fetch all saints
  const { data: saints, isLoading } = useQuery({
    queryKey: ["/api/saints"],
  });

  const filteredSaints = React.useMemo(() => {
    if (!saints) return [];
    const typedSaints = saints as SaintResponse[];
    if (!searchTerm) return typedSaints;
    
    return typedSaints.filter(saint => 
      saint.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (saint.title && saint.title.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (saint.patronOf && saint.patronOf.toLowerCase().includes(searchTerm.toLowerCase()))
    );
  }, [saints, searchTerm]);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow mt-14 mb-16">
        <div className="container mx-auto px-4 py-6">
          <div className="flex justify-between items-center mb-6">
            <h1 className="font-serif text-3xl font-bold">Manage Saints</h1>
            <Button onClick={() => navigate("/admin")} variant="outline">
              <i className="fas fa-arrow-left mr-2"></i> Back to Admin
            </Button>
          </div>
          
          <Card className="bg-white rounded-lg shadow-md p-5 mb-6">
            <div className="flex flex-col sm:flex-row justify-between items-center mb-4">
              <h2 className="font-serif text-xl font-semibold mb-2 sm:mb-0">All Saints</h2>
              <div className="flex space-x-2">
                <Button onClick={() => navigate("/admin/novena-import")} variant="outline">
                  <i className="fas fa-file-import mr-2"></i> Import Novenas
                </Button>
                <Button onClick={() => navigate("/admin/saints/new")}>
                  <i className="fas fa-plus mr-2"></i> Add New Saint
                </Button>
              </div>
            </div>
            
            <div className="mb-4">
              <Input
                placeholder="Search saints..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="max-w-md"
              />
            </div>
            
            {isLoading ? (
              <div className="text-center py-10">
                <i className="fas fa-spinner fa-spin text-2xl text-primary mb-2"></i>
                <p>Loading saints...</p>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredSaints.length === 0 ? (
                  <p className="text-slate-600 text-center py-10">
                    {searchTerm ? "No saints found matching your search." : "No saints found. Add your first saint!"}
                  </p>
                ) : (
                  filteredSaints.map((saint: SaintResponse) => (
                    <Card key={saint.id} className="border border-slate-200 hover:border-primary transition-colors">
                      <div className="p-4 flex justify-between items-center">
                        <div>
                          <h3 className="font-serif font-semibold text-lg">{saint.name}</h3>
                          {saint.title && <p className="text-slate-600">{saint.title}</p>}
                          {saint.patronOf && <p className="text-sm text-slate-500">Patron of: {saint.patronOf}</p>}
                        </div>
                        <div className="flex space-x-2">
                          <Button 
                            onClick={() => navigate(`/admin/prayers/${saint.id}`)} 
                            variant="outline" 
                            size="sm"
                          >
                            <i className="fas fa-pray mr-1"></i> Prayers
                          </Button>
                          <Button 
                            onClick={() => navigate(`/admin/saints/edit/${saint.id}`)} 
                            variant="outline" 
                            size="sm"
                          >
                            <i className="fas fa-edit mr-1"></i> Edit
                          </Button>
                        </div>
                      </div>
                    </Card>
                  ))
                )}
              </div>
            )}
          </Card>
        </div>
      </main>
      
      <BottomNavigation />
    </div>
  );
}
import * as React from "react";
import { useLocation } from "wouter";
import { Header } from "@/components/layout/header";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function AdminHome() {
  const [, navigate] = useLocation();
  
  const adminFeatures = [
    {
      title: "Manage Saints",
      description: "Add, edit, or view all saints in the database. You can update saint details and assign them to categories.",
      icon: "fas fa-user",
      color: "#3b82f6", // blue-500
      route: "/admin/saints"
    },
    {
      title: "Manage Categories",
      description: "Create and edit categories for organizing saints. Customize icons and colors for each category.",
      icon: "fas fa-folder",
      color: "#8b5cf6", // violet-500
      route: "/admin/categories"
    },
    {
      title: "Manage Novena Prayers",
      description: "Create custom day-specific prayers for saints' novenas. Customize the prayer content for each day.",
      icon: "fas fa-pray",
      color: "#10b981", // emerald-500
      route: "/admin/prayers"
    },
    {
      title: "Import Novenas",
      description: "Import novena prayers from external websites. Automatically extract day-by-day prayers.",
      icon: "fas fa-file-import",
      color: "#ec4899", // pink-500
      route: "/admin/novena-import"
    },
    {
      title: "Manage Testimonials",
      description: "Review and approve user testimonials about miracles and favors received through novena prayers.",
      icon: "fas fa-comment-alt",
      color: "#0ea5e9", // sky-500
      route: "/admin/testimonials"
    },
    {
      title: "Customize Header",
      description: "Change the appearance of the app header. Customize colors and background image for the app header.",
      icon: "fas fa-image",
      color: "#f59e0b", // amber-500
      route: "/admin/header-customization"
    }
  ];
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow mt-14 mb-16">
        <div className="container mx-auto px-4 py-6">
          <div className="flex justify-between items-center mb-6">
            <h1 className="font-serif text-3xl font-bold">Admin Dashboard</h1>
            <Button onClick={() => navigate("/")} variant="outline">
              <i className="fas fa-home mr-2"></i> Return to App
            </Button>
          </div>
          
          <Card className="bg-white rounded-lg shadow-md p-5 mb-6">
            <h2 className="font-serif text-xl font-semibold mb-4">Welcome to the Admin Area</h2>
            <p className="text-slate-600 mb-6">
              This is the administration area for managing content in the Catholic Saints Novenas app.
              Use the tools below to manage saints, categories, and novena prayers.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {adminFeatures.map((feature, index) => (
                <Card 
                  key={index}
                  className="border border-slate-200 hover:border-primary transition-colors"
                >
                  <div className="p-5">
                    <div className="mb-4 flex justify-center">
                      <div 
                        className="w-16 h-16 rounded-full flex items-center justify-center"
                        style={{ backgroundColor: `${feature.color}20` }} // Using 20% opacity version of the color
                      >
                        <i className={`${feature.icon} text-2xl`} style={{ color: feature.color }}></i>
                      </div>
                    </div>
                    <h3 className="font-serif text-xl font-semibold text-center mb-2">{feature.title}</h3>
                    <p className="text-slate-600 text-center mb-4">{feature.description}</p>
                    <Button 
                      className="w-full mt-2"
                      onClick={() => navigate(feature.route)}
                    >
                      <i className="fas fa-arrow-right mr-2"></i> Go to {feature.title}
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          </Card>
          
          <Card className="bg-white rounded-lg shadow-md p-5">
            <h2 className="font-serif text-xl font-semibold mb-4">Quick Tips</h2>
            <ul className="list-disc list-inside space-y-2 text-slate-600">
              <li>Add saints first, then assign them to categories.</li>
              <li>Create categories with distinct icons to help users find saints more easily.</li>
              <li>For each saint, you can create unique prayers for each day of a novena.</li>
              <li>You can mark saints as "Featured" to have them appear on the home page.</li>
              <li>Use the Import Novenas feature to quickly add prayers from external websites.</li>
              <li>Novenas can range from 1 to 54 days in length, depending on the saint's tradition.</li>
              <li>Review and approve user testimonials to inspire others with miracle stories.</li>
              <li>All changes are saved to the database immediately.</li>
            </ul>
          </Card>
        </div>
      </main>
      
      <BottomNavigation />
    </div>
  );
}
import * as React from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Header } from "@/components/layout/header";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { SaintResponse, NovenaPrayerResponse } from "@/lib/types";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";

export default function PrayerEditorAdmin() {
  const params = useParams();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const saintId = params.id;
  const [selectedDay, setSelectedDay] = React.useState<number>(1);
  const [title, setTitle] = React.useState<string>("");
  const [content, setContent] = React.useState<string>("");
  const [hasUnsavedChanges, setHasUnsavedChanges] = React.useState(false);

  // Fetch saint details
  const { data: saint, isLoading: isLoadingSaint } = useQuery({
    queryKey: [`/api/saints/${saintId}`],
  });

  // Fetch all prayers for this saint
  const { data: prayers, isLoading: isLoadingPrayers } = useQuery({
    queryKey: [`/api/saints/${saintId}/prayers`],
  });

  // Effect to update form when prayers data loads or selected day changes
  React.useEffect(() => {
    if (prayers && saint) {
      const prayersArray = prayers as NovenaPrayerResponse[];
      const prayer = prayersArray.find(p => p.day === selectedDay);
      if (prayer) {
        setTitle(prayer.title || "");
        setContent(prayer.content);
        setHasUnsavedChanges(false);
      } else {
        // If no prayer exists for this day, use saint's default prayer
        setTitle(`Day ${selectedDay} Prayer`);
        setContent((saint as SaintResponse)?.prayer || "");
        setHasUnsavedChanges(false);
      }
    }
  }, [prayers, saint, selectedDay]);

  // Save prayer mutation
  const savePrayer = useMutation({
    mutationFn: async () => {
      const response = await apiRequest(
        "POST", 
        `/api/saints/${saintId}/prayers/${selectedDay}`, 
        { title, content }
      );
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/saints/${saintId}/prayers`] });
      setHasUnsavedChanges(false);
      
      toast({
        title: "Prayer Saved",
        description: `Day ${selectedDay} prayer has been saved successfully.`,
      });
    },
    onError: (error) => {
      toast({
        title: "Error Saving Prayer",
        description: "There was an error saving the prayer. Please try again.",
        variant: "destructive",
      });
      console.error("Error saving prayer:", error);
    },
  });

  // Delete prayer mutation
  const deletePrayer = useMutation({
    mutationFn: async (prayerId: number) => {
      await apiRequest("DELETE", `/api/prayers/${prayerId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/saints/${saintId}/prayers`] });
      
      // Reset to default prayer
      if (saint) {
        setTitle(`Day ${selectedDay} Prayer`);
        setContent((saint as SaintResponse).prayer);
        setHasUnsavedChanges(false);
      }
      
      toast({
        title: "Prayer Deleted",
        description: `Day ${selectedDay} custom prayer has been removed.`,
      });
    },
    onError: (error) => {
      toast({
        title: "Error Deleting Prayer",
        description: "There was an error deleting the prayer. Please try again.",
        variant: "destructive",
      });
      console.error("Error deleting prayer:", error);
    },
  });

  const handleDayChange = (day: number) => {
    // Check for unsaved changes
    if (hasUnsavedChanges) {
      if (window.confirm("You have unsaved changes. Are you sure you want to switch days without saving?")) {
        setSelectedDay(day);
      }
    } else {
      setSelectedDay(day);
    }
  };

  const handleInputChange = (field: 'title' | 'content', value: string) => {
    if (field === 'title') {
      setTitle(value);
    } else {
      setContent(value);
    }
    setHasUnsavedChanges(true);
  };

  const handleSavePrayer = () => {
    if (content.trim().length < 10) {
      toast({
        title: "Invalid Content",
        description: "Prayer content must be at least 10 characters long.",
        variant: "destructive",
      });
      return;
    }

    savePrayer.mutate();
  };

  const handleDeletePrayer = () => {
    const prayersArray = prayers as NovenaPrayerResponse[];
    const prayer = prayersArray?.find(p => p.day === selectedDay);
    
    if (!prayer || prayer.id === 0) {
      toast({
        title: "Cannot Delete",
        description: "There is no custom prayer for this day to delete.",
        variant: "destructive",
      });
      return;
    }
    
    if (window.confirm(`Are you sure you want to delete the custom prayer for Day ${selectedDay}? This will revert to using the default prayer.`)) {
      deletePrayer.mutate(prayer.id);
    }
  };

  const navigateBack = () => {
    // Check for unsaved changes
    if (hasUnsavedChanges) {
      if (window.confirm("You have unsaved changes. Are you sure you want to leave without saving?")) {
        navigate("/admin/prayers");
      }
    } else {
      navigate("/admin/prayers");
    }
  };

  if (isLoadingSaint || isLoadingPrayers) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow mt-14 mb-16">
          <div className="container mx-auto px-4 py-6 text-center">
            <div className="mt-20">
              <i className="fas fa-spinner fa-spin text-4xl text-primary mb-4"></i>
              <p>Loading information...</p>
            </div>
          </div>
        </main>
        <BottomNavigation />
      </div>
    );
  }

  const typedSaint = saint as SaintResponse;
  const prayersArray = prayers as NovenaPrayerResponse[];

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow mt-14 mb-16">
        <div className="container mx-auto px-4 py-6">
          <div className="flex justify-between items-center mb-6">
            <h1 className="font-serif text-3xl font-bold">Edit {typedSaint.name} Novena Prayers</h1>
            <Button onClick={navigateBack} variant="outline">
              <i className="fas fa-arrow-left mr-2"></i> Back to Prayers
            </Button>
          </div>
          
          <Card className="bg-white rounded-lg shadow-md p-5 mb-6">
            <div className="mb-4">
              <h2 className="font-serif text-xl font-semibold">Day-Specific Novena Prayers</h2>
              <p className="text-slate-600 mt-1">
                Create or edit custom prayers for each day of the novena. Days with custom prayers are highlighted.
              </p>
            </div>
            
            <Tabs defaultValue="1" onValueChange={(value) => handleDayChange(parseInt(value, 10))}>
              <TabsList className="grid grid-cols-9 mb-6">
                {Array.from({ length: 9 }, (_, i) => i + 1).map((day) => (
                  <TabsTrigger 
                    key={day} 
                    value={day.toString()}
                    className={
                      prayersArray && prayersArray.some(p => p.day === day && p.id !== 0)
                        ? "border-b-2 border-primary" 
                        : ""
                    }
                  >
                    Day {day}
                  </TabsTrigger>
                ))}
              </TabsList>
              
              {Array.from({ length: 9 }, (_, i) => i + 1).map((day) => (
                <TabsContent key={day} value={day.toString()}>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="title">Prayer Title (optional)</Label>
                      <Input 
                        id="title" 
                        value={title}
                        onChange={(e) => handleInputChange('title', e.target.value)}
                        placeholder={`Day ${day} Prayer`}
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="content">Prayer Content</Label>
                      <Textarea 
                        id="content" 
                        value={content}
                        onChange={(e) => handleInputChange('content', e.target.value)}
                        placeholder="Enter the prayer content for this day..."
                        className="min-h-[300px]"
                      />
                      <p className="text-xs text-slate-500 mt-1">
                        Use double line breaks (press Enter twice) to create new paragraphs.
                      </p>
                    </div>
                    
                    <div className="flex justify-between pt-4 border-t border-slate-200">
                      <Button
                        onClick={handleDeletePrayer}
                        variant="destructive"
                        disabled={!prayersArray || !prayersArray.some(p => p.day === selectedDay && p.id !== 0) || deletePrayer.isPending}
                      >
                        {deletePrayer.isPending ? "Deleting..." : "Delete Custom Prayer"}
                      </Button>
                      
                      <div className="space-x-2">
                        <Button
                          onClick={handleSavePrayer}
                          disabled={!hasUnsavedChanges || savePrayer.isPending}
                        >
                          {savePrayer.isPending ? "Saving..." : "Save Prayer"}
                        </Button>
                      </div>
                    </div>
                  </div>
                </TabsContent>
              ))}
            </Tabs>
          </Card>
          
          <Card className="bg-white rounded-lg shadow-md p-5 mb-6">
            <h2 className="font-serif text-xl font-semibold mb-3">Default Prayer</h2>
            <p className="text-slate-600 mb-4">
              This is the default prayer used when no day-specific prayers exist:
            </p>
            <div className="prose prose-slate bg-slate-50 p-4 rounded-md border border-slate-200">
              {typedSaint.prayer.split('\n\n').map((paragraph, index) => (
                <p key={index}>{paragraph}</p>
              ))}
            </div>
            <div className="mt-4">
              <Button onClick={() => navigate(`/admin/saints/edit/${saintId}`)} variant="outline">
                <i className="fas fa-edit mr-2"></i> Edit Default Prayer
              </Button>
            </div>
          </Card>
        </div>
      </main>
      
      <BottomNavigation />
    </div>
  );
}
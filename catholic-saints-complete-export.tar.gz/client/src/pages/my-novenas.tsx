import * as React from "react";
import { useQuery } from "@tanstack/react-query";
import { Header } from "@/components/layout/header";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { NovenaCard } from "@/components/saints/novena-card";
import { DailyNovenaReminder } from "@/components/reminders/daily-novena-reminder";
import { ActiveNovena, NovenaResponse } from "@/lib/types";

export default function MyNovenas() {
  const [showReminder, setShowReminder] = React.useState(true);
  
  // Fetch user's regular novenas
  const { data: novenas, isLoading: isLoadingNovenas } = useQuery<NovenaResponse[]>({
    queryKey: ["/api/novenas"],
  });

  // Fetch user's rosary novenas
  const { data: currentRosaryNovena, isLoading: isLoadingRosaryNovena } = useQuery<any>({
    queryKey: ["/api/rosary-novenas/current"],
  });

  const isLoading = isLoadingNovenas || isLoadingRosaryNovena;

  // Process novenas for display
  const processedNovenas = React.useMemo(() => {
    const allNovenas: ActiveNovena[] = [];
    
    // Add regular novenas
    if (novenas) {
      const regularNovenas = novenas.map((novena: NovenaResponse): ActiveNovena => {
        return {
          id: novena.id,
          saintId: novena.saintId,
          saintName: novena.saint?.name || "Unknown Saint",
          saintImageUrl: novena.saint?.imageUrl || null,
          categoryName: "Prayer",
          startDate: novena.startDate,
          currentDay: novena.currentDay,
          completedDays: novena.completedDays,
          intention: novena.intention,
          isComplete: novena.isComplete,
        };
      });
      allNovenas.push(...regularNovenas);
    }
    
    // Add rosary novena if it exists
    if (currentRosaryNovena && currentRosaryNovena.id) {
      const rosaryNovena: ActiveNovena = {
        id: currentRosaryNovena.id,
        saintId: 9, // 54-Day Rosary Novena saint ID
        saintName: "54-Day Rosary Novena to the Blessed Virgin Mary",
        saintImageUrl: null,
        categoryName: "54 Day Rosary Novena To The Blessed Virgin Mary",
        startDate: currentRosaryNovena.startDate,
        currentDay: currentRosaryNovena.currentDay,
        completedDays: currentRosaryNovena.completedDays || [],
        intention: currentRosaryNovena.intentions || null,
        isComplete: currentRosaryNovena.isComplete || false,
      };
      allNovenas.push(rosaryNovena);
    }
    
    return allNovenas;
  }, [novenas, currentRosaryNovena]);

  // Separate active and completed novenas
  const activeNovenas = processedNovenas.filter((n: ActiveNovena) => !n.isComplete);
  const completedNovenas = processedNovenas.filter((n: ActiveNovena) => n.isComplete);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-grow mt-14 mb-16">
        <div className="container mx-auto px-4 py-6">
          <h1 className="font-serif text-3xl font-bold mb-2">My Novenas</h1>
          <p className="text-slate-600 mb-6">Track progress and manage all your novena prayers in one place</p>
          
          {/* Daily Novena Reminder */}
          {showReminder && (
            <div className="mb-6">
              <DailyNovenaReminder onDismiss={() => setShowReminder(false)} />
            </div>
          )}
          
          {isLoading ? (
            <div className="text-center py-8">
              <i className="fas fa-pray text-4xl text-slate-300 mb-4"></i>
              <p>Loading your novenas...</p>
            </div>
          ) : processedNovenas.length === 0 ? (
            <div className="bg-white rounded-lg shadow-md p-8 text-center">
              <i className="fas fa-pray text-4xl text-slate-300 mb-4"></i>
              <h3 className="text-xl font-serif mb-2">No Novenas Started Yet</h3>
              <p className="text-slate-600 mb-4">
                Begin your prayer journey by selecting a saint and starting a novena. Choose from traditional 9-day novenas, 
                33-day preparation, or 54-day rosary novenas.
              </p>
              <div className="flex justify-center gap-3">
                <button
                  className="bg-primary text-white px-6 py-2 rounded-lg font-semibold"
                  onClick={() => window.location.href = "/saints"}
                >
                  Browse Saints
                </button>
                <button
                  className="bg-blue-600 text-white px-6 py-2 rounded-lg font-semibold"
                  onClick={() => window.location.href = "/consecration-home"}
                >
                  Start Total Consecration
                </button>
              </div>
            </div>
          ) : (
            <>
              {/* Active Novenas */}
              <section className="mb-8">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="font-serif text-2xl font-bold">
                    Active Novenas <span className="bg-primary text-white text-sm rounded-full px-2 py-0.5 ml-2">{activeNovenas.length}</span>
                  </h2>
                  <button 
                    onClick={() => window.location.href = "/saints"}
                    className="text-primary flex items-center text-sm font-medium"
                  >
                    Start New <i className="fas fa-plus ml-1 text-xs"></i>
                  </button>
                </div>
                {activeNovenas.length > 0 ? (
                  <div className="grid grid-cols-1 gap-4">
                    {activeNovenas.map((novena: ActiveNovena) => (
                      <NovenaCard key={novena.id} novena={novena} />
                    ))}
                  </div>
                ) : (
                  <div className="bg-white rounded-lg shadow-md p-6 text-center">
                    <i className="fas fa-pray text-3xl text-slate-300 mb-3"></i>
                    <p className="text-slate-600">
                      You don't have any active novenas. Start a new prayer journey today!
                    </p>
                  </div>
                )}
              </section>

              {/* Completed Novenas */}
              <section>
                <div className="flex justify-between items-center mb-4">
                  <h2 className="font-serif text-2xl font-bold">
                    Completed Novenas 
                    {completedNovenas.length > 0 && 
                      <span className="bg-green-600 text-white text-sm rounded-full px-2 py-0.5 ml-2">{completedNovenas.length}</span>
                    }
                  </h2>
                </div>
                
                {completedNovenas.length > 0 ? (
                  <div className="grid grid-cols-1 gap-4">
                    {completedNovenas.map((novena: ActiveNovena) => (
                      <NovenaCard key={novena.id} novena={novena} />
                    ))}
                  </div>
                ) : (
                  <div className="bg-white rounded-lg shadow-md p-6 text-center">
                    <i className="fas fa-check-circle text-3xl text-slate-300 mb-3"></i>
                    <p className="text-slate-600">
                      You'll see your completed novenas here. Keep praying!
                    </p>
                  </div>
                )}
              </section>
            </>
          )}
        </div>
      </main>

      <BottomNavigation />
    </div>
  );
}

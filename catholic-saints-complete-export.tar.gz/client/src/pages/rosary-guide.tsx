import React from "react";
import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Header } from "@/components/layout/header";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { useToast } from "@/hooks/use-toast";
import { 
  ChevronRight, ChevronLeft, RotateCcw, Hand,
  Flower2, Star
} from "lucide-react";

export default function RosaryGuide() {
  const [, navigate] = useLocation();
  const { toast } = useToast();

  const [currentStep, setCurrentStep] = React.useState(0);
  const [isCompleted, setIsCompleted] = React.useState(false);

  // Get today's mystery type
  const today = new Date().getDay();
  const mysterySchedule: Record<number, { type: string; icon: string }> = {
    0: { type: "Glorious", icon: "👑" },
    1: { type: "Joyful", icon: "🌟" },
    2: { type: "Sorrowful", icon: "⚰️" },
    3: { type: "Glorious", icon: "👑" },
    4: { type: "Luminous", icon: "💡" },
    5: { type: "Sorrowful", icon: "⚰️" },
    6: { type: "Joyful", icon: "🌟" }
  };

  const todaysMystery = mysterySchedule[today] || mysterySchedule[0];

  const rosarySteps = [
    { id: 0, type: "sign", title: "Sign of the Cross", icon: "✟", instruction: "Make the sign of the cross", beads: 0 },
    { id: 1, type: "creed", title: "Apostles' Creed", icon: "📿", instruction: "Pray the Apostles' Creed", beads: 1 },
    { id: 2, type: "our_father", title: "Our Father", icon: "🙏", instruction: "Pray one Our Father", beads: 1 },
    { id: 3, type: "hail_mary", title: "3 Hail Marys", icon: "🌹", instruction: "For Faith, Hope, and Charity", beads: 3 },
    { id: 4, type: "glory", title: "Glory Be", icon: "✨", instruction: "Pray Glory Be to the Father", beads: 1 },
    // First Decade
    { id: 5, type: "mystery", title: "1st Mystery", icon: todaysMystery.icon, instruction: "Announce and meditate on the first mystery", beads: 0 },
    { id: 6, type: "our_father", title: "Our Father", icon: "🙏", instruction: "Pray one Our Father", beads: 1 },
    { id: 7, type: "decade", title: "10 Hail Marys", icon: "🌹", instruction: "While meditating on the mystery", beads: 10 },
    { id: 8, type: "glory", title: "Glory Be + Fatima Prayer", icon: "✨", instruction: "Glory be... O my Jesus...", beads: 1 },
    // Complete rosary would have all 5 decades, but simplified for demo
    { id: 9, type: "hail_queen", title: "Hail Holy Queen", icon: "👑", instruction: "Pray Hail Holy Queen", beads: 1 },
    { id: 10, type: "sign", title: "Final Sign of the Cross", icon: "✟", instruction: "Make the sign of the cross", beads: 0 }
  ];

  const currentStepData = rosarySteps[currentStep];
  const progress = (currentStep / (rosarySteps.length - 1)) * 100;

  const nextStep = () => {
    if (currentStep < rosarySteps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      setIsCompleted(true);
      toast({
        title: "Rosary Completed! 🌹",
        description: "You have successfully prayed a complete Holy Rosary.",
      });
    }
  };

  const previousStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const resetRosary = () => {
    setCurrentStep(0);
    setIsCompleted(false);
  };

  const getStepColor = (step: any) => {
    switch (step.type) {
      case "sign": return "bg-purple-100 border-purple-300 text-purple-800";
      case "creed": return "bg-indigo-100 border-indigo-300 text-indigo-800";
      case "our_father": return "bg-blue-100 border-blue-300 text-blue-800";
      case "hail_mary": case "decade": return "bg-rose-100 border-rose-300 text-rose-800";
      case "glory": return "bg-yellow-100 border-yellow-300 text-yellow-800";
      case "mystery": return "bg-green-100 border-green-300 text-green-800";
      case "hail_queen": return "bg-pink-100 border-pink-300 text-pink-800";
      default: return "bg-gray-100 border-gray-300 text-gray-800";
    }
  };

  if (isCompleted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-rose-50 to-pink-100">
        <Header />
        <main className="flex-grow mt-14 mb-16">
          <div className="container mx-auto px-4 py-6">
            <Card className="max-w-2xl mx-auto text-center p-8 bg-gradient-to-r from-rose-100 to-pink-100 border-rose-200">
              <div className="text-6xl mb-4">🌹</div>
              <h1 className="text-3xl font-bold text-rose-800 mb-4">Rosary Completed!</h1>
              <p className="text-rose-700 text-lg mb-6">
                You have successfully prayed a complete Holy Rosary. May Our Lady's blessings be upon you.
              </p>
              <div className="space-y-4">
                <Button onClick={resetRosary} className="bg-rose-600 hover:bg-rose-700 text-white px-8 py-3">
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Pray Another Rosary
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => navigate("/holy-rosary-home")}
                  className="border-rose-300 text-rose-700 hover:bg-rose-50 px-8 py-3"
                >
                  Back to Holy Rosary Home
                </Button>
              </div>
            </Card>
          </div>
        </main>
        <BottomNavigation />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 to-pink-100">
      <Header />
      
      <main className="flex-grow mt-14 mb-16">
        <div className="container mx-auto px-4 py-6">
          {/* Progress Header */}
          <Card className="mb-6 p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center">
                <Flower2 className="w-6 h-6 text-rose-600 mr-2" />
                <h1 className="text-xl font-bold text-gray-900">Novice-Friendly Rosary Guide</h1>
              </div>
              <Badge className="bg-blue-100 text-blue-800">
                {todaysMystery.type} Mysteries
              </Badge>
            </div>
            <Progress value={progress} className="h-3" />
            <p className="text-sm text-gray-600 mt-2">
              Step {currentStep + 1} of {rosarySteps.length}
            </p>
          </Card>

          {/* Current Step - Large Visual Design */}
          <Card className={`mb-6 p-8 ${getStepColor(currentStepData)} border-2 shadow-lg`}>
            <div className="text-center">
              {/* Large Icon */}
              <div className="text-8xl mb-6">{currentStepData.icon}</div>
              
              {/* Step Title */}
              <h2 className="text-4xl font-bold mb-6">{currentStepData.title}</h2>
              
              {/* Bead Counter - Visual Beads */}
              {currentStepData.beads > 0 && (
                <div className="mb-6">
                  <div className="flex items-center justify-center mb-4">
                    <Hand className="w-6 h-6 mr-3" />
                    <span className="text-2xl font-bold">
                      {currentStepData.beads === 1 ? "1 Bead" : `${currentStepData.beads} Beads`}
                    </span>
                  </div>
                  {/* Visual Bead Representation */}
                  <div className="flex justify-center flex-wrap gap-2 max-w-md mx-auto">
                    {Array.from({ length: Math.min(currentStepData.beads, 15) }, (_, i) => (
                      <div
                        key={i}
                        className="w-6 h-6 rounded-full bg-white/60 border-3 border-current shadow-lg"
                      />
                    ))}
                    {currentStepData.beads > 15 && (
                      <span className="text-xl font-bold">...</span>
                    )}
                  </div>
                </div>
              )}

              {/* Simple Instruction - Minimal Text */}
              <div className="bg-white/40 rounded-xl p-6 mb-6 border border-white/60">
                <p className="text-2xl font-semibold leading-relaxed">
                  {currentStepData.instruction}
                </p>
              </div>

              {/* Prayer Type Badge */}
              <Badge className="text-lg py-2 px-6 mb-4 bg-white/30 border-current">
                {currentStepData.type === "decade" ? "Meditative Prayer" : 
                 currentStepData.type === "mystery" ? "Reflection" : "Standard Prayer"}
              </Badge>
            </div>
          </Card>

          {/* Today's Mysteries Info Card */}
          {currentStepData.type === "mystery" && (
            <Card className="mb-6 p-6 bg-gradient-to-r from-indigo-50 to-purple-50 border-indigo-200">
              <div className="text-center">
                <h3 className="text-2xl font-bold text-indigo-800 mb-4 flex items-center justify-center">
                  <Star className="w-6 h-6 mr-2" />
                  Today's {todaysMystery.type} Mysteries
                </h3>
                <div className="grid gap-3 text-lg">
                  {todaysMystery.type === "Joyful" && [
                    "🌟 The Annunciation",
                    "👥 The Visitation", 
                    "👶 The Nativity",
                    "🕊️ The Presentation",
                    "🏛️ Finding Jesus in the Temple"
                  ].map((mystery, i) => (
                    <div key={i} className="p-3 bg-white/60 rounded-lg font-medium text-blue-800">
                      {mystery}
                    </div>
                  ))}
                  {todaysMystery.type === "Sorrowful" && [
                    "😢 The Agony in the Garden",
                    "⛓️ The Scourging at the Pillar",
                    "👑 The Crowning with Thorns", 
                    "✝️ The Carrying of the Cross",
                    "⚰️ The Crucifixion"
                  ].map((mystery, i) => (
                    <div key={i} className="p-3 bg-white/60 rounded-lg font-medium text-red-800">
                      {mystery}
                    </div>
                  ))}
                  {todaysMystery.type === "Glorious" && [
                    "🌅 The Resurrection",
                    "☁️ The Ascension",
                    "🔥 The Descent of the Holy Spirit",
                    "👑 The Assumption of Mary",
                    "👸 The Coronation of Mary"
                  ].map((mystery, i) => (
                    <div key={i} className="p-3 bg-white/60 rounded-lg font-medium text-purple-800">
                      {mystery}
                    </div>
                  ))}
                  {todaysMystery.type === "Luminous" && [
                    "💧 The Baptism of Jesus",
                    "🍷 The Wedding at Cana",
                    "📢 The Proclamation of the Kingdom",
                    "✨ The Transfiguration",
                    "🍞 The Institution of the Eucharist"
                  ].map((mystery, i) => (
                    <div key={i} className="p-3 bg-white/60 rounded-lg font-medium text-yellow-800">
                      {mystery}
                    </div>
                  ))}
                </div>
              </div>
            </Card>
          )}

          {/* Large Navigation Buttons */}
          <div className="grid grid-cols-3 gap-4">
            <Button
              onClick={previousStep}
              disabled={currentStep === 0}
              variant="outline"
              className="h-16 text-lg"
            >
              <ChevronLeft className="w-6 h-6 mr-2" />
              Previous
            </Button>

            <Button
              onClick={resetRosary}
              variant="outline"
              className="h-16 text-lg"
            >
              <RotateCcw className="w-6 h-6 mr-2" />
              Restart
            </Button>

            <Button
              onClick={nextStep}
              className="bg-rose-600 hover:bg-rose-700 text-white h-16 text-lg"
            >
              {currentStep === rosarySteps.length - 1 ? "Complete" : "Next"}
              <ChevronRight className="w-6 h-6 ml-2" />
            </Button>
          </div>
        </div>
      </main>
      
      <BottomNavigation />
    </div>
  );
}
import * as React from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Header } from "@/components/layout/header";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { Calendar, Clock, Heart, Star, CheckCircle2, Circle, Crown, Play, Pause, Copy, Share, Download, Volume2, ChevronLeft, ChevronRight } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { RosaryNovena, RosaryNovenaText } from "@shared/schema";

interface NovenaPrayer {
  id: number;
  saintId: number;
  day: number;
  title?: string;
  content: string;
  createdAt: string;
}

export default function RosaryNovenaDetail() {
  const params = useParams();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const novenaId = params.id;

  // Audio and interaction states
  const [isPlaying, setIsPlaying] = React.useState(false);
  const speechRef = React.useRef<SpeechSynthesisUtterance | null>(null);

  // Fetch novena details
  const { data: novena, isLoading } = useQuery<RosaryNovena>({
    queryKey: [`/api/rosary-novenas/${novenaId}`],
  });

  // State for viewing different days and active tab
  const [viewingDay, setViewingDay] = React.useState<number | null>(null);
  const [activeTab, setActiveTab] = React.useState("today");
  const currentViewDay = viewingDay || novena?.currentDay || 1;

  // Fetch prayer content for current viewing day
  const { data: dailyPrayer, isLoading: isLoadingPrayer } = useQuery<NovenaPrayer>({
    queryKey: [`/api/saints/9/prayers/${currentViewDay}`],
    enabled: !!currentViewDay,
    staleTime: 0, // Always fetch fresh data
    refetchOnMount: true,
  });

  // Mark day as complete mutation
  const markDayCompleteMutation = useMutation({
    mutationFn: async (day: number) => {
      await apiRequest("POST", `/api/rosary-novenas/${novenaId}/day/${day}/complete`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/rosary-novenas/${novenaId}`] });
      toast({
        title: "Day Completed! 🌹",
        description: "Your prayer has been marked as complete.",
      });
    },
  });

  // Function to render content with proper mystery formatting
  // Function to render the prayer introduction with mystery type and phase
  const renderPrayerIntroduction = (currentDay: number, content: string) => {
    // Determine mystery type based on content
    let mysteryType = "The Joyful Mysteries";
    let mysteryIcon = "🌟";
    let mysteryBg = "from-blue-50 to-sky-100";
    let mysteryBorder = "border-blue-200";
    let mysteryText = "text-blue-900";
    
    if (content.includes('Agony') || content.includes('Scourging') || content.includes('Crowning') || 
        content.includes('Carrying') || content.includes('Crucifixion')) {
      mysteryType = "The Sorrowful Mysteries";
      mysteryIcon = "⚰️";
      mysteryBg = "from-red-50 to-rose-100";
      mysteryBorder = "border-red-200";
      mysteryText = "text-red-900";
    } else if (content.includes('Resurrection') || content.includes('Ascension') || 
               content.includes('Descent') || content.includes('Assumption') || 
               content.includes('Coronation')) {
      mysteryType = "The Glorious Mysteries";
      mysteryIcon = "👑";
      mysteryBg = "from-purple-50 to-violet-100";
      mysteryBorder = "border-purple-200";
      mysteryText = "text-purple-900";
    }
    
    // Determine phase based on day
    const isInPetition = currentDay <= 27;
    const phaseTitle = isInPetition ? "In Petition" : "In Thanksgiving";
    const phaseIcon = "🙏";
    const phaseBg = isInPetition ? "from-blue-50 to-indigo-50" : "from-green-50 to-emerald-50";
    const phaseBorder = isInPetition ? "border-blue-200" : "border-green-200";
    const phaseText = isInPetition ? "text-blue-900" : "text-green-900";
    
    return (
      <div className="mb-8 space-y-6">
        {/* Mystery Type Card */}
        <div className={`bg-gradient-to-r ${mysteryBg} ${mysteryBorder} border rounded-xl shadow-lg`}>
          <div className="text-center py-6 px-4">
            <div className="text-4xl mb-3">{mysteryIcon}</div>
            <h2 className={`text-3xl font-bold ${mysteryText} mb-3 tracking-wide`}>
              {mysteryType}
            </h2>
            <div className="bg-white/30 rounded-lg py-3 px-4 max-w-md mx-auto">
              <p className={`${mysteryText} font-medium text-lg`}>
                Prayer before the recitation: Sign of the cross. Hail Mary.
              </p>
            </div>
          </div>
        </div>
        
        {/* Phase Header Card */}
        <div className={`bg-gradient-to-r ${phaseBg} ${phaseBorder} border rounded-xl shadow-lg`}>
          <div className="text-center py-5 px-4">
            <div className="flex items-center justify-center mb-3">
              <span className={`${phaseText.replace('text-', 'text-')} text-3xl mr-3`}>{phaseIcon}</span>
              <h3 className={`text-2xl font-bold ${phaseText} tracking-wide`}>
                {phaseTitle}
              </h3>
              <span className={`${phaseText.replace('text-', 'text-')} text-3xl ml-3`}>{phaseIcon}</span>
            </div>
            <div className="bg-white/30 rounded-lg py-2 px-4 max-w-xs mx-auto">
              <p className={`${phaseText} font-medium text-sm`}>
                {isInPetition ? "First 27 Days" : "Days 28-54"}
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderPrayerContent = (content: string) => {
    const mysteryTitles = [
      'The Annunciation', 'The Visitation', 'The Nativity', 'The Presentation', 'The Finding Of The Child Jesus In The Temple',
      'The Agony', 'The Scourging', 'The Crowning With Thorns', 'The Carrying Of The Cross', 'The Crucifixion',
      'The Resurrection', 'The Ascension', 'The Descent of the Holy Ghost', 'The Assumption Of Our Blessed Mother Into Heaven', 'The Coronation Of Our Blessed Mother In Heaven As Its Queen'
    ];
    
    // Split content into sections using double line breaks first
    const sections = content.split('\n\n');
    const processedParagraphs = [];
    
    for (let i = 0; i < sections.length; i++) {
      const section = sections[i].trim();
      
      // Skip empty sections
      if (!section) continue;
      
      // Check if this section starts with a mystery title
      const lines = section.split('\n');
      const firstLine = lines[0].trim();
      
      if (mysteryTitles.includes(firstLine)) {
        // Add the mystery title
        processedParagraphs.push({
          type: 'mystery_title',
          content: firstLine,
          index: i
        });
        
        // If there are more lines in this section, they contain the meditation
        if (lines.length > 1) {
          const meditationText = lines.slice(1).join('\n').trim();
          if (meditationText) {
            processedParagraphs.push({
              type: 'mystery_meditation',
              content: meditationText,
              mystery: firstLine,
              index: i
            });
          }
        }
      } else {
        // Check if section contains any mystery titles within it
        let foundMystery = false;
        for (const line of lines) {
          const trimmedLine = line.trim();
          if (mysteryTitles.includes(trimmedLine)) {
            // Split this section by the mystery title
            const mysteryIndex = section.indexOf(trimmedLine);
            const beforeMystery = section.substring(0, mysteryIndex).trim();
            const afterMystery = section.substring(mysteryIndex + trimmedLine.length).trim();
            
            // Add content before mystery title if any
            if (beforeMystery) {
              processedParagraphs.push({
                type: 'regular',
                content: beforeMystery,
                index: i
              });
            }
            
            // Add mystery title
            processedParagraphs.push({
              type: 'mystery_title',
              content: trimmedLine,
              index: i
            });
            
            // Add content after mystery title if any
            if (afterMystery) {
              processedParagraphs.push({
                type: 'mystery_meditation',
                content: afterMystery,
                mystery: trimmedLine,
                index: i
              });
            }
            
            foundMystery = true;
            break;
          }
        }
        
        // If no mystery found, treat as regular content
        if (!foundMystery) {
          processedParagraphs.push({
            type: 'regular',
            content: section,
            index: i
          });
        }
      }
    }
    
    return processedParagraphs.map((item, index) => {
      if (item.type === 'mystery_title') {
        const mysteryTitle = item.content;
        let mysteryIcon = "✨";
        let cardClasses = "bg-gradient-to-r from-indigo-50 to-indigo-100 border-indigo-200";
        let titleClasses = "text-indigo-900";
        let dividerClasses = "bg-gradient-to-r from-indigo-400 to-indigo-600";
        
        if (mysteryTitle.includes('Annunciation') || mysteryTitle.includes('Visitation') || 
            mysteryTitle.includes('Nativity') || mysteryTitle.includes('Presentation') || 
            mysteryTitle.includes('Finding')) {
          mysteryIcon = "🌟";
          cardClasses = "bg-gradient-to-r from-blue-50 to-sky-100 border-blue-200";
          titleClasses = "text-blue-900";
          dividerClasses = "bg-gradient-to-r from-blue-400 to-sky-600";
        } else if (mysteryTitle.includes('Agony') || mysteryTitle.includes('Scourging') || 
                   mysteryTitle.includes('Crowning') || mysteryTitle.includes('Carrying') || 
                   mysteryTitle.includes('Crucifixion')) {
          mysteryIcon = "⚰️";
          cardClasses = "bg-gradient-to-r from-red-50 to-rose-100 border-red-200";
          titleClasses = "text-red-900";
          dividerClasses = "bg-gradient-to-r from-red-400 to-rose-600";
        } else if (mysteryTitle.includes('Resurrection') || mysteryTitle.includes('Ascension') || 
                   mysteryTitle.includes('Descent') || mysteryTitle.includes('Assumption') || 
                   mysteryTitle.includes('Coronation')) {
          mysteryIcon = "👑";
          cardClasses = "bg-gradient-to-r from-purple-50 to-violet-100 border-purple-200";
          titleClasses = "text-purple-900";
          dividerClasses = "bg-gradient-to-r from-purple-400 to-violet-600";
        }
        
        return (
          <div key={index} className={`${cardClasses} rounded-xl border shadow-lg mb-4`}>
            <div className="text-center py-8 px-4">
              <div className="text-5xl mb-4">{mysteryIcon}</div>
              <h3 className={`text-4xl font-bold ${titleClasses} mb-4 tracking-wide`}>
                {mysteryTitle}
              </h3>
              <div className={`w-40 h-2 ${dividerClasses} mx-auto rounded-full`}></div>
            </div>
          </div>
        );
      } else if (item.type === 'mystery_meditation') {
        // Split the meditation content more carefully
        const content = item.content;
        const prayerSplit = content.split('I humbly pray:');
        const meditationText = prayerSplit[0].trim();
        
        // Extract prayer instructions and virtue binding
        let prayerInstructions = '';
        let virtueBinding = '';
        
        if (prayerSplit[1]) {
          const afterPrayer = prayerSplit[1].trim();
          // Look for the virtue binding section
          const bindingSplit = afterPrayer.split('I bind these');
          prayerInstructions = bindingSplit[0].trim();
          
          if (bindingSplit[1]) {
            virtueBinding = 'I bind these' + bindingSplit[1].trim();
          }
        }
        
        return (
          <div key={index} className="space-y-4 mb-6">
            {/* Meditation Text */}
            <div className="bg-gradient-to-r from-slate-50 to-gray-50 rounded-xl p-6 border border-gray-200 shadow-sm">
              <p className="text-gray-800 text-lg leading-relaxed italic">
                {meditationText}
              </p>
            </div>
            
            {/* Prayer Instructions */}
            {prayerInstructions && (
              <div className="bg-blue-50 rounded-lg p-4 border-l-4 border-blue-400">
                <p className="text-blue-900 font-medium">
                  <strong>I humbly pray:</strong><br />
                  {prayerInstructions}
                </p>
              </div>
            )}
            
            {/* Virtue Binding */}
            {virtueBinding && (
              <div className="bg-gradient-to-r from-rose-50 to-pink-50 rounded-lg p-4 border border-rose-200">
                <p className="text-rose-800 font-medium text-center italic">{virtueBinding}</p>
              </div>
            )}
          </div>
        );
      } else {
        const paragraph = item.content;
        
        // Check for special sections
        if (paragraph.includes('Hail Mary') || paragraph.includes('Our Father') || paragraph.includes('Glory Be')) {
          return (
            <div key={index} className="bg-blue-50 rounded-lg p-4 border-l-4 border-blue-400 my-4">
              <p className="text-blue-900 font-medium italic">{paragraph}</p>
            </div>
          );
        }
        
        // Handle "In petition" section that contains the prayer to Mary
        if (paragraph.toLowerCase().startsWith('in petition') && paragraph.includes('Sweet Mother Mary')) {
          // Remove the "In petition" text from the beginning
          const cleanedParagraph = paragraph.replace(/^In petition\s*/i, '').trim();
          
          return (
            <div key={index} className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-6 border border-blue-200 shadow-lg my-6">
              <div className="flex items-center justify-center mb-4">
                <span className="text-blue-600 text-2xl mr-2">🙏</span>
                <h3 className="text-2xl font-bold text-blue-800 text-center">In Petition</h3>
                <span className="text-blue-600 text-2xl ml-2">🙏</span>
              </div>
              <div className="bg-blue-100/50 rounded-lg p-4 border border-blue-300">
                <p className="text-blue-900 text-lg leading-relaxed font-medium">{cleanedParagraph}</p>
              </div>
            </div>
          );
        }

        // Handle "In thanksgiving" section that contains the prayer to Mary
        if (paragraph.toLowerCase().startsWith('in thanksgiving') && paragraph.includes('Sweet Mother Mary')) {
          // Remove the "In thanksgiving" text from the beginning
          const cleanedParagraph = paragraph.replace(/^In thanksgiving\s*/i, '').trim();
          
          return (
            <div key={index} className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl p-6 border border-green-200 shadow-lg my-6">
              <div className="flex items-center justify-center mb-4">
                <span className="text-green-600 text-2xl mr-2">🙏</span>
                <h3 className="text-2xl font-bold text-green-800 text-center">In Thanksgiving</h3>
                <span className="text-green-600 text-2xl ml-2">🙏</span>
              </div>
              <div className="bg-green-100/50 rounded-lg p-4 border border-green-300">
                <p className="text-green-900 text-lg leading-relaxed font-medium">{cleanedParagraph}</p>
              </div>
            </div>
          );
        }

        if (paragraph.includes('Spiritual Communion')) {
          // Remove the duplicate "Spiritual Communion" text from the beginning of the paragraph
          const cleanedParagraph = paragraph.replace(/^Spiritual Communion\s*/i, '').trim();
          
          return (
            <div key={index} className="bg-gradient-to-r from-amber-50 to-yellow-50 rounded-xl p-6 border border-amber-200 shadow-lg my-6">
              <div className="flex items-center justify-center mb-4">
                <span className="text-amber-600 text-2xl mr-2">❤️</span>
                <h3 className="text-2xl font-bold text-amber-800 text-center">Spiritual Communion</h3>
                <span className="text-amber-600 text-2xl ml-2">❤️</span>
              </div>
              <div className="bg-amber-100/50 rounded-lg p-4 border border-amber-300">
                <p className="text-amber-900 text-lg leading-relaxed font-medium">{cleanedParagraph}</p>
              </div>
            </div>
          );
        }
        
        if (paragraph.includes('I bind these') && paragraph.includes('roses')) {
          return (
            <div key={index} className="bg-gradient-to-r from-rose-50 to-pink-50 rounded-lg p-4 border border-rose-200 my-4">
              <p className="text-rose-800 font-medium text-center italic">{paragraph}</p>
            </div>
          );
        }
        
        // Clean up any duplicate "In petition" or "In thanksgiving" phrases in regular paragraphs
        let cleanedParagraph = paragraph
          .replace(/^In petition\s*/i, '')
          .replace(/^In thanksgiving\s*/i, '')
          .trim();

        return (
          <div key={index} className="my-4">
            <p className="text-gray-800 leading-relaxed text-lg">{cleanedParagraph}</p>
          </div>
        );
      }
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!novena) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">Novena not found</h2>
          <Button onClick={() => navigate("/novenas")}>Return to My Novenas</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      <Header />
      
      <main className="pt-16 pb-20 px-4">
        <div className="max-w-4xl mx-auto">
          {/* Header Section */}
          <div className="text-center mb-8">
            <div className="flex items-center justify-center gap-2 mb-4">
              <Crown className="h-8 w-8 text-yellow-600" />
              <h1 className="text-3xl md:text-4xl font-bold text-gray-800">
                54-Day Rosary Novena
              </h1>
              <Crown className="h-8 w-8 text-yellow-600" />
            </div>
            
            <div className="flex items-center justify-center gap-4 text-sm text-gray-600 mb-6">
              <div className="flex items-center gap-1">
                <Calendar className="h-4 w-4" />
                <span>Day {currentViewDay} of 54</span>
              </div>
              <div className="flex items-center gap-1">
                <Clock className="h-4 w-4" />
                <span>{novena.phase === 'petition' ? 'Petition' : 'Thanksgiving'} Phase</span>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="mb-6">
              <Progress value={(currentViewDay / 54) * 100} className="h-3" />
              <p className="text-sm text-gray-600 mt-2">
                {Math.round((currentViewDay / 54) * 100)}% Complete
              </p>
            </div>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger value="today">Today's Prayer</TabsTrigger>
              <TabsTrigger value="navigate">Navigate Days</TabsTrigger>
            </TabsList>

            <TabsContent value="today">
              <Card className="backdrop-blur-md bg-white/90 border border-white/20 shadow-2xl">
                {isLoadingPrayer ? (
                  <div className="p-8 text-center">
                    <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-600 mx-auto mb-4"></div>
                    <p className="text-gray-600">Loading today's prayer...</p>
                  </div>
                ) : dailyPrayer ? (
                  <div className="p-6 md:p-8">
                    {/* Day Navigation */}
                    <div className="flex items-center justify-between mb-6">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setViewingDay(Math.max(1, currentViewDay - 1))}
                        disabled={currentViewDay <= 1}
                      >
                        <ChevronLeft className="h-4 w-4 mr-1" />
                        Previous
                      </Button>
                      
                      <Badge variant="secondary" className="text-lg py-2 px-4">
                        Day {currentViewDay}
                      </Badge>
                      
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setViewingDay(Math.min(54, currentViewDay + 1))}
                        disabled={currentViewDay >= 54}
                      >
                        Next
                        <ChevronRight className="h-4 w-4 ml-1" />
                      </Button>
                    </div>

                    {/* Prayer Introduction */}
                    {renderPrayerIntroduction(currentViewDay, dailyPrayer.content)}

                    {/* Prayer Text */}
                    <div className="relative z-10">
                      <div className="prose prose-lg prose-gray max-w-none">
                        <div className="text-gray-800 leading-relaxed space-y-4">
                          {renderPrayerContent(dailyPrayer.content)}
                        </div>
                      </div>
                    </div>

                    {/* Complete Button */}
                    <div className="mt-8 text-center">
                      <Button
                        onClick={() => markDayCompleteMutation.mutate(currentViewDay)}
                        disabled={markDayCompleteMutation.isPending}
                        className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white font-semibold py-3 px-8 rounded-xl shadow-lg transform transition-all duration-200 hover:scale-105"
                      >
                        {markDayCompleteMutation.isPending ? (
                          <div className="flex items-center gap-2">
                            <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                            <span>Marking Complete...</span>
                          </div>
                        ) : (
                          <div className="flex items-center gap-2">
                            <CheckCircle2 className="h-5 w-5" />
                            <span>Mark Day {currentViewDay} Complete</span>
                          </div>
                        )}
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="p-8 text-center">
                    <p className="text-gray-600">No prayer content available for this day.</p>
                  </div>
                )}
              </Card>
            </TabsContent>

            <TabsContent value="navigate">
              <Card className="backdrop-blur-md bg-white/90 border border-white/20 shadow-2xl p-6">
                <h3 className="text-xl font-semibold mb-4">Navigate to Any Day</h3>
                <div className="grid grid-cols-6 md:grid-cols-9 gap-2">
                  {Array.from({ length: 54 }, (_, i) => i + 1).map((day) => (
                    <Button
                      key={day}
                      variant={day === currentViewDay ? "default" : "outline"}
                      size="sm"
                      onClick={() => {
                        setViewingDay(day);
                        setActiveTab("today");
                      }}
                      className={day === currentViewDay ? "bg-blue-600 text-white" : ""}
                    >
                      {day}
                    </Button>
                  ))}
                </div>
                
                {viewingDay && viewingDay !== novena.currentDay && (
                  <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                    <p className="text-blue-800 text-sm">
                      You're viewing Day {viewingDay}. Your current progress is Day {novena.currentDay}.
                    </p>
                    <Button
                      onClick={() => setViewingDay(null)}
                      variant="outline"
                      size="sm"
                      className="mt-2"
                    >
                      Return to Current Day ({novena.currentDay})
                    </Button>
                  </div>
                )}
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>

      <BottomNavigation />
    </div>
  );
}
import * as React from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Header } from "@/components/layout/header";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { Card } from "@/components/ui/card";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Progress } from "@/components/ui/progress";
import { format, addDays } from "date-fns";
import { NovenaResponse } from "@/lib/types";

export default function ConsecrationHome() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  
  // Fetch the user's consecration novenas
  const { data: userNovenas, isLoading } = useQuery<NovenaResponse[]>({
    queryKey: ["/api/novenas"],
  });
  
  // Get active consecration novena
  const activeConsecration = React.useMemo(() => {
    if (!userNovenas) return null;
    return userNovenas.find(novena => 
      novena.saintId === 10 && // 33-Day Consecration Saint ID
      !novena.isComplete
    );
  }, [userNovenas]);
  
  // Start a new consecration
  const startConsecration = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/novenas", {
        saintId: 10, // 33-Day Consecration Saint ID
        intention: "My intention for this consecration to the Immaculate Heart of Mary"
      });
      return await response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/novenas"] });
      toast({
        title: "Consecration Journey Started",
        description: "You've begun your 33-day journey of consecration to the Immaculate Heart of Mary.",
      });
      navigate(`/consecration/${data.id}`);
    },
    onError: (error) => {
      toast({
        title: "Failed to Start Consecration",
        description: "There was an error starting your consecration journey. Please try again.",
        variant: "destructive",
      });
      console.error("Error starting consecration:", error);
    },
  });

  // Continue existing consecration
  const continueConsecration = () => {
    if (activeConsecration) {
      navigate(`/consecration/${activeConsecration.id}`);
    }
  };
  
  return (
    <div className="min-h-screen flex flex-col bg-blue-50">
      <Header />
      
      <main className="flex-grow mt-14 mb-16 container mx-auto px-4 py-6">
        <h1 className="font-serif text-3xl font-bold text-center mb-8">
          Preparation for Total Consecration
        </h1>

        <div className="max-w-3xl mx-auto">
          {/* Hero Section */}
          <Card className="bg-blue-600 text-white rounded-lg shadow-lg p-6 mb-8 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-700 to-blue-500 opacity-90"></div>
            <div className="relative z-10">
              <h2 className="font-serif text-2xl font-bold mb-3">
                Preparation for Total Consecration to Jesus through Mary
              </h2>
              <p className="text-blue-100 mb-4">
                "Totus Tuus" (Totally Yours) - A 33-day spiritual journey of 
                preparation for consecration to Jesus through Mary, following 
                the method of St. Louis de Montfort.
              </p>
              
              {isLoading ? (
                <div className="bg-white/20 rounded p-4 animate-pulse w-full h-10"></div>
              ) : activeConsecration ? (
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm text-blue-100">
                      Day {activeConsecration.currentDay} of 33
                    </span>
                    <span className="text-sm text-blue-100">
                      {Math.round((activeConsecration.currentDay / 33) * 100)}% Complete
                    </span>
                  </div>
                  <Progress 
                    value={(activeConsecration.currentDay / 33) * 100} 
                    className="h-2 bg-blue-300 mb-3" 
                  />
                  <Button 
                    className="w-full bg-white text-blue-700 hover:bg-blue-50"
                    onClick={continueConsecration}
                  >
                    Continue Your Preparation Journey
                  </Button>
                </div>
              ) : (
                <Button 
                  className="w-full bg-white text-blue-700 hover:bg-blue-50"
                  onClick={() => startConsecration.mutate()}
                  disabled={startConsecration.isPending}
                >
                  {startConsecration.isPending ? "Starting..." : "Begin Total Consecration Preparation"}
                </Button>
              )}
            </div>
          </Card>

          {/* What Is Consecration */}
          <Card className="bg-white rounded-lg shadow-md p-6 mb-6">
            <h2 className="font-serif text-xl font-semibold mb-4">What is Total Consecration?</h2>
            <div className="text-slate-700 space-y-3">
              <p>
                Total Consecration to Jesus through Mary is the act of entrusting yourself entirely to Jesus 
                through His mother. This consecration, also known as "Perfect Consecration" or "True Devotion," 
                was promoted by St. Louis de Montfort as the surest, easiest, and most perfect means to becoming a saint.
              </p>
              <p>
                The 33-day preparation period helps deepen your relationship with Jesus through Mary by renouncing 
                the spirit of the world, gaining knowledge of self, understanding Mary's role in salvation, and 
                growing in knowledge of Christ. This method includes daily prayers, readings, and reflections.
              </p>
              <p>
                At the end of the 33-day preparation period, you recite a formal prayer of consecration, offering yourself 
                to Jesus through Mary as her slave, allowing her to form you into the image of her Son.
              </p>
            </div>
          </Card>

          {/* Consecration Journey */}
          <Card className="bg-white rounded-lg shadow-md p-6 mb-6">
            <h2 className="font-serif text-xl font-semibold mb-4">The Preparation Journey</h2>
            <div className="space-y-4">
              <div className="flex">
                <div className="mr-3 bg-blue-100 text-blue-700 h-8 w-8 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="font-semibold">1</span>
                </div>
                <div>
                  <h3 className="font-semibold text-blue-700">Days 1-12: Emptying Yourself of the Spirit of the World</h3>
                  <p className="text-slate-600 text-sm">Recognize and renounce worldly attachments</p>
                </div>
              </div>
              
              <div className="flex">
                <div className="mr-3 bg-blue-100 text-blue-700 h-8 w-8 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="font-semibold">2</span>
                </div>
                <div>
                  <h3 className="font-semibold text-blue-700">Days 13-19: Knowledge of Self</h3>
                  <p className="text-slate-600 text-sm">Recognize your shortcomings and need for God</p>
                </div>
              </div>
              
              <div className="flex">
                <div className="mr-3 bg-blue-100 text-blue-700 h-8 w-8 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="font-semibold">3</span>
                </div>
                <div>
                  <h3 className="font-semibold text-blue-700">Days 20-26: Knowledge of Mary</h3>
                  <p className="text-slate-600 text-sm">Deepen your understanding of the Blessed Mother</p>
                </div>
              </div>
              
              <div className="flex">
                <div className="mr-3 bg-blue-100 text-blue-700 h-8 w-8 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="font-semibold">4</span>
                </div>
                <div>
                  <h3 className="font-semibold text-blue-700">Days 27-33: Knowledge of Jesus Christ</h3>
                  <p className="text-slate-600 text-sm">Prepare to give yourself completely to Jesus through Mary</p>
                </div>
              </div>
              
              <div className="flex">
                <div className="mr-3 bg-green-100 text-green-700 h-8 w-8 rounded-full flex items-center justify-center flex-shrink-0">
                  <i className="fas fa-check"></i>
                </div>
                <div>
                  <h3 className="font-semibold text-green-700">Day 34: Consecration Day</h3>
                  <p className="text-slate-600 text-sm">Make your formal act of consecration to Jesus through Mary</p>
                </div>
              </div>
            </div>
          </Card>

          {/* Benefits of Consecration */}
          <Card className="bg-white rounded-lg shadow-md p-6 mb-6">
            <h2 className="font-serif text-xl font-semibold mb-4">Benefits of Total Consecration</h2>
            <ul className="list-disc pl-5 text-slate-700 space-y-2">
              <li>Deepen your spiritual life and relationship with Jesus Christ</li>
              <li>Grow in holiness with Mary's maternal guidance</li>
              <li>Receive special graces through Mary's intercession</li>
              <li>Find peace and purpose in entrusting yourself completely to Jesus through Mary</li>
              <li>Join the spiritual tradition practiced by many saints throughout history</li>
              <li>Renew your baptismal promises with a deeper understanding</li>
            </ul>
          </Card>

          {/* Start Button */}
          {isLoading ? (
            <div className="bg-white rounded p-4 animate-pulse w-full h-12"></div>
          ) : activeConsecration ? (
            <Button 
              className="w-full bg-primary text-white py-3 text-lg font-semibold mb-8"
              onClick={continueConsecration}
            >
              Continue Day {activeConsecration.currentDay} of Your Preparation
            </Button>
          ) : (
            <Button 
              className="w-full bg-primary text-white py-3 text-lg font-semibold mb-8"
              onClick={() => startConsecration.mutate()}
              disabled={startConsecration.isPending}
            >
              {startConsecration.isPending ? "Starting..." : "Begin Your 33-Day Preparation Journey"}
            </Button>
          )}
        </div>
      </main>
      
      <BottomNavigation />
    </div>
  );
}
import React from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Header } from "@/components/layout/header";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Flower2, Heart, Clock, Calendar, Star, Crown } from "lucide-react";

interface NovenaResponse {
  id: number;
  saintId: number;
  startDate: string;
  currentDay: number;
  isComplete: boolean;
  intention?: string;
}

export default function HolyRosaryHome() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  
  // Fetch the user's novenas to see if they have an active Holy Rosary devotion
  const { data: userNovenas, isLoading } = useQuery<NovenaResponse[]>({
    queryKey: ["/api/novenas"],
  });
  
  // Get active Holy Rosary devotion
  const activeRosary = React.useMemo(() => {
    if (!userNovenas) return null;
    return userNovenas.find(novena => 
      novena.saintId === 253 && // Holy Rosary Saint ID
      !novena.isComplete
    );
  }, [userNovenas]);
  
  // Start Holy Rosary devotion
  const startRosary = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/novenas", {
        saintId: 253, // Holy Rosary Saint ID
        intention: "My intention for this daily Holy Rosary devotion"
      });
      return await response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/novenas"] });
      toast({
        title: "Holy Rosary Started",
        description: "You've begun your daily Holy Rosary devotion with the 15 promises of Our Lady.",
      });
      navigate(`/novena/${data.id}`);
    },
    onError: (error) => {
      toast({
        title: "Failed to Start Holy Rosary",
        description: "There was an error starting your Holy Rosary devotion. Please try again.",
        variant: "destructive",
      });
      console.error("Error starting Holy Rosary:", error);
    },
  });

  const handleStartRosary = () => {
    startRosary.mutate();
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-rose-50 to-pink-100">
        <Header />
        <main className="flex-grow mt-14 mb-16">
          <div className="container mx-auto px-4 py-6">
            <div className="animate-pulse">
              <div className="h-8 bg-rose-200 rounded w-1/3 mb-4"></div>
              <div className="h-40 bg-rose-200 rounded mb-4"></div>
              <div className="h-20 bg-rose-200 rounded"></div>
            </div>
          </div>
        </main>
        <BottomNavigation />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 to-pink-100">
      <Header />
      
      <main className="flex-grow mt-14 mb-16">
        <div className="container mx-auto px-4 py-6">
          {/* Header Section */}
          <div className="text-center mb-8">
            <div className="w-16 h-16 mx-auto bg-gradient-to-br from-rose-500 to-pink-600 rounded-full flex items-center justify-center shadow-lg mb-4">
              <Flower2 className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              The Holy Rosary of the Blessed Virgin Mary
            </h1>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Given to Saint Dominic by Our Lady in 1214 during his mission against the Albigensian heretics in Toulouse, 
              this powerful weapon proved instrumental in defeating heretics and demonstrated miraculous power at the Battle of Lepanto.
            </p>
          </div>

          {/* Active Devotion or Start Button */}
          {activeRosary ? (
            <Card className="mb-8 bg-gradient-to-br from-rose-50 via-pink-50 to-purple-50 border-rose-200 shadow-xl overflow-hidden">
              {/* Header Section with Visual Elements */}
              <div className="bg-gradient-to-r from-rose-500 to-pink-500 text-white p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="bg-white/20 rounded-full p-3 mr-4">
                      <Flower2 className="w-8 h-8" />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold">Your Daily Rosary</h3>
                      <p className="text-rose-100 text-sm">Sacred devotion in progress</p>
                    </div>
                  </div>
                  <Badge className="bg-white/30 text-white border-white/30 text-lg py-2 px-4">
                    <div className="w-2 h-2 bg-white rounded-full mr-2 animate-pulse"></div>
                    Active
                  </Badge>
                </div>
              </div>

              {/* Progress and Information Section */}
              <div className="p-6">
                {/* Today's Mystery Info Card */}
                <div className="mb-6 p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl border border-blue-200">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="text-3xl mr-3">
                        {(() => {
                          const today = new Date().getDay();
                          const mysterySchedule: Record<number, { type: string; icon: string; color: string }> = {
                            0: { type: "Glorious", icon: "👑", color: "text-purple-600" },
                            1: { type: "Joyful", icon: "🌟", color: "text-blue-600" },
                            2: { type: "Sorrowful", icon: "⚰️", color: "text-red-600" },
                            3: { type: "Glorious", icon: "👑", color: "text-purple-600" },
                            4: { type: "Luminous", icon: "💡", color: "text-yellow-600" },
                            5: { type: "Sorrowful", icon: "⚰️", color: "text-red-600" },
                            6: { type: "Joyful", icon: "🌟", color: "text-blue-600" }
                          };
                          return (mysterySchedule[today] || mysterySchedule[0]).icon;
                        })()}
                      </div>
                      <div>
                        <h4 className="font-bold text-lg text-gray-800">
                          Today's {(() => {
                            const today = new Date().getDay();
                            const mysterySchedule: Record<number, { type: string }> = {
                              0: { type: "Glorious" },
                              1: { type: "Joyful" },
                              2: { type: "Sorrowful" },
                              3: { type: "Glorious" },
                              4: { type: "Luminous" },
                              5: { type: "Sorrowful" },
                              6: { type: "Joyful" }
                            };
                            return (mysterySchedule[today] || mysterySchedule[0]).type;
                          })()} Mysteries
                        </h4>
                        <p className="text-blue-600 text-sm">Perfect for meditation today</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm text-gray-500">Day of Week</div>
                      <div className="font-bold text-blue-700">
                        {new Date().toLocaleDateString('en-US', { weekday: 'long' })}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Benefits Reminder */}
                <div className="mb-6 p-4 bg-gradient-to-r from-amber-50 to-orange-50 rounded-xl border border-amber-200">
                  <div className="flex items-start">
                    <div className="text-2xl mr-3">📿</div>
                    <div>
                      <h4 className="font-semibold text-amber-800 mb-2">15 Promises of Our Lady</h4>
                      <p className="text-amber-700 text-sm leading-relaxed">
                        Continue your daily devotion to receive the special graces promised by Our Lady to those who pray the Rosary devoutly.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Action Buttons with Enhanced Design */}
                <div className="space-y-4">
                  {/* Primary Action - Continue Daily Rosary */}
                  <Button 
                    onClick={() => navigate(`/novena/${activeRosary.id}`)}
                    className="bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-700 hover:to-pink-700 text-white w-full py-4 text-lg font-semibold shadow-lg transition-all duration-300 transform hover:scale-[1.02]"
                  >
                    <div className="flex items-center justify-center">
                      <div className="bg-white/20 rounded-full p-2 mr-3">
                        <Heart className="w-5 h-5" />
                      </div>
                      <div className="text-left">
                        <div>Continue Daily Rosary</div>
                        <div className="text-rose-100 text-sm font-normal">Pick up where you left off</div>
                      </div>
                    </div>
                  </Button>

                  {/* Secondary Actions Grid */}
                  <div className="grid grid-cols-2 gap-3">
                    <Button 
                      onClick={() => navigate("/rosary-guide")}
                      variant="outline"
                      className="border-2 border-rose-300 text-rose-700 hover:bg-rose-50 py-4 h-auto flex-col space-y-1 transition-all duration-300 transform hover:scale-[1.02]"
                    >
                      <Flower2 className="w-6 h-6" />
                      <div className="text-center">
                        <div className="font-semibold">Guided Prayer</div>
                        <div className="text-xs opacity-75">Step-by-step</div>
                      </div>
                    </Button>

                    <Button 
                      onClick={() => navigate("/rosary-novena")}
                      variant="outline"
                      className="border-2 border-blue-300 text-blue-700 hover:bg-blue-50 py-4 h-auto flex-col space-y-1 transition-all duration-300 transform hover:scale-[1.02]"
                    >
                      <Star className="w-6 h-6" />
                      <div className="text-center">
                        <div className="font-semibold">54-Day Novena</div>
                        <div className="text-xs opacity-75">Special devotion</div>
                      </div>
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          ) : (
            <Card className="mb-8 bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 border-blue-200 shadow-xl overflow-hidden">
              {/* Header Section */}
              <div className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white p-6 text-center">
                <div className="bg-white/20 rounded-full p-4 w-20 h-20 mx-auto mb-4 flex items-center justify-center">
                  <Crown className="w-10 h-10" />
                </div>
                <h3 className="text-2xl font-bold mb-2">Begin Your Daily Rosary</h3>
                <p className="text-blue-100 text-sm">Start this sacred devotion today</p>
              </div>

              {/* Content Section */}
              <div className="p-6">
                {/* Today's Mystery Info Card */}
                <div className="mb-6 p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl border border-green-200">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="text-3xl mr-3">
                        {(() => {
                          const today = new Date().getDay();
                          const mysterySchedule: Record<number, { type: string; icon: string }> = {
                            0: { type: "Glorious", icon: "👑" },
                            1: { type: "Joyful", icon: "🌟" },
                            2: { type: "Sorrowful", icon: "⚰️" },
                            3: { type: "Glorious", icon: "👑" },
                            4: { type: "Luminous", icon: "💡" },
                            5: { type: "Sorrowful", icon: "⚰️" },
                            6: { type: "Joyful", icon: "🌟" }
                          };
                          return (mysterySchedule[today] || mysterySchedule[0]).icon;
                        })()}
                      </div>
                      <div>
                        <h4 className="font-bold text-lg text-gray-800">
                          Today's Perfect Start
                        </h4>
                        <p className="text-green-600 text-sm">
                          {(() => {
                            const today = new Date().getDay();
                            const mysterySchedule: Record<number, { type: string }> = {
                              0: { type: "Glorious" },
                              1: { type: "Joyful" },
                              2: { type: "Sorrowful" },
                              3: { type: "Glorious" },
                              4: { type: "Luminous" },
                              5: { type: "Sorrowful" },
                              6: { type: "Joyful" }
                            };
                            return (mysterySchedule[today] || mysterySchedule[0]).type;
                          })()} Mysteries await you
                        </p>
                      </div>
                    </div>
                    <Badge className="bg-green-100 text-green-800 px-3 py-1">
                      Fresh Start
                    </Badge>
                  </div>
                </div>

                {/* Benefits Preview */}
                <div className="mb-6 p-4 bg-gradient-to-r from-yellow-50 to-amber-50 rounded-xl border border-yellow-200">
                  <div className="text-center">
                    <div className="text-2xl mb-2">🎁</div>
                    <h4 className="font-semibold text-amber-800 mb-2">15 Promises of Our Lady</h4>
                    <p className="text-amber-700 text-sm leading-relaxed">
                      Begin your daily Rosary devotion and receive the special graces promised by Our Lady to faithful devotees.
                    </p>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="space-y-4">
                  {/* Primary Action - Start Daily Rosary */}
                  <Button 
                    onClick={handleStartRosary}
                    disabled={startRosary.isPending}
                    className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white w-full py-4 text-lg font-semibold shadow-lg transition-all duration-300 transform hover:scale-[1.02]"
                  >
                    <div className="flex items-center justify-center">
                      <div className="bg-white/20 rounded-full p-2 mr-3">
                        <Flower2 className="w-5 h-5" />
                      </div>
                      <div className="text-left">
                        <div>{startRosary.isPending ? "Starting..." : "Start Daily Rosary"}</div>
                        <div className="text-blue-100 text-sm font-normal">Begin your sacred journey</div>
                      </div>
                    </div>
                  </Button>

                  {/* Secondary Actions Grid */}
                  <div className="grid grid-cols-2 gap-3">
                    <Button 
                      onClick={() => navigate("/rosary-guide")}
                      variant="outline"
                      className="border-2 border-rose-300 text-rose-700 hover:bg-rose-50 py-4 h-auto flex-col space-y-1 transition-all duration-300 transform hover:scale-[1.02]"
                    >
                      <Crown className="w-6 h-6" />
                      <div className="text-center">
                        <div className="font-semibold">Guided Prayer</div>
                        <div className="text-xs opacity-75">Step-by-step</div>
                      </div>
                    </Button>

                    <Button 
                      onClick={() => navigate("/rosary-novena")}
                      variant="outline"
                      className="border-2 border-purple-300 text-purple-700 hover:bg-purple-50 py-4 h-auto flex-col space-y-1 transition-all duration-300 transform hover:scale-[1.02]"
                    >
                      <Star className="w-6 h-6" />
                      <div className="text-center">
                        <div className="font-semibold">54-Day Novena</div>
                        <div className="text-xs opacity-75">Special devotion</div>
                      </div>
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          )}

          {/* Tabs Content */}
          <Tabs defaultValue="overview" className="space-y-6">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="promises">15 Promises</TabsTrigger>
              <TabsTrigger value="mysteries">Mysteries</TabsTrigger>
            </TabsList>

            <TabsContent value="overview">
              <Card className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-4">The Holy Rosary</h3>
                <div className="prose prose-gray max-w-none">
                  <p className="text-gray-700 leading-relaxed mb-4">
                    The Holy Rosary was given to Saint Dominic by the Blessed Virgin Mary herself in 1214 during his mission 
                    against the Albigensian heretics in Toulouse, France. This powerful weapon of prayer proved instrumental 
                    in defeating these heretics and restoring Catholic faith. The Rosary combines vocal prayer with meditation 
                    on the mysteries of Christ's life, divided into four sets: Joyful, Sorrowful, Glorious, and Luminous mysteries.
                  </p>
                  <p className="text-gray-700 leading-relaxed">
                    Throughout history, the Rosary has demonstrated miraculous power, most notably at the Battle of Lepanto in 1571, 
                    where Christian forces attributed their victory over the Ottoman Empire to Our Lady's intercession through the Rosary. 
                    Padre Pio, the beloved saint, called the Rosary "the weapon" for spiritual warfare. This devotion has been a source 
                    of grace, protection, and spiritual strength for Catholics throughout the centuries, forming a spiritual armor 
                    against evil and a pathway to deeper union with Jesus through Mary.
                  </p>
                </div>
              </Card>
            </TabsContent>

            <TabsContent value="promises">
              <Card className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-4">The 15 Promises of Our Lady</h3>
                <div className="space-y-3">
                  {[
                    "To all those who recite my Rosary devoutly, I promise my special protection and very great graces.",
                    "Those who will persevere in the recitation of my Rosary shall receive some signal grace.",
                    "The Rosary shall be a very powerful armor against hell; it shall destroy vice, deliver from sin, and shall dispel heresy.",
                    "The Rosary shall make virtue and good works flourish, and shall obtain for souls the most abundant divine mercies.",
                    "Those who trust themselves to me through the Rosary, shall not perish.",
                    "Those who will recite my Rosary piously, considering its Mysteries, shall not be overwhelmed by misfortune nor die a bad death.",
                    "Those truly devoted to my Rosary shall not die without the consolations of the Church, or without grace.",
                    "Those who will recite my Rosary shall find during their life and at their death the light of God, the fullness of His grace.",
                    "I will deliver very promptly from purgatory the souls devoted to my Rosary.",
                    "The true children of my Rosary shall enjoy great glory in heaven.",
                    "What you ask through my Rosary, you shall obtain.",
                    "Those who propagate my Rosary shall obtain through me aid in all their necessities.",
                    "I have obtained from my son that all the confreres of the Rosary shall have for their brethren in life and death the saints of heaven.",
                    "Those who recite my Rosary faithfully are all my beloved children, the brothers and sisters of Jesus Christ.",
                    "Devotion to my Rosary is a special sign of predestination."
                  ].map((promise, index) => (
                    <div key={index} className="flex items-start space-x-3 p-3 bg-rose-50 rounded-lg">
                      <Badge className="bg-rose-600 text-white rounded-full min-w-[24px] h-6 flex items-center justify-center text-xs">
                        {index + 1}
                      </Badge>
                      <p className="text-gray-700 text-sm leading-relaxed">{promise}</p>
                    </div>
                  ))}
                </div>
              </Card>
            </TabsContent>

            <TabsContent value="mysteries">
              <div className="space-y-6">
                <h3 className="text-xl font-bold text-gray-900 mb-4">Explore the Mysteries</h3>
                
                {/* Mystery Cards Grid */}
                <div className="grid md:grid-cols-2 gap-6">
                  {/* Joyful Mysteries */}
                  <Card className="overflow-hidden hover:shadow-lg transition-all duration-300 transform hover:scale-[1.02] cursor-pointer bg-gradient-to-br from-yellow-50 to-amber-50 border-yellow-200">
                    <div className="p-6">
                      <div className="flex items-center mb-4">
                        <div className="bg-yellow-500 text-white rounded-full p-3 mr-4">
                          <span className="text-2xl">🌟</span>
                        </div>
                        <div>
                          <h4 className="text-lg font-semibold text-yellow-800">Joyful Mysteries</h4>
                          <p className="text-sm text-yellow-600">Monday & Saturday</p>
                        </div>
                      </div>
                      <div className="space-y-2">
                        {[
                          { number: 1, title: "The Annunciation" },
                          { number: 2, title: "The Visitation" },
                          { number: 3, title: "The Nativity" },
                          { number: 4, title: "The Presentation" },
                          { number: 5, title: "Finding Jesus in the Temple" }
                        ].map((mystery) => (
                          <div
                            key={mystery.number}
                            onClick={() => navigate(`/mystery/joyful/${mystery.number}`)}
                            className="block p-3 bg-white rounded-lg hover:bg-yellow-50 transition-colors cursor-pointer border border-yellow-100 hover:border-yellow-300"
                          >
                            <span className="text-sm text-yellow-700 font-medium">
                              {mystery.number}. {mystery.title}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </Card>

                  {/* Sorrowful Mysteries */}
                  <Card className="overflow-hidden hover:shadow-lg transition-all duration-300 transform hover:scale-[1.02] cursor-pointer bg-gradient-to-br from-red-50 to-rose-50 border-red-200">
                    <div className="p-6">
                      <div className="flex items-center mb-4">
                        <div className="bg-red-500 text-white rounded-full p-3 mr-4">
                          <span className="text-2xl">✝️</span>
                        </div>
                        <div>
                          <h4 className="text-lg font-semibold text-red-800">Sorrowful Mysteries</h4>
                          <p className="text-sm text-red-600">Tuesday & Friday</p>
                        </div>
                      </div>
                      <div className="space-y-2">
                        {[
                          { number: 1, title: "The Agony in the Garden" },
                          { number: 2, title: "The Scourging at the Pillar" },
                          { number: 3, title: "The Crowning with Thorns" },
                          { number: 4, title: "The Carrying of the Cross" },
                          { number: 5, title: "The Crucifixion" }
                        ].map((mystery) => (
                          <div
                            key={mystery.number}
                            onClick={() => navigate(`/mystery/sorrowful/${mystery.number}`)}
                            className="block p-3 bg-white rounded-lg hover:bg-red-50 transition-colors cursor-pointer border border-red-100 hover:border-red-300"
                          >
                            <span className="text-sm text-red-700 font-medium">
                              {mystery.number}. {mystery.title}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </Card>

                  {/* Glorious Mysteries */}
                  <Card className="overflow-hidden hover:shadow-lg transition-all duration-300 transform hover:scale-[1.02] cursor-pointer bg-gradient-to-br from-purple-50 to-violet-50 border-purple-200">
                    <div className="p-6">
                      <div className="flex items-center mb-4">
                        <div className="bg-purple-500 text-white rounded-full p-3 mr-4">
                          <span className="text-2xl">👑</span>
                        </div>
                        <div>
                          <h4 className="text-lg font-semibold text-purple-800">Glorious Mysteries</h4>
                          <p className="text-sm text-purple-600">Wednesday & Sunday</p>
                        </div>
                      </div>
                      <div className="space-y-2">
                        {[
                          { number: 1, title: "The Resurrection" },
                          { number: 2, title: "The Ascension" },
                          { number: 3, title: "The Descent of the Holy Spirit" },
                          { number: 4, title: "The Assumption" },
                          { number: 5, title: "The Coronation" }
                        ].map((mystery) => (
                          <div
                            key={mystery.number}
                            onClick={() => navigate(`/mystery/glorious/${mystery.number}`)}
                            className="block p-3 bg-white rounded-lg hover:bg-purple-50 transition-colors cursor-pointer border border-purple-100 hover:border-purple-300"
                          >
                            <span className="text-sm text-purple-700 font-medium">
                              {mystery.number}. {mystery.title}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </Card>

                  {/* Luminous Mysteries */}
                  <Card className="overflow-hidden hover:shadow-lg transition-all duration-300 transform hover:scale-[1.02] cursor-pointer bg-gradient-to-br from-green-50 to-emerald-50 border-green-200">
                    <div className="p-6">
                      <div className="flex items-center mb-4">
                        <div className="bg-green-500 text-white rounded-full p-3 mr-4">
                          <span className="text-2xl">💡</span>
                        </div>
                        <div>
                          <h4 className="text-lg font-semibold text-green-800">Luminous Mysteries</h4>
                          <p className="text-sm text-green-600">Thursday</p>
                        </div>
                      </div>
                      <div className="space-y-2">
                        {[
                          { number: 1, title: "The Baptism of Jesus" },
                          { number: 2, title: "The Wedding at Cana" },
                          { number: 3, title: "The Proclamation of the Kingdom" },
                          { number: 4, title: "The Transfiguration" },
                          { number: 5, title: "The Institution of the Eucharist" }
                        ].map((mystery) => (
                          <div
                            key={mystery.number}
                            onClick={() => navigate(`/mystery/luminous/${mystery.number}`)}
                            className="block p-3 bg-white rounded-lg hover:bg-green-50 transition-colors cursor-pointer border border-green-100 hover:border-green-300"
                          >
                            <span className="text-sm text-green-700 font-medium">
                              {mystery.number}. {mystery.title}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </Card>
                </div>

                {/* Traditional Schedule Info */}
                <Card className="p-4 bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
                  <div className="text-center">
                    <p className="text-sm text-blue-700">
                      <strong>Traditional Schedule:</strong> Click any mystery above to explore its meditation, virtue, and prayer. 
                      The daily schedule provides guidance, but you may pray any mysteries as the Spirit moves you.
                    </p>
                  </div>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      
      <BottomNavigation />
    </div>
  );
}
import * as React from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Header } from "@/components/layout/header";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { Card } from "@/components/ui/card";
import { NovenaResponse, NovenaPrayerResponse } from "@/lib/types";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { DayDetail } from "@/components/consecration/day-detail";

export default function ConsecrationDayDetail() {
  const params = useParams();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const novenaId = params.novenaId;
  const dayNumber = parseInt(params.day || "1", 10);
  
  // Fetch novena details
  const { data: novena, isLoading: isLoadingNovena } = useQuery<NovenaResponse>({
    queryKey: [`/api/novenas/${novenaId}`],
  });
  
  // Get the selected day's prayer
  const { data: dailyPrayer, isLoading: isLoadingPrayer } = useQuery<NovenaPrayerResponse>({
    queryKey: [`/api/saints/${(novena as NovenaResponse)?.saintId}/prayers/${dayNumber}`],
    enabled: !!novena,
    refetchOnWindowFocus: false,
    refetchOnMount: true,
    staleTime: 0, // Consider the data stale immediately to ensure fresh data on day change
  });
  
  // Update current day/progress mutation
  const markDayComplete = useMutation({
    mutationFn: async () => {
      try {
        const response = await apiRequest(
          "PATCH", 
          `/api/novenas/${novenaId}/progress`, 
          { day: dayNumber }
        );
        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.message || "Failed to update progress");
        }
        return await response.json();
      } catch (error) {
        console.error("Error updating novena progress:", error);
        throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/novenas/${novenaId}`] });
      queryClient.invalidateQueries({ queryKey: ["/api/novenas"] });
      toast({
        title: "Prayer Completed",
        description: `Day ${dayNumber} has been marked as complete.`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to Update Progress",
        description: error?.message || "There was an error updating your consecration progress.",
        variant: "destructive",
      });
      console.error("Error updating novena progress:", error);
    },
  });
  
  const navigateBack = () => {
    navigate(`/consecration/${novenaId}`);
  };
  
  const navigateToDay = (day: number) => {
    if (day >= 1 && day <= 33) {
      navigate(`/consecration/${novenaId}/day/${day}`);
    }
  };

  if (isLoadingNovena) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow mt-14 mb-16">
          <div className="container mx-auto px-4 py-6 text-center">
            <div className="mt-20">
              <i className="fas fa-pray text-4xl text-slate-300 mb-4"></i>
              <p>Loading consecration information...</p>
            </div>
          </div>
        </main>
        <BottomNavigation />
      </div>
    );
  }

  const typedNovena = novena as NovenaResponse;
  const isCompleted = typedNovena.completedDays.includes(dayNumber);
  
  return (
    <div className="min-h-screen flex flex-col bg-blue-50">
      <Header />
      
      <main className="flex-grow mt-14 mb-16">
        <div className="container mx-auto px-4 py-6">
          <div className="mb-6 flex items-center">
            <button className="mr-3 text-slate-600" onClick={navigateBack}>
              <i className="fas fa-arrow-left"></i>
            </button>
            <h2 className="font-serif text-2xl font-bold">Day {dayNumber} of 33</h2>
            
            {isCompleted && (
              <span className="ml-auto bg-green-100 text-green-700 text-sm font-medium px-3 py-1 rounded-full flex items-center">
                <i className="fas fa-check-circle mr-1"></i> Completed
              </span>
            )}
          </div>
          
          <Card className="bg-white rounded-lg shadow-md p-5 mb-6">
            <DayDetail 
              day={dayNumber} 
              novena={typedNovena} 
              dailyPrayer={dailyPrayer}
              onComplete={() => markDayComplete.mutate()}
              isPending={markDayComplete.isPending} 
            />
            
            {/* Navigation buttons */}
            <div className="flex justify-between mt-6 pt-4 border-t border-slate-100">
              <button
                onClick={() => navigateToDay(dayNumber - 1)}
                disabled={dayNumber <= 1}
                className={`px-4 py-2 flex items-center rounded-md ${
                  dayNumber <= 1 
                    ? 'text-slate-400 cursor-not-allowed' 
                    : 'text-primary hover:bg-primary/10'
                }`}
              >
                <i className="fas fa-chevron-left mr-2"></i> 
                Previous Day
              </button>
              
              <button
                onClick={() => navigateToDay(dayNumber + 1)}
                disabled={dayNumber >= 33}
                className={`px-4 py-2 flex items-center rounded-md ${
                  dayNumber >= 33
                    ? 'text-slate-400 cursor-not-allowed' 
                    : 'text-primary hover:bg-primary/10'
                }`}
              >
                Next Day
                <i className="fas fa-chevron-right ml-2"></i>
              </button>
            </div>
          </Card>
        </div>
      </main>
      <BottomNavigation />
    </div>
  );
}
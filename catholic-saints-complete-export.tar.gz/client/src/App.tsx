import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { FloatingReminderButton } from "@/components/reminders/floating-reminder-button";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import Saints from "@/pages/saints";
import Category from "@/pages/category";
import SaintDetail from "@/pages/saint-detail";
import NovenaProgress from "@/pages/novena-progress";
import ConsecrationDetail from "@/pages/consecration-detail";
import ConsecrationHome from "@/pages/consecration-home";
import ConsecrationDayDetail from "@/pages/consecration-day-detail";
import RosaryNovenaHome from "@/pages/rosary-novena-home";
import RosaryNovenaDetail from "@/pages/rosary-novena-detail";
import HolyRosaryHome from "@/pages/holy-rosary-home";
import RosaryGuide from "@/pages/rosary-guide";
import MysteryDetail from "@/pages/mystery-detail";
import MyNovenas from "@/pages/my-novenas";
import MyTestimonials from "@/pages/my-testimonials";
import PrayerEditor from "@/pages/prayer-editor-new";
import Settings from "@/pages/settings";
import About from "@/pages/about";

// Admin Pages
import Admin from "@/pages/admin";
import AdminSaints from "@/pages/admin/saints";
import SaintForm from "@/pages/admin/saint-form";
import AdminCategories from "@/pages/admin/categories";
import CategoryForm from "@/pages/admin/category-form";
import AdminPrayers from "@/pages/admin/prayers";
import PrayerEditorAdmin from "@/pages/admin/prayer-editor";
import HeaderCustomization from "@/pages/admin/header-customization";
import NovenaImport from "@/pages/admin/novena-import";
import AdminTestimonials from "@/pages/admin/testimonials";

function Router() {
  return (
    <Switch>
      {/* User-facing routes */}
      <Route path="/" component={Home} />
      <Route path="/saints" component={Saints} />
      <Route path="/category/:id" component={Category} />
      <Route path="/saint/:id" component={SaintDetail} />
      <Route path="/novena/:id" component={NovenaProgress} />
      <Route path="/consecration-home" component={ConsecrationHome} />
      <Route path="/consecration/:novenaId/day/:day" component={ConsecrationDayDetail} />
      <Route path="/consecration/:id" component={ConsecrationDetail} />
      <Route path="/rosary-novena-home" component={RosaryNovenaHome} />
      <Route path="/rosary-novena" component={RosaryNovenaHome} />
      <Route path="/rosary-novena/:id" component={RosaryNovenaDetail} />
      <Route path="/holy-rosary-home" component={HolyRosaryHome} />
      <Route path="/holy-rosary" component={HolyRosaryHome} />
      <Route path="/rosary-guide" component={RosaryGuide} />
      <Route path="/mystery/:type/:number" component={MysteryDetail} />
      <Route path="/novenas" component={MyNovenas} />
      <Route path="/testimonials" component={MyTestimonials} />
      <Route path="/settings" component={Settings} />
      <Route path="/about" component={About} />
      <Route path="/prayers/edit/:id" component={PrayerEditor} />
      
      {/* Admin routes */}
      <Route path="/admin" component={Admin} />
      <Route path="/admin/saints" component={AdminSaints} />
      <Route path="/admin/saints/new" component={SaintForm} />
      <Route path="/admin/saints/edit/:id" component={SaintForm} />
      <Route path="/admin/categories" component={AdminCategories} />
      <Route path="/admin/categories/new" component={CategoryForm} />
      <Route path="/admin/categories/edit/:id" component={CategoryForm} />
      <Route path="/admin/prayers" component={AdminPrayers} />
      <Route path="/admin/prayers/:id" component={PrayerEditorAdmin} />
      <Route path="/admin/header-customization" component={HeaderCustomization} />
      <Route path="/admin/novena-import" component={NovenaImport} />
      <Route path="/admin/testimonials" component={AdminTestimonials} />
      
      {/* 404 Not Found route */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router />
      <FloatingReminderButton />
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;

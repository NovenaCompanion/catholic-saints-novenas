import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Import FontAwesome
const fontAwesomeScript = document.createElement("link");
fontAwesomeScript.rel = "stylesheet";
fontAwesomeScript.href = "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css";
document.head.appendChild(fontAwesomeScript);

// Set page title
document.title = "My Novena Companion - Catholic Novena Prayers";

// Import Google Fonts
const googleFontsScript = document.createElement("link");
googleFontsScript.rel = "stylesheet";
googleFontsScript.href = "https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;600;700&family=Source+Sans+Pro:wght@400;600;700&display=swap";
document.head.appendChild(googleFontsScript);

createRoot(document.getElementById("root")!).render(<App />);

import { db } from "@db";
import { 
  categories, 
  saints, 
  saintCategories, 
  novenas,
  novenaPrayers,
  testimonials,
  rosaryNovenas,
  rosaryNovenaTexts,
  rosaryNovenaInfo,
  persistentImages,
  type Category, 
  type Saint, 
  type Novena,
  type NovenaPrayer,
  type Testimonial,
  type RosaryNovena,
  type RosaryNovenaInsert,
  type RosaryNovenaText,
  type RosaryNovenaTextInsert,
  type RosaryNovenaInfo,
  type RosaryNovenaInfoInsert,
  type PersistentImage,
  type PersistentImageInsert
} from "@shared/schema";
import { eq, and, inArray, desc, asc, sql, count } from "drizzle-orm";

export const storage = {
  // Category operations
  async getAllCategories(): Promise<(Category & { saintCount: number })[]> {
    const result = await db
      .select({
        id: categories.id,
        name: categories.name,
        description: categories.description,
        icon: categories.icon,
        iconBgColor: categories.iconBgColor,
        iconColor: categories.iconColor,
        imageUrl: categories.imageUrl,
        saintCount: count(saintCategories.saintId)
      })
      .from(categories)
      .leftJoin(saintCategories, and(
        eq(categories.id, saintCategories.categoryId),
        sql`${saintCategories.saintId} != 253` // Exclude Holy Rosary from category counts
      ))
      .where(sql`${categories.id} != 41`) // Exclude Holy Rosary category from categories list
      .groupBy(categories.id, categories.name, categories.description, categories.icon, categories.iconBgColor, categories.iconColor, categories.imageUrl)
      .orderBy(categories.name);
    
    return result;
  },
  
  async getCategoryById(categoryId: number): Promise<Category> {
    const category = await db.query.categories.findFirst({
      where: eq(categories.id, categoryId)
    });
    
    if (!category) {
      throw new Error(`Category with ID ${categoryId} not found`);
    }
    
    return category;
  },
  
  async createCategory(data: {
    name: string;
    description: string | null;
    icon: string;
    iconBgColor: string;
    iconColor: string;
    imageUrl?: string | null;
  }): Promise<Category> {
    const [category] = await db.insert(categories)
      .values({
        name: data.name,
        description: data.description,
        icon: data.icon,
        iconBgColor: data.iconBgColor,
        iconColor: data.iconColor,
        imageUrl: data.imageUrl
      })
      .returning();
      
    return category;
  },
  
  async updateCategory(
    categoryId: number, 
    data: {
      name: string;
      description: string | null;
      icon: string;
      iconBgColor: string;
      iconColor: string;
      imageUrl?: string | null;
    }
  ): Promise<Category> {
    const [updatedCategory] = await db.update(categories)
      .set({
        name: data.name,
        description: data.description,
        icon: data.icon,
        iconBgColor: data.iconBgColor,
        iconColor: data.iconColor,
        imageUrl: data.imageUrl
      })
      .where(eq(categories.id, categoryId))
      .returning();
      
    if (!updatedCategory) {
      throw new Error(`Category with ID ${categoryId} not found`);
    }
    
    return updatedCategory;
  },

  async getCategoryWithSaints(categoryId: number): Promise<Category & { saints: Saint[] }> {
    const category = await db.query.categories.findFirst({
      where: eq(categories.id, categoryId),
      with: {
        saintCategories: {
          with: {
            saint: true
          }
        }
      }
    });

    if (!category) {
      throw new Error(`Category with ID ${categoryId} not found`);
    }

    const saints = category.saintCategories.map(sc => sc.saint);
    return { ...category, saints };
  },

  // Saint operations
  async getAllSaints(): Promise<Saint[]> {
    return db.query.saints.findMany({
      where: sql`${saints.id} != 253`, // Exclude Holy Rosary from saints list
      orderBy: saints.name
    });
  },

  async getPopularSaints(): Promise<Saint[]> {
    return db.query.saints.findMany({
      where: and(eq(saints.isPopular, true), sql`${saints.id} != 253`), // Exclude Holy Rosary from popular saints
      orderBy: saints.name
    });
  },

  async getSaintsByCategory(categoryId: number): Promise<Saint[]> {
    const saintIds = await db.query.saintCategories.findMany({
      where: eq(saintCategories.categoryId, categoryId),
      columns: {
        saintId: true
      }
    });

    return db.query.saints.findMany({
      where: and(
        inArray(saints.id, saintIds.map(s => s.saintId)),
        sql`${saints.id} != 253` // Exclude Holy Rosary from category saints list
      ),
      orderBy: saints.name
    });
  },

  async getSaintById(saintId: number): Promise<Saint & { categories: Category[] }> {
    const saint = await db.query.saints.findFirst({
      where: eq(saints.id, saintId),
      with: {
        saintCategories: {
          with: {
            category: true
          }
        }
      }
    });

    if (!saint) {
      throw new Error(`Saint with ID ${saintId} not found`);
    }

    const categories = saint.saintCategories.map(sc => sc.category);
    return { ...saint, categories };
  },
  
  async createSaint(data: {
    name: string;
    title: string | null;
    description: string;
    imageUrl: string | null;
    feastDay: string | null;
    patronOf: string | null;
    born: string | null;
    died: string | null;
    prayer: string;
    isPopular: boolean;
    novenaLength?: number;
    categoryIds: number[];
  }): Promise<Saint> {
    // Insert the saint (no transaction needed for Neon serverless)
    const [saint] = await db.insert(saints)
      .values({
        name: data.name,
        title: data.title,
        description: data.description,
        imageUrl: data.imageUrl,
        feastDay: data.feastDay,
        patronOf: data.patronOf,
        born: data.born,
        died: data.died,
        prayer: data.prayer,
        isPopular: data.isPopular,
        ...(data.novenaLength && { novenaLength: data.novenaLength })
      })
      .returning();
      
    // Add category associations
    if (data.categoryIds && data.categoryIds.length > 0) {
      const categoryRelations = data.categoryIds.map(categoryId => ({
        saintId: saint.id,
        categoryId
      }));
      
      await db.insert(saintCategories)
        .values(categoryRelations);
    }
    
    return saint;
  },
  
  async updateSaint(
    saintId: number,
    data: {
      name: string;
      title: string | null;
      description: string;
      imageUrl: string | null;
      feastDay: string | null;
      patronOf: string | null;
      born: string | null;
      died: string | null;
      prayer: string;
      isPopular: boolean;
      novenaLength?: number;
      categoryIds: number[];
    }
  ): Promise<Saint> {
    // Update the saint (no transaction needed for Neon serverless)
    const [updatedSaint] = await db.update(saints)
      .set({
        name: data.name,
        title: data.title,
        description: data.description,
        imageUrl: data.imageUrl,
        feastDay: data.feastDay,
        patronOf: data.patronOf,
        born: data.born,
        died: data.died,
        prayer: data.prayer,
        isPopular: data.isPopular,
        ...(data.novenaLength ? { novenaLength: data.novenaLength } : {})
      })
      .where(eq(saints.id, saintId))
      .returning();
      
    if (!updatedSaint) {
      throw new Error(`Saint with ID ${saintId} not found`);
    }
    
    // Delete existing category associations
    await db.delete(saintCategories)
      .where(eq(saintCategories.saintId, saintId));
    
    // Add new category associations
    if (data.categoryIds && data.categoryIds.length > 0) {
      const categoryRelations = data.categoryIds.map(categoryId => ({
        saintId,
        categoryId
      }));
      
      await db.insert(saintCategories)
        .values(categoryRelations);
    }
    
    return updatedSaint;
  },

  // Novena operations
  async createNovena(userId: string, saintId: number, intention?: string): Promise<Novena> {
    // Get saint to determine novena length
    const saint = await this.getSaintById(saintId);
    const novenaLength = saint.novenaLength || 9;
    
    const [novena] = await db.insert(novenas)
      .values({
        userId,
        saintId,
        intention,
        startDate: new Date(),
        currentDay: 1,
        completedDays: [],
        isComplete: false
      })
      .returning();

    return novena;
  },

  async getUserNovenas(userId: string): Promise<Array<Novena & { saint: Saint }>> {
    return db.query.novenas.findMany({
      where: eq(novenas.userId, userId),
      with: {
        saint: true
      },
      orderBy: novenas.startDate
    });
  },

  async getNovena(novenaId: number): Promise<Novena & { saint: Saint }> {
    const novena = await db.query.novenas.findFirst({
      where: eq(novenas.id, novenaId),
      with: {
        saint: true
      }
    });

    if (!novena) {
      throw new Error(`Novena with ID ${novenaId} not found`);
    }

    return novena;
  },

  async updateNovenaProgress(novenaId: number, userId: string, day: number): Promise<Novena> {
    // First fetch the novena to check ownership and current state
    const novena = await db.query.novenas.findFirst({
      where: and(
        eq(novenas.id, novenaId),
        eq(novenas.userId, userId)
      ),
      with: {
        saint: true
      }
    });

    if (!novena) {
      throw new Error(`Novena with ID ${novenaId} not found for this user`);
    }

    // Determine novena length
    const novenaLength = novena.saint?.novenaLength || 9;

    // Parse completed days (handle both array and JSON string)
    let completedDays: number[] = [];
    if (typeof novena.completedDays === 'string') {
      try {
        completedDays = JSON.parse(novena.completedDays);
      } catch {
        completedDays = [];
      }
    } else if (Array.isArray(novena.completedDays)) {
      completedDays = [...novena.completedDays];
    }

    // Add the day if not already completed
    if (!completedDays.includes(day)) {
      completedDays.push(day);
    }
    
    // Calculate the new current day
    const nextDay = Math.max(...completedDays) + 1;
    const isComplete = nextDay > novenaLength;
    
    // Update the novena
    const [updatedNovena] = await db.update(novenas)
      .set({
        completedDays,
        currentDay: isComplete ? novenaLength : nextDay,
        isComplete
      })
      .where(eq(novenas.id, novenaId))
      .returning();

    return updatedNovena;
  },

  async updateNovenaIntention(novenaId: number, userId: string, intention: string): Promise<Novena> {
    const [updatedNovena] = await db.update(novenas)
      .set({
        intention
      })
      .where(and(
        eq(novenas.id, novenaId),
        eq(novenas.userId, userId)
      ))
      .returning();

    if (!updatedNovena) {
      throw new Error(`Novena with ID ${novenaId} not found for this user`);
    }

    return updatedNovena;
  },

  // Novena Prayer operations
  async createNovenaPrayer(saintId: number, day: number, content: string, title?: string): Promise<NovenaPrayer> {
    const [prayer] = await db.insert(novenaPrayers)
      .values({
        saintId,
        day,
        content,
        title,
        createdAt: new Date()
      })
      .returning();

    return prayer;
  },

  async getSaintNovenaPrayers(saintId: number): Promise<NovenaPrayer[]> {
    return db.query.novenaPrayers.findMany({
      where: eq(novenaPrayers.saintId, saintId),
      orderBy: novenaPrayers.day
    });
  },

  async getNovenaPrayer(saintId: number, day: number): Promise<NovenaPrayer | null> {
    const prayer = await db.query.novenaPrayers.findFirst({
      where: and(
        eq(novenaPrayers.saintId, saintId),
        eq(novenaPrayers.day, day)
      )
    });
    
    return prayer || null;
  },

  async updateNovenaPrayer(id: number, content: string, title?: string): Promise<NovenaPrayer> {
    const [updatedPrayer] = await db.update(novenaPrayers)
      .set({
        content,
        title,
      })
      .where(eq(novenaPrayers.id, id))
      .returning();

    if (!updatedPrayer) {
      throw new Error(`Novena prayer with ID ${id} not found`);
    }

    return updatedPrayer;
  },

  async deleteNovenaPrayer(id: number): Promise<void> {
    await db.delete(novenaPrayers)
      .where(eq(novenaPrayers.id, id));
  },

  // Testimonial operations
  async createTestimonial(
    userId: string, 
    saintId: number, 
    data: { 
      title: string; 
      content: string; 
      favorsReceived: string;
    }
  ): Promise<Testimonial> {
    const [testimonial] = await db.insert(testimonials)
      .values({
        userId,
        saintId,
        title: data.title,
        content: data.content,
        favorsReceived: data.favorsReceived,
        approved: false, // New testimonials start as unapproved
        createdAt: new Date()
      })
      .returning();

    return testimonial;
  },

  async getSaintTestimonials(saintId: number, onlyApproved: boolean = true): Promise<Testimonial[]> {
    const query = onlyApproved 
      ? and(eq(testimonials.saintId, saintId), eq(testimonials.approved, true))
      : eq(testimonials.saintId, saintId);
      
    return db.query.testimonials.findMany({
      where: query,
      orderBy: desc(testimonials.createdAt)
    });
  },

  async getUserTestimonials(userId: string): Promise<Array<Testimonial & { saint: Saint }>> {
    return db.query.testimonials.findMany({
      where: eq(testimonials.userId, userId),
      with: {
        saint: true
      },
      orderBy: desc(testimonials.createdAt)
    });
  },

  async approveTestimonial(testimonialId: number): Promise<Testimonial> {
    const [testimonial] = await db.update(testimonials)
      .set({ approved: true })
      .where(eq(testimonials.id, testimonialId))
      .returning();
      
    if (!testimonial) {
      throw new Error(`Testimonial with ID ${testimonialId} not found`);
    }
    
    return testimonial;
  },

  async deleteTestimonial(testimonialId: number): Promise<void> {
    await db.delete(testimonials)
      .where(eq(testimonials.id, testimonialId));
  },

  // Saint Category operations
  async addSaintToCategory(saintId: number, categoryId: number): Promise<void> {
    // Check if the relation already exists
    const existingRelation = await db.query.saintCategories.findFirst({
      where: and(
        eq(saintCategories.saintId, saintId),
        eq(saintCategories.categoryId, categoryId)
      )
    });

    if (!existingRelation) {
      // Only insert if the relation doesn't already exist
      await db.insert(saintCategories)
        .values({
          saintId,
          categoryId
        });
    }
  },

  async removeSaintFromCategory(saintId: number, categoryId: number): Promise<void> {
    await db.delete(saintCategories)
      .where(and(
        eq(saintCategories.saintId, saintId),
        eq(saintCategories.categoryId, categoryId)
      ));
  },

  // 54-Day Rosary Novena operations
  async getCurrentRosaryNovena(userId: string): Promise<RosaryNovena | null> {
    const novena = await db.query.rosaryNovenas.findFirst({
      where: and(
        eq(rosaryNovenas.userId, userId),
        eq(rosaryNovenas.isComplete, false)
      ),
      orderBy: desc(rosaryNovenas.startDate)
    });
    
    return novena || null;
  },

  async getRosaryNovenaById(novenaId: number): Promise<RosaryNovena | null> {
    const novena = await db.query.rosaryNovenas.findFirst({
      where: eq(rosaryNovenas.id, novenaId)
    });
    
    return novena || null;
  },

  async createRosaryNovena(data: RosaryNovenaInsert): Promise<RosaryNovena> {
    const insertData = {
      userId: data.userId,
      startDate: data.startDate,
      currentDay: data.currentDay || 1,
      completedDays: [] as any,
      intentions: data.intentions,
      isComplete: data.isComplete || false,
      phase: data.phase || 'petition'
    };
    
    const [novena] = await db.insert(rosaryNovenas).values(insertData).returning();
    return novena;
  },

  async markRosaryNovenaDay(novenaId: number, day: number): Promise<RosaryNovena> {
    // First get the current novena
    const currentNovena = await this.getRosaryNovenaById(novenaId);
    if (!currentNovena) {
      throw new Error(`Rosary novena with ID ${novenaId} not found`);
    }

    // Parse completed days (handle both array and JSON string)
    let completedDays: number[] = [];
    if (typeof currentNovena.completedDays === 'string') {
      try {
        completedDays = JSON.parse(currentNovena.completedDays);
      } catch {
        completedDays = [];
      }
    } else if (Array.isArray(currentNovena.completedDays)) {
      completedDays = currentNovena.completedDays;
    }

    // Add the day if not already completed
    if (!completedDays.includes(day)) {
      completedDays.push(day);
    }

    // Determine phase and completion status
    const phase = day <= 27 ? 'petition' : 'thanksgiving';
    const isComplete = completedDays.length >= 54;
    const currentDay = Math.min(day + 1, 54);

    // Update the novena
    const [updatedNovena] = await db.update(rosaryNovenas)
      .set({
        completedDays: completedDays.sort((a, b) => a - b) as any,
        currentDay,
        phase,
        isComplete
      })
      .where(eq(rosaryNovenas.id, novenaId))
      .returning();

    return updatedNovena;
  },

  async getRosaryNovenaText(day: number): Promise<RosaryNovenaText | null> {
    const text = await db.query.rosaryNovenaTexts.findFirst({
      where: eq(rosaryNovenaTexts.day, day)
    });
    
    return text || null;
  },

  async createRosaryNovenaText(data: RosaryNovenaTextInsert): Promise<RosaryNovenaText> {
    const [text] = await db.insert(rosaryNovenaTexts).values(data).returning();
    return text;
  },

  async getRosaryNovenaInfo(): Promise<any[]> {
    const info = await db.query.rosaryNovenaInfo.findMany({
      orderBy: asc(rosaryNovenaInfo.order)
    });
    
    return info;
  },

  async getRosaryNovenaInfoByType(type: string): Promise<any | null> {
    const info = await db.query.rosaryNovenaInfo.findFirst({
      where: eq(rosaryNovenaInfo.type, type)
    });
    
    return info || null;
  },

  async createRosaryNovenaInfo(data: any): Promise<any> {
    const [info] = await db.insert(rosaryNovenaInfo).values(data).returning();
    return info;
  },

  // Persistent Image operations
  async saveImage(type: string, imageData: string, mimeType: string, originalName?: string, size?: number): Promise<PersistentImage> {
    // First, check if an image of this type already exists and delete it
    await db.delete(persistentImages).where(eq(persistentImages.type, type));
    
    // Insert the new image
    const [image] = await db.insert(persistentImages).values({
      type,
      data: imageData,
      mimeType,
      originalName,
      size,
      updatedAt: new Date()
    }).returning();
    
    return image;
  },

  async getImage(type: string): Promise<PersistentImage | null> {
    const image = await db.query.persistentImages.findFirst({
      where: eq(persistentImages.type, type)
    });
    
    return image || null;
  },

  async deleteImage(type: string): Promise<void> {
    await db.delete(persistentImages).where(eq(persistentImages.type, type));
  },

  // Prayer management methods (moved from existing position in file)
  async getSaintPrayers(saintId: number): Promise<NovenaPrayer[]> {
    const prayers = await db.query.novenaPrayers.findMany({
      where: eq(novenaPrayers.saintId, saintId),
      orderBy: asc(novenaPrayers.day)
    });
    
    return prayers;
  },

  async updatePrayer(prayerId: number, content: string): Promise<void> {
    await db.update(novenaPrayers)
      .set({ content })
      .where(eq(novenaPrayers.id, prayerId));
  }
};

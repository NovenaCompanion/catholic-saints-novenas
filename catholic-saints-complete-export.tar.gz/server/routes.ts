import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  novenaInsertSchema, 
  novenaPrayerInsertSchema, 
  categoryInsertSchema, 
  saintInsertSchema,
  testimonialInsertSchema,
  rosaryNovenaInsertSchema,
  rosaryNovenaTextInsertSchema
} from "@shared/schema";
import { z } from "zod";
import { upload, handleMulterError, getUploadedFileUrl } from "./upload";
import { db } from "@db";
import { sql } from "drizzle-orm";

// Helper to generate a userId for anonymous users
const getUserId = (req: Request): string => {
  if (!req.headers["x-user-id"]) {
    // Generate a random user ID if none is provided
    req.headers["x-user-id"] = `user_${Math.random().toString(36).substring(2, 15)}`;
  }
  return req.headers["x-user-id"] as string;
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Apply multer error handling middleware
  app.use(handleMulterError);

  // Image Upload Endpoints - Database Storage
  app.post("/api/upload/categories", upload.single("image"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No image file provided" });
      }
      
      // Convert file to base64
      const fs = await import('fs');
      const imageBuffer = fs.readFileSync(req.file.path);
      const base64Data = imageBuffer.toString('base64');
      const dataUrl = `data:${req.file.mimetype};base64,${base64Data}`;
      
      // Save to database
      await storage.saveImage('category', base64Data, req.file.mimetype, req.file.originalname, req.file.size);
      
      // Clean up temporary file
      fs.unlinkSync(req.file.path);
      
      return res.json({ url: dataUrl });
    } catch (error) {
      console.error("Error uploading category image:", error);
      return res.status(500).json({ message: "Failed to upload image" });
    }
  });

  app.post("/api/upload/saints", upload.single("image"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No image file provided" });
      }
      
      // Convert file to base64
      const fs = await import('fs');
      const imageBuffer = fs.readFileSync(req.file.path);
      const base64Data = imageBuffer.toString('base64');
      const dataUrl = `data:${req.file.mimetype};base64,${base64Data}`;
      
      // Save to database
      await storage.saveImage('universal-saint', base64Data, req.file.mimetype, req.file.originalname, req.file.size);
      
      // Clean up temporary file
      fs.unlinkSync(req.file.path);
      
      return res.json({ url: dataUrl });
    } catch (error) {
      console.error("Error uploading saint image:", error);
      return res.status(500).json({ message: "Failed to upload image" });
    }
  });

  app.post("/api/upload/universal-saint", upload.single("image"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No image file provided" });
      }
      
      // Convert file to base64
      const fs = await import('fs');
      const imageBuffer = fs.readFileSync(req.file.path);
      const base64Data = imageBuffer.toString('base64');
      const dataUrl = `data:${req.file.mimetype};base64,${base64Data}`;
      
      // Save to database
      await storage.saveImage('universal-saint', base64Data, req.file.mimetype, req.file.originalname, req.file.size);
      
      // Clean up temporary file
      fs.unlinkSync(req.file.path);
      
      return res.json({ url: dataUrl });
    } catch (error) {
      console.error("Error uploading universal saint image:", error);
      return res.status(500).json({ message: "Failed to upload image" });
    }
  });

  app.post("/api/upload/category", upload.single("image"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No image file provided" });
      }
      
      // Convert file to base64
      const fs = await import('fs');
      const imageBuffer = fs.readFileSync(req.file.path);
      const base64Data = imageBuffer.toString('base64');
      const dataUrl = `data:${req.file.mimetype};base64,${base64Data}`;
      
      // Save to database
      await storage.saveImage('category', base64Data, req.file.mimetype, req.file.originalname, req.file.size);
      
      // Clean up temporary file
      fs.unlinkSync(req.file.path);
      
      return res.json({ url: dataUrl });
    } catch (error) {
      console.error("Error uploading category image:", error);
      return res.status(500).json({ message: "Failed to upload image" });
    }
  });

  app.post("/api/upload/header", upload.single("image"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No image file provided" });
      }
      
      // Convert file to base64
      const fs = await import('fs');
      const imageBuffer = fs.readFileSync(req.file.path);
      const base64Data = imageBuffer.toString('base64');
      const dataUrl = `data:${req.file.mimetype};base64,${base64Data}`;
      
      // Save to database
      await storage.saveImage('header', base64Data, req.file.mimetype, req.file.originalname, req.file.size);
      
      // Clean up temporary file
      fs.unlinkSync(req.file.path);
      
      return res.json({ url: dataUrl });
    } catch (error) {
      console.error("Error uploading header image:", error);
      return res.status(500).json({ message: "Failed to upload image" });
    }
  });

  // Universal saint image upload (duplicate - should be removed)
  app.post("/api/upload/universal-saint-duplicate", upload.single("image"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No image file provided" });
      }
      
      // Convert file to base64
      const fs = await import('fs');
      const imageBuffer = fs.readFileSync(req.file.path);
      const base64Data = imageBuffer.toString('base64');
      const dataUrl = `data:${req.file.mimetype};base64,${base64Data}`;
      
      // Save to database
      await storage.saveImage('universal-saint', base64Data, req.file.mimetype, req.file.originalname, req.file.size);
      
      // Clean up temporary file
      fs.unlinkSync(req.file.path);
      
      return res.json({ url: dataUrl });
    } catch (error) {
      console.error("Error uploading universal saint image:", error);
      return res.status(500).json({ message: "Failed to upload image" });
    }
  });

  app.post("/api/upload/header-duplicate", upload.single("image"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No image file provided" });
      }
      
      // Convert file to base64
      const fs = await import('fs');
      const imageBuffer = fs.readFileSync(req.file.path);
      const base64Data = imageBuffer.toString('base64');
      const dataUrl = `data:${req.file.mimetype};base64,${base64Data}`;
      
      // Save to database
      await storage.saveImage('header', base64Data, req.file.mimetype, req.file.originalname, req.file.size);
      
      // Clean up temporary file
      fs.unlinkSync(req.file.path);
      
      return res.json({ url: dataUrl });
    } catch (error) {
      console.error("Error uploading header image:", error);
      return res.status(500).json({ message: "Failed to upload image" });
    }
  });

  // Image retrieval endpoints
  app.get("/api/images/:type", async (req, res) => {
    try {
      const { type } = req.params;
      const image = await storage.getImage(type);
      
      if (!image) {
        return res.status(404).json({ message: "Image not found" });
      }
      
      // Return the data URL for easy use in frontend
      const dataUrl = `data:${image.mimeType};base64,${image.data}`;
      return res.json({ url: dataUrl, originalName: image.originalName, size: image.size });
    } catch (error) {
      console.error("Error retrieving image:", error);
      return res.status(500).json({ message: "Failed to retrieve image" });
    }
  });

  app.delete("/api/images/:type", async (req, res) => {
    try {
      const { type } = req.params;
      await storage.deleteImage(type);
      return res.json({ message: "Image deleted successfully" });
    } catch (error) {
      console.error("Error deleting image:", error);
      return res.status(500).json({ message: "Failed to delete image" });
    }
  });

  // Get all categories
  app.get("/api/categories", async (_req, res) => {
    try {
      const categories = await storage.getAllCategories();
      return res.json(categories);
    } catch (error) {
      console.error("Error fetching categories:", error);
      return res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  // Get saints by category
  app.get("/api/categories/:id/saints", async (req, res) => {
    try {
      const categoryId = parseInt(req.params.id, 10);
      if (isNaN(categoryId)) {
        return res.status(400).json({ message: "Invalid category ID" });
      }

      const saints = await storage.getSaintsByCategory(categoryId);
      return res.json(saints);
    } catch (error) {
      console.error(`Error fetching saints for category ${req.params.id}:`, error);
      return res.status(500).json({ message: "Failed to fetch saints for category" });
    }
  });

  // Get all saints
  app.get("/api/saints", async (_req, res) => {
    try {
      const saints = await storage.getAllSaints();
      return res.json(saints);
    } catch (error) {
      console.error("Error fetching saints:", error);
      return res.status(500).json({ message: "Failed to fetch saints" });
    }
  });

  // Get popular saints
  app.get("/api/saints/popular", async (_req, res) => {
    try {
      const popularSaints = await storage.getPopularSaints();
      return res.json(popularSaints);
    } catch (error) {
      console.error("Error fetching popular saints:", error);
      return res.status(500).json({ message: "Failed to fetch popular saints" });
    }
  });

  // Get saint by ID
  app.get("/api/saints/:id", async (req, res) => {
    try {
      const saintId = parseInt(req.params.id, 10);
      if (isNaN(saintId)) {
        return res.status(400).json({ message: "Invalid saint ID" });
      }

      const saint = await storage.getSaintById(saintId);
      return res.json(saint);
    } catch (error) {
      console.error(`Error fetching saint ${req.params.id}:`, error);
      return res.status(500).json({ message: "Failed to fetch saint" });
    }
  });

  // Create a novena
  app.post("/api/novenas", async (req, res) => {
    try {
      const userId = getUserId(req);
      
      // Validate request body
      const schema = novenaInsertSchema.pick({ saintId: true, intention: true });
      const { saintId, intention } = schema.parse(req.body);

      const novena = await storage.createNovena(userId, saintId, intention || undefined);
      return res.status(201).json(novena);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error creating novena:", error);
      return res.status(500).json({ message: "Failed to create novena" });
    }
  });

  // Get user's novenas
  app.get("/api/novenas", async (req, res) => {
    try {
      const userId = getUserId(req);
      const novenas = await storage.getUserNovenas(userId);
      return res.json(novenas);
    } catch (error) {
      console.error("Error fetching novenas:", error);
      return res.status(500).json({ message: "Failed to fetch novenas" });
    }
  });

  // Get novena by ID
  app.get("/api/novenas/:id", async (req, res) => {
    try {
      const novenaId = parseInt(req.params.id, 10);
      if (isNaN(novenaId)) {
        return res.status(400).json({ message: "Invalid novena ID" });
      }

      const novena = await storage.getNovena(novenaId);
      return res.json(novena);
    } catch (error) {
      console.error(`Error fetching novena ${req.params.id}:`, error);
      return res.status(500).json({ message: "Failed to fetch novena" });
    }
  });

  // Update novena progress
  app.patch("/api/novenas/:id/progress", async (req, res) => {
    try {
      const novenaId = parseInt(req.params.id, 10);
      if (isNaN(novenaId)) {
        return res.status(400).json({ message: "Invalid novena ID" });
      }

      const userId = getUserId(req);
      
      // First get the novena to check its length for validation
      const novena = await storage.getNovena(novenaId);
      const novenaLength = novena.saint?.novenaLength || 9;
      
      // Dynamic validation based on actual novena length
      const schema = z.object({ day: z.number().min(1).max(novenaLength) });
      const { day } = schema.parse(req.body);

      const updatedNovena = await storage.updateNovenaProgress(novenaId, userId, day);
      return res.json(updatedNovena);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error(`Error updating novena progress for ${req.params.id}:`, error);
      return res.status(500).json({ message: "Failed to update novena progress" });
    }
  });

  // Update novena intention
  app.patch("/api/novenas/:id/intention", async (req, res) => {
    try {
      const novenaId = parseInt(req.params.id, 10);
      if (isNaN(novenaId)) {
        return res.status(400).json({ message: "Invalid novena ID" });
      }

      const userId = getUserId(req);
      const schema = z.object({ intention: z.string().min(1) });
      const { intention } = schema.parse(req.body);

      const updatedNovena = await storage.updateNovenaIntention(novenaId, userId, intention);
      return res.json(updatedNovena);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error(`Error updating novena intention for ${req.params.id}:`, error);
      return res.status(500).json({ message: "Failed to update novena intention" });
    }
  });

  // Novena Prayers Routes
  
  // Get all prayers for a saint's novena
  app.get("/api/saints/:id/prayers", async (req, res) => {
    try {
      const saintId = parseInt(req.params.id, 10);
      if (isNaN(saintId)) {
        return res.status(400).json({ message: "Invalid saint ID" });
      }

      const prayers = await storage.getSaintNovenaPrayers(saintId);
      return res.json(prayers);
    } catch (error) {
      console.error(`Error fetching prayers for saint ${req.params.id}:`, error);
      return res.status(500).json({ message: "Failed to fetch novena prayers" });
    }
  });
  
  // Testimonial Routes
  
  // Get testimonials for a saint
  app.get("/api/saints/:id/testimonials", async (req, res) => {
    try {
      const saintId = parseInt(req.params.id, 10);
      if (isNaN(saintId)) {
        return res.status(400).json({ message: "Invalid saint ID" });
      }
      
      const onlyApproved = req.query.all !== 'true';
      const testimonials = await storage.getSaintTestimonials(saintId, onlyApproved);
      return res.json(testimonials);
    } catch (error) {
      console.error(`Error fetching testimonials for saint ${req.params.id}:`, error);
      return res.status(500).json({ message: "Failed to fetch testimonials" });
    }
  });
  
  // Create a new testimonial for a saint
  app.post("/api/saints/:id/testimonials", async (req, res) => {
    try {
      const saintId = parseInt(req.params.id, 10);
      if (isNaN(saintId)) {
        return res.status(400).json({ message: "Invalid saint ID" });
      }
      
      const userId = getUserId(req);
      
      // Validate request body
      const schema = z.object({
        title: z.string().min(3).max(100),
        content: z.string().min(10),
        favorsReceived: z.string().min(10)
      });
      
      const { title, content, favorsReceived } = schema.parse(req.body);
      
      const testimonial = await storage.createTestimonial(userId, saintId, {
        title,
        content,
        favorsReceived
      });
      
      return res.status(201).json(testimonial);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error(`Error creating testimonial for saint ${req.params.id}:`, error);
      return res.status(500).json({ message: "Failed to create testimonial" });
    }
  });

  // Get specific day prayer for a saint
  app.get("/api/saints/:id/prayers/:day", async (req, res) => {
    try {
      const saintId = parseInt(req.params.id, 10);
      const day = parseInt(req.params.day, 10);
      
      if (isNaN(saintId)) {
        return res.status(400).json({ message: "Invalid saint ID" });
      }
      
      // Get the saint to determine maximum day
      const saint = await storage.getSaintById(saintId);
      const maxDay = saint.novenaLength || 9;
      
      if (isNaN(day) || day < 1 || day > maxDay) {
        return res.status(400).json({ message: `Day must be between 1 and ${maxDay}` });
      }

      const prayer = await storage.getNovenaPrayer(saintId, day);
      
      if (!prayer) {
        // If no specific prayer exists for this day, return the generic prayer from the saint
        const saint = await storage.getSaintById(saintId);
        return res.json({
          id: 0, // Placeholder ID
          saintId,
          day,
          title: `Day ${day} Prayer`,
          content: saint.prayer,
          createdAt: new Date().toISOString()
        });
      }
      
      return res.json(prayer);
    } catch (error) {
      console.error(`Error fetching prayer for saint ${req.params.id}, day ${req.params.day}:`, error);
      return res.status(500).json({ message: "Failed to fetch novena prayer" });
    }
  });

  // Create or update a prayer for a specific day
  app.post("/api/saints/:id/prayers/:day", async (req, res) => {
    try {
      const saintId = parseInt(req.params.id, 10);
      const day = parseInt(req.params.day, 10);
      
      if (isNaN(saintId)) {
        return res.status(400).json({ message: "Invalid saint ID" });
      }
      
      // Get the saint to determine maximum day
      const saint = await storage.getSaintById(saintId);
      const maxDay = saint.novenaLength || 9;
      
      if (isNaN(day) || day < 1 || day > maxDay) {
        return res.status(400).json({ message: `Day must be between 1 and ${maxDay}` });
      }

      // Validate request body
      const schema = z.object({
        title: z.string().optional(),
        content: z.string().min(10)
      });
      
      const { title, content } = schema.parse(req.body);
      
      // Check if prayer already exists
      const existingPrayer = await storage.getNovenaPrayer(saintId, day);
      
      let prayer;
      if (existingPrayer) {
        // Update existing prayer
        prayer = await storage.updateNovenaPrayer(existingPrayer.id, content, title);
      } else {
        // Create new prayer
        prayer = await storage.createNovenaPrayer(saintId, day, content, title);
      }
      
      return res.status(201).json(prayer);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error(`Error creating/updating prayer for saint ${req.params.id}, day ${req.params.day}:`, error);
      return res.status(500).json({ message: "Failed to create/update novena prayer" });
    }
  });

  // Delete a prayer
  app.delete("/api/prayers/:id", async (req, res) => {
    try {
      const prayerId = parseInt(req.params.id, 10);
      if (isNaN(prayerId)) {
        return res.status(400).json({ message: "Invalid prayer ID" });
      }

      await storage.deleteNovenaPrayer(prayerId);
      return res.status(204).send();
    } catch (error) {
      console.error(`Error deleting prayer ${req.params.id}:`, error);
      return res.status(500).json({ message: "Failed to delete novena prayer" });
    }
  });

  // Admin Category Routes

  // Get category by ID
  app.get("/api/categories/:id", async (req, res) => {
    try {
      const categoryId = parseInt(req.params.id, 10);
      if (isNaN(categoryId)) {
        return res.status(400).json({ message: "Invalid category ID" });
      }

      const category = await storage.getCategoryById(categoryId);
      return res.json(category);
    } catch (error) {
      console.error(`Error fetching category ${req.params.id}:`, error);
      return res.status(500).json({ message: "Failed to fetch category" });
    }
  });

  // Create a new category
  app.post("/api/categories", async (req, res) => {
    try {
      // Validate request body
      const schema = categoryInsertSchema.extend({
        description: z.string().nullable(),
      });
      
      const parsedData = schema.parse(req.body);
      
      const category = await storage.createCategory({
        name: parsedData.name,
        description: parsedData.description,
        icon: parsedData.icon || "fas fa-folder",
        iconBgColor: parsedData.iconBgColor || "#f0f9ff",
        iconColor: parsedData.iconColor || "#0ea5e9"
      });

      return res.status(201).json(category);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error creating category:", error);
      return res.status(500).json({ message: "Failed to create category" });
    }
  });

  // Update a category
  app.put("/api/categories/:id", async (req, res) => {
    try {
      const categoryId = parseInt(req.params.id, 10);
      if (isNaN(categoryId)) {
        return res.status(400).json({ message: "Invalid category ID" });
      }

      // Validate request body
      const schema = categoryInsertSchema.extend({
        description: z.string().nullable(),
      });
      
      const parsedData = schema.parse(req.body);
      
      const category = await storage.updateCategory(categoryId, {
        name: parsedData.name,
        description: parsedData.description,
        icon: parsedData.icon || "fas fa-folder",
        iconBgColor: parsedData.iconBgColor || "#f0f9ff",
        iconColor: parsedData.iconColor || "#0ea5e9"
      });

      return res.json(category);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error(`Error updating category ${req.params.id}:`, error);
      return res.status(500).json({ message: "Failed to update category" });
    }
  });

  // Admin Saint Routes

  // Create a new saint
  app.post("/api/saints", async (req, res) => {
    try {
      // Validate request body
      const schema = saintInsertSchema.extend({
        title: z.string().nullable(),
        imageUrl: z.string().nullable(),
        feastDay: z.string().nullable(),
        patronOf: z.string().nullable(), 
        born: z.string().nullable(),
        died: z.string().nullable(),
        novenaLength: z.number().optional(),
        categoryIds: z.array(z.number()).default([])
      });
      
      const parsedData = schema.parse(req.body);
      
      const saint = await storage.createSaint({
        name: parsedData.name,
        title: parsedData.title,
        description: parsedData.description,
        imageUrl: parsedData.imageUrl,
        feastDay: parsedData.feastDay,
        patronOf: parsedData.patronOf,
        born: parsedData.born,
        died: parsedData.died,
        prayer: parsedData.prayer,
        isPopular: parsedData.isPopular ?? false,
        novenaLength: parsedData.novenaLength,
        categoryIds: parsedData.categoryIds
      });

      return res.status(201).json(saint);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error creating saint:", error);
      return res.status(500).json({ message: "Failed to create saint" });
    }
  });

  // Update a saint
  app.put("/api/saints/:id", async (req, res) => {
    try {
      const saintId = parseInt(req.params.id, 10);
      if (isNaN(saintId)) {
        return res.status(400).json({ message: "Invalid saint ID" });
      }

      // Validate request body
      const schema = saintInsertSchema.extend({
        title: z.string().nullable(),
        imageUrl: z.string().nullable(),
        feastDay: z.string().nullable(),
        patronOf: z.string().nullable(), 
        born: z.string().nullable(),
        died: z.string().nullable(),
        novenaLength: z.number().optional(),
        categoryIds: z.array(z.number()).default([])
      });
      
      const parsedData = schema.parse(req.body);
      
      const saint = await storage.updateSaint(saintId, {
        name: parsedData.name,
        title: parsedData.title,
        description: parsedData.description,
        imageUrl: parsedData.imageUrl,
        feastDay: parsedData.feastDay,
        patronOf: parsedData.patronOf,
        born: parsedData.born,
        died: parsedData.died,
        prayer: parsedData.prayer,
        isPopular: parsedData.isPopular ?? false,
        novenaLength: parsedData.novenaLength,
        categoryIds: parsedData.categoryIds
      });

      return res.json(saint);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error(`Error updating saint ${req.params.id}:`, error);
      return res.status(500).json({ message: "Failed to update saint" });
    }
  });

  // Novena import utility routes
  app.post("/api/utils/preview-novena", async (req, res) => {
    try {
      const { url } = req.body;
      
      if (!url) {
        return res.status(400).json({ error: "URL is required" });
      }
      
      // Fetch content from the provided URL
      const response = await fetch(url);
      const html = await response.text();
      
      // Extract main content (simple extraction - can be enhanced)
      let content = html;
      // Remove script and style tags
      content = content.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, "");
      content = content.replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, "");
      // Remove HTML tags but keep line breaks
      content = content.replace(/<\/p>/gi, "\n\n");
      content = content.replace(/<br\s*\/?>/gi, "\n");
      content = content.replace(/<li>/gi, "• ");
      content = content.replace(/<\/li>/gi, "\n");
      content = content.replace(/<\/h[1-6]>/gi, "\n\n");
      content = content.replace(/<\/div>/gi, "\n");
      content = content.replace(/<[^>]*>/g, "");
      // Decode HTML entities
      content = content.replace(/&nbsp;/g, " ");
      content = content.replace(/&amp;/g, "&");
      content = content.replace(/&lt;/g, "<");
      content = content.replace(/&gt;/g, ">");
      content = content.replace(/&quot;/g, '"');
      // Trim whitespace and remove excessive line breaks
      content = content.replace(/\n{3,}/g, "\n\n");
      content = content.trim();
      
      res.status(200).json({ content });
    } catch (error) {
      console.error("Error fetching novena content:", error);
      res.status(500).json({ error: "Failed to fetch novena content" });
    }
  });
  
  app.post("/api/utils/extract-prayers", async (req, res) => {
    try {
      const { content } = req.body;
      
      if (!content) {
        return res.status(400).json({ error: "Content is required" });
      }
      
      // Split content by day markers (this is a simple implementation that can be enhanced)
      const dayRegexes = [
        new RegExp("Day\\s+(\\d+)[:\\s]+(.*?)(?=Day\\s+\\d+|$)", "gi"),  // "Day 1: ..." format
        new RegExp("(\\d+)[a-z]{0,2}\\s+Day[:\\s]+(.*?)(?=\\d+[a-z]{0,2}\\s+Day|$)", "gi"),  // "1st Day: ..." format
        new RegExp("Day\\s+(\\d+)\\s+of\\s+\\d+[:\\s]+(.*?)(?=Day\\s+\\d+\\s+of\\s+\\d+|$)", "gi"),  // "Day 1 of 9: ..." format
      ];
      
      let prayers: {day: number, title: string | null, content: string}[] = [];
      let matched = false;
      
      // Try each regex pattern until we find one that works
      for (const regex of dayRegexes) {
        let matches;
        const tempPrayers: typeof prayers = [];
        regex.lastIndex = 0; // Reset regex state
        
        while ((matches = regex.exec(content)) !== null) {
          const day = parseInt(matches[1]);
          const prayerContent = matches[2].trim();
          
          // Extract title if present (first line as title)
          let title: string | null = null;
          let actualContent = prayerContent;
          
          const lines = prayerContent.split("\n");
          if (lines.length > 1 && lines[0].length < 100 && !lines[0].startsWith("•") && !lines[0].startsWith("-")) {
            title = lines[0].trim();
            actualContent = lines.slice(1).join("\n").trim();
          }
          
          tempPrayers.push({ day, title, content: actualContent });
        }
        
        if (tempPrayers.length > 0) {
          prayers = tempPrayers;
          matched = true;
          break;
        }
      }
      
      // If standard patterns didn't work, try to infer day structure from the content
      if (!matched) {
        // Split by double newlines assuming each paragraph might be a different day
        const sections = content.split(/\n\n+/);
        if (sections.length >= 9) {
          // Assume the content might be organized by days even without explicit "Day X" markers
          for (let i = 0; i < Math.min(sections.length, 54); i++) {
            prayers.push({
              day: i + 1,
              title: null,
              content: sections[i].trim()
            });
          }
        }
      }
      
      // Sort by day number
      prayers = prayers.sort((a, b) => a.day - b.day);
      
      if (prayers.length === 0) {
        return res.status(404).json({ error: "Could not extract daily prayers from the content" });
      }
      
      res.status(200).json({ prayers });
    } catch (error) {
      console.error("Error extracting prayers:", error);
      res.status(500).json({ error: "Failed to extract prayers" });
    }
  });
  
  // Import novena prayers
  app.post("/api/novena-prayers/import", async (req, res) => {
    try {
      const { saintId, prayers } = req.body;
      
      if (!saintId || !prayers || !Array.isArray(prayers) || prayers.length === 0) {
        return res.status(400).json({ error: "Invalid import data" });
      }
      
      // First, delete any existing prayers for this saint
      const existingPrayers = await storage.getSaintNovenaPrayers(saintId);
      for (const prayer of existingPrayers) {
        await storage.deleteNovenaPrayer(prayer.id);
      }
      
      // Then create the new prayers
      const importedPrayers = [];
      for (const prayer of prayers) {
        const { day, title, content } = prayer;
        if (!day || !content) continue;
        
        const newPrayer = await storage.createNovenaPrayer(
          saintId,
          day,
          content,
          title || undefined
        );
        
        importedPrayers.push(newPrayer);
      }
      
      // Update the saint's novena length if necessary
      if (importedPrayers.length > 0) {
        const maxDay = Math.max(...importedPrayers.map(p => p.day));
        if (maxDay > 9) {
          // Get the saint
          const saint = await storage.getSaintById(saintId);
          
          // Only update if the current novenaLength is less than the number of imported prayers
          if (!saint.novenaLength || saint.novenaLength < maxDay) {
            // Set default values for fields that might be null
            const isPopular = typeof saint.isPopular === 'boolean' ? saint.isPopular : false;
            
            await storage.updateSaint(saintId, {
              name: saint.name,
              title: saint.title,
              description: saint.description,
              imageUrl: saint.imageUrl,
              feastDay: saint.feastDay,
              patronOf: saint.patronOf,
              born: saint.born,
              died: saint.died,
              prayer: saint.prayer,
              isPopular: isPopular,
              novenaLength: maxDay,
              categoryIds: [] // We're only updating the novenaLength
            });
          }
        }
      }
      
      res.status(200).json({ 
        message: "Prayers imported successfully", 
        count: importedPrayers.length 
      });
    } catch (error) {
      console.error("Error importing prayers:", error);
      res.status(500).json({ error: "Failed to import prayers" });
    }
  });
  
  // Admin Testimonial Routes
  
  // Admin authentication endpoint
  app.post("/api/admin/authenticate", async (req, res) => {
    try {
      const { password } = req.body;
      
      // Check against environment variable or hardcoded admin password
      const adminPassword = process.env.ADMIN_PASSWORD || "admin123";
      
      if (password === adminPassword) {
        res.json({ success: true, message: "Authentication successful" });
      } else {
        res.status(401).json({ success: false, message: "Invalid password" });
      }
    } catch (error) {
      console.error("Admin authentication error:", error);
      res.status(500).json({ success: false, message: "Authentication error" });
    }
  });

  // Get all testimonials (including unapproved)
  app.get("/api/admin/testimonials", async (req, res) => {
    try {
      // For all saints
      const allSaints = await storage.getAllSaints();
      const testimonials = [];
      
      for (const saint of allSaints) {
        const saintTestimonials = await storage.getSaintTestimonials(saint.id, false);
        
        // Enhance testimonials with saint info
        for (const testimonial of saintTestimonials) {
          testimonials.push({
            ...testimonial,
            saintName: saint.name
          });
        }
      }
      
      return res.json(testimonials);
    } catch (error) {
      console.error("Error fetching all testimonials:", error);
      return res.status(500).json({ message: "Failed to fetch testimonials" });
    }
  });
  
  // Approve a testimonial
  app.post("/api/admin/testimonials/:id/approve", async (req, res) => {
    try {
      const testimonialId = parseInt(req.params.id, 10);
      if (isNaN(testimonialId)) {
        return res.status(400).json({ message: "Invalid testimonial ID" });
      }
      
      const testimonial = await storage.approveTestimonial(testimonialId);
      return res.json(testimonial);
    } catch (error) {
      console.error(`Error approving testimonial ${req.params.id}:`, error);
      return res.status(500).json({ message: "Failed to approve testimonial" });
    }
  });
  
  // Delete a testimonial
  app.delete("/api/admin/testimonials/:id", async (req, res) => {
    try {
      const testimonialId = parseInt(req.params.id, 10);
      if (isNaN(testimonialId)) {
        return res.status(400).json({ message: "Invalid testimonial ID" });
      }
      
      await storage.deleteTestimonial(testimonialId);
      return res.status(204).send();
    } catch (error) {
      console.error(`Error deleting testimonial ${req.params.id}:`, error);
      return res.status(500).json({ message: "Failed to delete testimonial" });
    }
  });
  
  // Get user testimonials
  app.get("/api/user/testimonials", async (req, res) => {
    try {
      const userId = getUserId(req);
      const testimonials = await storage.getUserTestimonials(userId);
      return res.json(testimonials);
    } catch (error) {
      console.error("Error fetching user testimonials:", error);
      return res.status(500).json({ message: "Failed to fetch testimonials" });
    }
  });
  
  // 54-Day Rosary Novena Routes
  
  // Get current user's active rosary novena
  app.get("/api/rosary-novenas/current", async (req, res) => {
    try {
      const userId = getUserId(req);
      const novena = await storage.getCurrentRosaryNovena(userId);
      return res.json(novena);
    } catch (error) {
      console.error("Error fetching current rosary novena:", error);
      return res.status(500).json({ message: "Failed to fetch rosary novena" });
    }
  });

  // Get rosary novena by ID
  app.get("/api/rosary-novenas/:id", async (req, res) => {
    try {
      const novenaId = parseInt(req.params.id, 10);
      if (isNaN(novenaId)) {
        return res.status(400).json({ message: "Invalid novena ID" });
      }

      const novena = await storage.getRosaryNovenaById(novenaId);
      if (!novena) {
        return res.status(404).json({ message: "Rosary novena not found" });
      }

      return res.json(novena);
    } catch (error) {
      console.error(`Error fetching rosary novena ${req.params.id}:`, error);
      return res.status(500).json({ message: "Failed to fetch rosary novena" });
    }
  });

  // Start a new 54-day rosary novena
  app.post("/api/rosary-novenas", async (req, res) => {
    try {
      const userId = getUserId(req);
      
      const schema = z.object({
        intentions: z.string().optional(),
      });
      
      const { intentions } = schema.parse(req.body);
      
      const novena = await storage.createRosaryNovena({
        userId,
        intentions: intentions || null,
        startDate: new Date(),
        currentDay: 1,
        completedDays: [],
        isComplete: false,
        phase: "petition"
      });

      return res.status(201).json(novena);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error creating rosary novena:", error);
      return res.status(500).json({ message: "Failed to create rosary novena" });
    }
  });

  // Mark a day as complete
  app.post("/api/rosary-novenas/:id/day/:day/complete", async (req, res) => {
    try {
      const novenaId = parseInt(req.params.id, 10);
      const day = parseInt(req.params.day, 10);
      
      if (isNaN(novenaId) || isNaN(day)) {
        return res.status(400).json({ message: "Invalid novena ID or day" });
      }

      const novena = await storage.markRosaryNovenaDay(novenaId, day);
      return res.json(novena);
    } catch (error) {
      console.error(`Error marking day ${req.params.day} complete for novena ${req.params.id}:`, error);
      return res.status(500).json({ message: "Failed to mark day complete" });
    }
  });

  // Get rosary novena text for a specific day
  app.get("/api/rosary-novenas/texts/:day", async (req, res) => {
    try {
      const day = parseInt(req.params.day, 10);
      if (isNaN(day) || day < 1 || day > 54) {
        return res.status(400).json({ message: "Invalid day (must be 1-54)" });
      }

      const text = await storage.getRosaryNovenaText(day);
      return res.json(text);
    } catch (error) {
      console.error(`Error fetching rosary novena text for day ${req.params.day}:`, error);
      return res.status(500).json({ message: "Failed to fetch novena text" });
    }
  });

  // Create or update rosary novena text (admin)
  app.post("/api/admin/rosary-novenas/texts", async (req, res) => {
    try {
      const schema = rosaryNovenaTextInsertSchema;
      const parsedData = schema.parse(req.body);
      
      const text = await storage.createRosaryNovenaText(parsedData);
      return res.status(201).json(text);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error creating rosary novena text:", error);
      return res.status(500).json({ message: "Failed to create novena text" });
    }
  });

  // Get rosary novena info (origin, method, promises)
  app.get("/api/rosary-novena-info", async (req, res) => {
    try {
      const info = await storage.getRosaryNovenaInfo();
      return res.json(info);
    } catch (error) {
      console.error("Error fetching rosary novena info:", error);
      return res.status(500).json({ message: "Failed to fetch novena info" });
    }
  });

  // Get specific rosary novena info by type
  app.get("/api/rosary-novena-info/:type", async (req, res) => {
    try {
      const type = req.params.type;
      const info = await storage.getRosaryNovenaInfoByType(type);
      
      if (!info) {
        return res.status(404).json({ message: "Info not found" });
      }

      return res.json(info);
    } catch (error) {
      console.error(`Error fetching rosary novena info for type ${req.params.type}:`, error);
      return res.status(500).json({ message: "Failed to fetch novena info" });
    }
  });

  // Saint Category Association Routes
  
  // Add a saint to a category
  app.post("/api/saints/categories", async (req, res) => {
    try {
      // Validate request body
      const schema = z.object({
        saintId: z.number().int().positive(),
        categoryId: z.number().int().positive()
      });
      
      const { saintId, categoryId } = schema.parse(req.body);
      
      // First check if both the saint and category exist
      try {
        await storage.getSaintById(saintId);
        await storage.getCategoryById(categoryId);
      } catch (error) {
        return res.status(404).json({ message: "Saint or category not found" });
      }
      
      await storage.addSaintToCategory(saintId, categoryId);
      return res.status(200).json({ success: true });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error adding saint to category:", error);
      return res.status(500).json({ message: "Failed to add saint to category" });
    }
  });
  
  // Remove a saint from a category
  app.delete("/api/saints/:saintId/categories/:categoryId", async (req, res) => {
    try {
      const saintId = parseInt(req.params.saintId, 10);
      const categoryId = parseInt(req.params.categoryId, 10);
      
      if (isNaN(saintId) || isNaN(categoryId)) {
        return res.status(400).json({ message: "Invalid saint or category ID" });
      }
      
      await storage.removeSaintFromCategory(saintId, categoryId);
      return res.status(204).send();
    } catch (error) {
      console.error(`Error removing saint ${req.params.saintId} from category ${req.params.categoryId}:`, error);
      return res.status(500).json({ message: "Failed to remove saint from category" });
    }
  });

  // Admin Content Editing Endpoints (simplified for basic editing)
  
  // Update category information (simplified)
  app.put("/api/admin/categories/:id", async (req, res) => {
    try {
      const categoryId = parseInt(req.params.id, 10);
      if (isNaN(categoryId)) {
        return res.status(400).json({ message: "Invalid category ID" });
      }

      const updateSchema = z.object({
        name: z.string().min(1, "Name is required"),
        description: z.string().optional()
      });

      const validated = updateSchema.parse(req.body);
      
      // Update category in database using raw SQL
      await db.execute(sql`
        UPDATE categories 
        SET name = ${validated.name}, 
            description = ${validated.description || null}
        WHERE id = ${categoryId}
      `);
      
      res.json({ message: "Category updated successfully" });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error updating category:", error);
      return res.status(500).json({ message: "Failed to update category" });
    }
  });

  // Get prayers for a specific saint (simplified)
  app.get("/api/admin/prayers/:saintId", async (req, res) => {
    try {
      const saintId = parseInt(req.params.saintId, 10);
      if (isNaN(saintId)) {
        return res.status(400).json({ message: "Invalid saint ID" });
      }

      const prayers = await storage.getSaintPrayers(saintId);
      res.json(prayers);
    } catch (error) {
      console.error("Error fetching prayers:", error);
      return res.status(500).json({ message: "Failed to fetch prayers" });
    }
  });

  // Update prayer content (simplified)
  app.put("/api/admin/prayers/:id", async (req, res) => {
    try {
      const prayerId = parseInt(req.params.id, 10);
      if (isNaN(prayerId)) {
        return res.status(400).json({ message: "Invalid prayer ID" });
      }

      const updateSchema = z.object({
        content: z.string().min(1, "Content is required")
      });

      const validated = updateSchema.parse(req.body);
      
      // Update prayer in database using raw SQL
      await db.execute(sql`
        UPDATE novena_prayers 
        SET content = ${validated.content}
        WHERE id = ${prayerId}
      `);
      
      res.json({ message: "Prayer updated successfully" });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error updating prayer:", error);
      return res.status(500).json({ message: "Failed to update prayer" });
    }
  });
  
  const httpServer = createServer(app);
  return httpServer;
}
